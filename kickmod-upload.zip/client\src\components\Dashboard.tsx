import { useEffect, useState } from "react";
import {
  Activity,
  AlertCircle,
  AlertOctagon,
  ArrowLeft,
  ArrowUpRight,
  Ban,
  Bot,
  CheckCircle2,
  Clock,
  ExternalLink,
  Eye,
  KeyRound,
  Link2,
  LogIn,
  MessageSquare,
  Plus,
  Radio,
  RefreshCw,
  Send,
  ShieldAlert,
  ShieldCheck,
  Timer,
  Trash2,
  UserCheck,
  UserPlus,
  Users,
  Webhook,
  Zap
} from "lucide-react";
import { DiscordIcon } from "./Navbar";
import { PingDot, Reveal, SectionTitle } from "./ui";

interface DashboardProps {
  user: any;
  channel: any;
  setChannel: (c: any) => void;
  onOpenAuth: () => void;
}

export default function Dashboard({
  user,
  channel,
  setChannel,
  onOpenAuth
}: DashboardProps) {
  // Onboarding Form States
  const [kickInput, setKickInput] = useState("");
  const [webhookInput, setWebhookInput] = useState("");
  const [addError, setAddError] = useState("");
  const [addSuccess, setAddSuccess] = useState("");
  const [addingLoading, setAddingLoading] = useState(false);

  // Live Channel Management States
  const [activeTab, setActiveTab] = useState<"mods" | "actions" | "webhook">("mods");
  const [scope, setScope] = useState<"live" | "month" | "all">("live");
  const [moderators, setModerators] = useState<any[]>([]);
  const [actions, setActions] = useState<any[]>([]);
  const [channelStats, setChannelStats] = useState<any>({
    total_moderators: 0,
    total_bans: 0,
    total_timeouts: 0,
    actions_today: 0,
    active_mods_today: 0,
  });
  const [refreshing, setRefreshing] = useState(false);
  const [webhookEdit, setWebhookEdit] = useState("");
  const [webhookStatus, setWebhookStatus] = useState<string | null>(null);
  const [webhookLoading, setWebhookLoading] = useState(false);

  // Fetch Channel Details & Analytics when channel is available
  const loadChannelData = async () => {
    if (!channel?.id) return;
    setRefreshing(true);
    try {
      // 1. Overview stats
      const overRes = await fetch(`/api/channels/${channel.id}/overview`);
      const overData = await overRes.json();
      if (overData.success) {
        setChannelStats(overData.stats);
      }

      // 2. Leaderboard with dynamic scope
      const leadRes = await fetch(`/api/channels/${channel.id}/leaderboard?scope=${scope}`);
      const leadData = await leadRes.json();
      if (leadData.success) {
        setModerators(leadData.moderators || []);
      }

      // 3. Mod Actions
      const actRes = await fetch(`/api/channels/${channel.id}/actions?limit=40`);
      const actData = await actRes.json();
      if (actData.success) {
        setActions(actData.actions || []);
      }
    } catch (e) {
      console.error("Failed to load channel data:", e);
    } finally {
      setTimeout(() => setRefreshing(false), 600);
    }
  };

  useEffect(() => {
    if (channel) {
      setWebhookEdit(channel.discord_webhook || "");
      loadChannelData();
    }
  }, [channel?.id, scope]);

  // Real-time socket listener
  useEffect(() => {
    const win = window as any;
    if (win.io && channel?.slug) {
      const socket = win.io();
      socket.on("mod_action", (data: any) => {
        if (data.channel_slug?.toLowerCase() === channel.slug.toLowerCase()) {
          setActions((prev) => [data, ...prev.slice(0, 39)]);
        }
      });
      socket.on("attendance_update", (data: any) => {
        if (data.channel_slug?.toLowerCase() === channel.slug.toLowerCase()) {
          loadChannelData();
        }
      });
      return () => {
        socket.disconnect();
      };
    }
  }, [channel?.slug]);

  // Submit new channel
  const handleAddChannel = async (e: React.FormEvent) => {
    e.preventDefault();
    setAddError("");
    setAddSuccess("");

    const clean = kickInput
      .trim()
      .replace(/^https?:\/\/(www\.)?kick\.com\//, "")
      .replace(/[^a-zA-Z0-9_-]/g, "");

    if (!clean) {
      return setAddError("يرجى إدخال اسم القناة أو الرابط بشكل صحيح.");
    }

    if (
      webhookInput.trim() &&
      !/^https:\/\/(canary\.|ptb\.)?(discord|discordapp)\.com\/api\/webhooks\//.test(
        webhookInput.trim()
      )
    ) {
      return setAddError("رابط ويب هوك ديسكورد غير صالح.");
    }

    setAddingLoading(true);
    try {
      const res = await fetch("/api/channels", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({
          slug: clean,
          discord_webhook: webhookInput.trim(),
        }),
      });

      const data = await res.json();
      if (!data.success) {
        setAddingLoading(false);
        return setAddError(data.error || "فشل تسجيل القناة.");
      }

      setAddSuccess(data.message || "تم ربط وتفعيل قناتك بنجاح!");
      setChannel(data.channel);
      setKickInput("");
      setWebhookInput("");
    } catch (err: any) {
      setAddError(err.message || "حدث خطأ بالاتصال بالسيرفر.");
    } finally {
      setAddingLoading(false);
    }
  };

  // Update Discord Webhook
  const handleUpdateWebhook = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!channel?.id) return;
    setWebhookStatus(null);
    setWebhookLoading(true);

    try {
      const res = await fetch(`/api/channels/${channel.id}/webhook`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ discord_webhook: webhookEdit.trim() }),
      });
      const data = await res.json();
      if (!data.success) {
        setWebhookStatus("فشل التحديث: " + (data.error || "خطأ غير معروف"));
      } else {
        setWebhookStatus(
          data.webhookValid
            ? "تم تحديث الرابط وإرسال تجربة فورية بنجاح إلى ديسكورد!"
            : "تم حفظ الرابط بنجاح."
        );
        setChannel({ ...channel, discord_webhook: webhookEdit.trim() });
      }
    } catch (err: any) {
      setWebhookStatus("حدث خطأ أثناء التحديث");
    } finally {
      setWebhookLoading(false);
    }
  };

  // Delete / Disconnect channel
  const handleDeleteChannel = async () => {
    if (!channel?.id) return;
    if (
      !confirm(
        `هل أنت متأكد من رغبتك في فصل قناة (${channel.slug})؟ سيتم إيقاف المراقبة فوراً.`
      )
    ) {
      return;
    }

    try {
      const res = await fetch(`/api/channels/${channel.id}`, {
        method: "DELETE",
        credentials: "include",
      });
      const data = await res.json();
      if (data.success) {
        setChannel(null);
      } else {
        alert(data.error || "فشل فصل القناة");
      }
    } catch (err) {
      alert("خطأ أثناء الاتصال بالسيرفر");
    }
  };

  return (
    <section id="dashboard" className="relative px-4 py-24">
      <div className="pointer-events-none absolute inset-x-0 top-1/2 -z-10 mx-auto h-96 max-w-4xl -translate-y-1/2 rounded-full bg-kick/10 blur-[150px]" />

      <div className="mx-auto max-w-6xl">
        {/* Section Header */}
        <SectionTitle
          badge="المنظومة السحابية الذكية"
          title="لوحة تحكم ومراقبة"
          accent="قناتك الخاصة"
          desc="مراقبة حصرية ومحمية 24/7 لكل ستريمر: إحصائيات المشرفين، الحضور الصامت، التنبيهات الفورية وسجل العقوبات."
        />

        {/* CASE 1: USER NOT LOGGED IN */}
        {!user && (
          <Reveal>
            <div className="relative mx-auto max-w-3xl overflow-hidden rounded-3xl border border-kick/30 bg-gradient-to-b from-[#101714] to-[#070b09] p-8 shadow-[0_0_80px_-20px_rgba(83,252,24,0.35)] md:p-12 text-center">
              <div className="absolute -top-24 start-1/2 h-52 w-80 -translate-x-1/2 rounded-full bg-kick/20 blur-[90px]" />

              <div className="mx-auto mb-6 flex h-16 w-16 items-center justify-center rounded-2xl border border-kick/50 bg-kick/10 text-kick shadow-[0_0_30px_rgba(83,252,24,0.3)]">
                <ShieldCheck className="h-8 w-8" />
              </div>

              <h3 className="text-2xl font-black md:text-3xl">
                نظام المراقبة الحصري والمحمي للستريمرز
              </h3>

              <p className="mx-auto mt-4 max-w-xl text-sm leading-7 text-gray-400">
                لكل حساب قناة واحدة مخصصة لا يمكن لأحد غيرك إضافتها أو الاطلاع على بيانات مشرفيها. سجّل دخولك الآن عبر ديسكورد أو البريد الإلكتروني لتفعيل الرصد اللحظي على مدار الساعة.
              </p>

              {/* Feature Grid */}
              <div className="my-8 grid grid-cols-1 gap-3 sm:grid-cols-3 text-start">
                <div className="rounded-2xl border border-white/5 bg-black/50 p-4">
                  <PingDot />
                  <div className="mt-2 text-xs font-bold text-white">رصد صامت 24/7</div>
                  <div className="text-[11px] text-gray-400 mt-1">كشف المشرفين المتواجدين بدون كتابة شات</div>
                </div>
                <div className="rounded-2xl border border-white/5 bg-black/50 p-4">
                  <Bot className="h-4 w-4 text-cyan-400" />
                  <div className="mt-2 text-xs font-bold text-white">عزل البوتات</div>
                  <div className="text-[11px] text-gray-400 mt-1">تمييز حسابات BotRix وتجنب احتسابها بالخطأ</div>
                </div>
                <div className="rounded-2xl border border-white/5 bg-black/50 p-4">
                  <Zap className="h-4 w-4 text-amber-400" />
                  <div className="mt-2 text-xs font-bold text-white">تنبيهات ديسكورد</div>
                  <div className="text-[11px] text-gray-400 mt-1">إشعارات فورية لكل حظر وكتم في روم المودز</div>
                </div>
              </div>

              <div className="flex flex-wrap items-center justify-center gap-3">
                <a
                  href="/dashboard"
                  className="btn-shine flex items-center gap-2 rounded-2xl bg-kick px-6 py-3.5 text-xs font-black text-black shadow-[0_0_25px_rgba(83,252,24,0.4)] transition hover:brightness-110"
                >
                  <Radio className="h-4 w-4 animate-pulse" />
                  دخول الداشبورد مباشرة
                </a>
                <a
                  href="/api/auth/discord/login"
                  className="flex items-center gap-2 rounded-2xl bg-[#5865f2] px-6 py-3.5 text-xs font-bold text-white shadow-[0_0_30px_rgba(88,101,242,0.4)] transition hover:brightness-110"
                >
                  <DiscordIcon className="h-4 w-4" />
                  تسجيل الدخول عبر ديسكورد (OAuth2)
                </a>
                <button
                  onClick={onOpenAuth}
                  className="glass flex items-center gap-2 rounded-2xl px-6 py-3.5 text-xs font-bold text-gray-200 transition hover:border-kick/40"
                >
                  <LogIn className="h-4 w-4 text-kick" />
                  تسجيل الدخول بالبريد أو OTP
                </button>
              </div>
            </div>
          </Reveal>
        )}

        {/* CASE 2: LOGGED IN BUT NO CHANNEL YET (ONBOARDING) */}
        {user && !channel && (
          <Reveal>
            <div className="relative mx-auto max-w-2xl overflow-hidden rounded-3xl border border-kick/40 bg-gradient-to-b from-[#101714] to-[#070b09] p-8 shadow-[0_0_90px_-20px_rgba(83,252,24,0.4)] md:p-10">
              <div className="absolute -top-20 start-1/2 h-44 w-72 -translate-x-1/2 rounded-full bg-kick/20 blur-[80px]" />

              <div className="relative flex items-center gap-4 border-b border-white/5 pb-6">
                <div className="flex h-14 w-14 shrink-0 items-center justify-center rounded-2xl border border-kick/50 bg-kick/10 text-kick shadow-[0_0_25px_rgba(83,252,24,0.25)]">
                  <Plus className="h-7 w-7" />
                </div>
                <div>
                  <h3 className="text-xl font-black text-white">ربط وتفعيل قناتك للمراقبة الحصرية</h3>
                  <p className="mt-1 text-xs text-gray-400">
                    أهلاً بك <b className="text-kick">@{user.username}</b>! أدخل معرف قناتك على كيك لحمايتها والبدء في الرصد اللحظي.
                  </p>
                </div>
              </div>

              <form onSubmit={handleAddChannel} className="relative mt-6 space-y-5">
                <div>
                  <label className="mb-2 flex items-center gap-2 text-xs font-bold text-gray-200">
                    <Link2 className="h-3.5 w-3.5 text-kick" />
                    معرّف أو رابط القناة على كيك (Kick Username)
                  </label>
                  <div className="group relative">
                    <input
                      required
                      value={kickInput}
                      onChange={(e) => setKickInput(e.target.value)}
                      placeholder="مثال: example أو اسم قناتك"
                      className="w-full rounded-xl border border-white/10 bg-black/70 py-4 pe-4 ps-24 text-sm outline-none transition placeholder:text-gray-600 focus:border-kick/60 focus:shadow-[0_0_0_4px_rgba(83,252,24,0.08)]"
                    />
                    <span dir="ltr" className="absolute start-4 top-1/2 -translate-y-1/2 font-mono text-xs text-kick font-bold">
                      kick.com/
                    </span>
                  </div>
                </div>

                <div>
                  <label className="mb-2 flex items-center gap-2 text-xs font-bold text-gray-200">
                    <Webhook className="h-3.5 w-3.5 text-indigo-300" />
                    رابط ديسكورد ويب هوك
                    <span className="font-normal text-gray-500">(اختياري - لتنبيهات روم المودز)</span>
                  </label>
                  <input
                    dir="ltr"
                    value={webhookInput}
                    onChange={(e) => setWebhookInput(e.target.value)}
                    placeholder="https://discord.com/api/webhooks/..."
                    className="w-full rounded-xl border border-white/10 bg-black/70 px-4 py-4 text-sm outline-none transition placeholder:text-gray-600 focus:border-kick/60"
                  />
                </div>

                <div className="rounded-xl border border-amber-500/20 bg-amber-500/5 p-3 text-xs text-amber-200/90 leading-5 flex items-start gap-2">
                  <ShieldAlert className="h-4 w-4 shrink-0 text-amber-400 mt-0.5" />
                  <span>
                    <b>حماية الملكية:</b> القناة التي تضيفها هنا ترتبط بحسابك بشكل دائم ومحمي؛ لن يتمكن أي مستخدم آخر من إضافتها أو التلاعب ببياناتها.
                  </span>
                </div>

                {addError && (
                  <div className="flex items-center gap-2 rounded-xl border border-red-500/30 bg-red-500/10 px-4 py-3 text-sm font-semibold text-red-300">
                    <AlertCircle className="h-4 w-4 shrink-0" /> {addError}
                  </div>
                )}
                {addSuccess && (
                  <div className="flex items-center gap-2 rounded-xl border border-kick/30 bg-kick/10 px-4 py-3 text-sm font-semibold text-kick">
                    <CheckCircle2 className="h-4 w-4 shrink-0" /> {addSuccess}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={addingLoading}
                  className="btn-shine flex items-center justify-center gap-2 w-full rounded-2xl bg-kick py-4 text-sm font-extrabold text-black shadow-[0_10px_40px_-8px_rgba(83,252,24,0.6)] transition hover:brightness-110"
                >
                  {addingLoading ? "جارٍ التحقق وبدء الرصد..." : "تفعيل وحماية القناة 24/7"}
                  <ArrowLeft className="h-4 w-4" />
                </button>
              </form>
            </div>
          </Reveal>
        )}

        {/* CASE 3: LOGGED IN AND CHANNEL ATTACHED (FULL LIVE DASHBOARD) */}
        {user && channel && (
          <div className="space-y-6">
            {/* Direct Switch to Big Old Dashboard Banner */}
            <div className="rounded-2xl border border-kick/40 bg-gradient-to-r from-kick/15 via-black/60 to-kick/5 p-5 flex flex-col sm:flex-row items-center justify-between gap-4 shadow-[0_0_40px_rgba(83,252,24,0.15)]">
              <div className="flex items-center gap-3.5">
                <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-kick/20 text-kick border border-kick/40 shadow-lg">
                  <Radio className="h-6 w-6 animate-pulse" />
                </div>
                <div>
                  <h4 className="text-base font-black text-white">لوحة التحكم (الداشبورد)</h4>
                  <p className="text-xs text-gray-400 mt-0.5">شات البث الحي، مخططات Chart.js المتقدمة، توزيع مهام الإشراف، وتصدير CSV/JSON</p>
                </div>
              </div>
              <a
                href="/dashboard"
                className="btn-shine flex items-center gap-2 rounded-xl bg-kick px-5 py-3 text-xs font-black text-black shadow-[0_0_20px_rgba(83,252,24,0.4)] transition hover:brightness-110 shrink-0"
              >
                <span>دخول الداشبورد</span>
                <ArrowLeft className="h-4 w-4" />
              </a>
            </div>

            {/* Channel Top Banner & Info Card */}
            <div className="relative overflow-hidden rounded-3xl border border-kick/30 bg-gradient-to-b from-[#111815] to-[#090d0b] p-6 shadow-[0_0_60px_-15px_rgba(83,252,24,0.3)] md:p-8">
              <div className="absolute -top-24 end-10 h-48 w-72 rounded-full bg-kick/15 blur-[90px]" />

              <div className="flex flex-col gap-6 md:flex-row md:items-center md:justify-between">
                <div className="flex items-center gap-4">
                  {channel.avatar_url ? (
                    <img
                      src={channel.avatar_url}
                      alt={channel.slug}
                      className="h-16 w-16 rounded-2xl border-2 border-kick/40 object-cover shadow-lg"
                    />
                  ) : (
                    <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-kick/50 bg-kick/10 text-2xl font-black text-kick">
                      {channel.slug.slice(0, 2).toUpperCase()}
                    </div>
                  )}

                  <div>
                    <div className="flex items-center gap-3">
                      <h3 className="text-2xl font-black text-white">
                        {channel.name || channel.slug}
                      </h3>
                      <span className="inline-flex items-center gap-1.5 rounded-full border border-kick/40 bg-kick/10 px-3 py-1 text-xs font-bold text-kick">
                        <PingDot />
                        رصد سحابي مباشر 24/7
                      </span>
                    </div>

                    <div className="mt-1.5 flex flex-wrap items-center gap-4 text-xs text-gray-400">
                      <span dir="ltr" className="font-mono text-gray-300">
                        kick.com/{channel.slug}
                      </span>
                      <a
                        href={`https://kick.com/${channel.slug}`}
                        target="_blank"
                        rel="noreferrer"
                        className="inline-flex items-center gap-1 text-kick hover:underline"
                      >
                        فتح القناة على كيك
                        <ExternalLink className="h-3 w-3" />
                      </a>
                    </div>
                  </div>
                </div>

                <div className="flex flex-wrap items-center gap-2.5">
                  <button
                    onClick={loadChannelData}
                    className="flex items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3.5 py-2 text-xs font-bold text-gray-200 transition hover:border-kick/50 hover:text-kick"
                  >
                    <RefreshCw className={`h-3.5 w-3.5 ${refreshing ? "animate-spin text-kick" : ""}`} />
                    تحديث
                  </button>
                  <button
                    onClick={() => setActiveTab("webhook")}
                    className="flex items-center gap-1.5 rounded-xl border border-indigo-500/30 bg-indigo-500/10 px-3.5 py-2 text-xs font-bold text-indigo-300 transition hover:brightness-110"
                  >
                    <Webhook className="h-3.5 w-3.5" />
                    إعدادات الويب هوك
                  </button>
                  <button
                    onClick={handleDeleteChannel}
                    className="flex items-center gap-1.5 rounded-xl border border-red-500/20 bg-red-500/5 px-3 py-2 text-xs font-bold text-red-400 transition hover:bg-red-500/15"
                    title="فصل القناة"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                  </button>
                </div>
              </div>

              {/* 4 Quick Stat Counters */}
              <div className="mt-8 grid grid-cols-2 gap-3 md:grid-cols-4">
                <div className="rounded-2xl border border-white/5 bg-black/40 p-4">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>إجمالي المشرفين</span>
                    <Users className="h-4 w-4 text-kick" />
                  </div>
                  <div className="mt-2 text-2xl font-black text-white tabular-nums">
                    {moderators.length || channelStats.total_moderators || 0}
                  </div>
                  <div className="mt-1 text-[11px] text-gray-500">مشرفين تم رصدهم</div>
                </div>

                <div className="rounded-2xl border border-white/5 bg-black/40 p-4">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>مشرفون متواجدون</span>
                    <UserCheck className="h-4 w-4 text-emerald-400" />
                  </div>
                  <div className="mt-2 text-2xl font-black text-emerald-400 tabular-nums">
                    {moderators.filter((m) => m.is_online).length}
                  </div>
                  <div className="mt-1 text-[11px] text-gray-500">حضور لحظي بالشات</div>
                </div>

                <div className="rounded-2xl border border-white/5 bg-black/40 p-4">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>عمليات الحظر (Bans)</span>
                    <Ban className="h-4 w-4 text-red-400" />
                  </div>
                  <div className="mt-2 text-2xl font-black text-red-400 tabular-nums">
                    {channelStats.total_bans || 0}
                  </div>
                  <div className="mt-1 text-[11px] text-gray-500">حظر دائم موثق</div>
                </div>

                <div className="rounded-2xl border border-white/5 bg-black/40 p-4">
                  <div className="flex items-center justify-between text-xs text-gray-400">
                    <span>عمليات الكتم (Timeouts)</span>
                    <Timer className="h-4 w-4 text-amber-400" />
                  </div>
                  <div className="mt-2 text-2xl font-black text-amber-400 tabular-nums">
                    {channelStats.total_timeouts || 0}
                  </div>
                  <div className="mt-1 text-[11px] text-gray-500">كتم مؤقت مسجل</div>
                </div>
              </div>
            </div>

            {/* Navigation Tabs */}
            <div className="flex border-b border-white/10 gap-2 pb-1">
              <button
                onClick={() => setActiveTab("mods")}
                className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold transition ${
                  activeTab === "mods"
                    ? "bg-kick text-black font-black shadow-[0_0_20px_rgba(83,252,24,0.3)]"
                    : "text-gray-400 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Users className="h-4 w-4" />
                أفضل المشرفين وتفاعلهم ({moderators.length})
              </button>
              <button
                onClick={() => setActiveTab("actions")}
                className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold transition ${
                  activeTab === "actions"
                    ? "bg-kick text-black font-black shadow-[0_0_20px_rgba(83,252,24,0.3)]"
                    : "text-gray-400 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Activity className="h-4 w-4" />
                سجل الإجراءات اللحظي ({actions.length})
              </button>
              <button
                onClick={() => setActiveTab("webhook")}
                className={`flex items-center gap-2 rounded-xl px-5 py-2.5 text-xs font-bold transition ${
                  activeTab === "webhook"
                    ? "bg-kick text-black font-black shadow-[0_0_20px_rgba(83,252,24,0.3)]"
                    : "text-gray-400 hover:bg-white/5 hover:text-white"
                }`}
              >
                <Webhook className="h-4 w-4" />
                تنبيهات ديسكورد
              </button>
            </div>

            {/* TAB CONTENT 1: MODERATORS LEADERBOARD */}
            {activeTab === "mods" && (
              <div className="overflow-hidden rounded-3xl border border-white/10 bg-[#0c1210] p-6 shadow-xl">
                <div className="mb-4 flex flex-wrap items-center justify-between gap-3">
                  <div>
                    <h4 className="text-base font-bold text-white flex items-center gap-2">
                      <ShieldCheck className="h-5 w-5 text-kick" />
                      لوحة شرف وترتيب المشرفين
                    </h4>
                    <span className="text-xs text-gray-400">
                      تقييم تلقائي بناءً على الحضور، الحظر، الكتم، والتفاعل
                    </span>
                  </div>

                  {/* 3 Scope Buttons: اللايف الواحد | الشهر كله | الوقت كله */}
                  <div className="inline-flex bg-black/60 border border-white/10 p-1 rounded-xl text-xs gap-1">
                    <button
                      onClick={() => setScope("live")}
                      className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
                        scope === "live"
                          ? "bg-kick text-black font-black shadow-sm"
                          : "text-gray-400 hover:text-white"
                      }`}
                    >
                      <span className="h-1.5 w-1.5 rounded-full bg-black live-pulse" />
                      اللايف الواحد
                    </button>
                    <button
                      onClick={() => setScope("month")}
                      className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
                        scope === "month"
                          ? "bg-kick text-black font-black shadow-sm"
                          : "text-gray-400 hover:text-white"
                      }`}
                    >
                      الشهر كله
                    </button>
                    <button
                      onClick={() => setScope("all")}
                      className={`px-3 py-1.5 rounded-lg font-bold transition flex items-center gap-1.5 ${
                        scope === "all"
                          ? "bg-kick text-black font-black shadow-sm"
                          : "text-gray-400 hover:text-white"
                      }`}
                    >
                      الوقت كله
                    </button>
                  </div>
                </div>

                {moderators.length === 0 ? (
                  <div className="py-12 text-center text-gray-500">
                    <PingDot className="mx-auto mb-3" />
                    بانتظار رصد المشرفين أثناء البث القادم... النظام يراقب القناة 24/7
                  </div>
                ) : (
                  <div className="overflow-x-auto">
                    <table className="w-full text-end text-xs">
                      <thead>
                        <tr className="border-b border-white/5 text-gray-400">
                          <th className="p-3 text-start">المشرف</th>
                          <th className="p-3 text-center">الحالة</th>
                          <th className="p-3 text-center">نقاط النشاط</th>
                          <th className="p-3 text-center">حظر</th>
                          <th className="p-3 text-center">كتم</th>
                          <th className="p-3 text-center">الرسائل</th>
                          <th className="p-3 text-end">آخر ظهور</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-white/5">
                        {moderators.map((m, idx) => (
                          <tr key={m.id || idx} className="hover:bg-white/5 transition">
                            <td className="p-3 text-start">
                              <div className="flex items-center gap-3">
                                <span className="font-mono text-gray-500 w-4">#{idx + 1}</span>
                                {m.avatar_url ? (
                                  <img
                                    src={m.avatar_url}
                                    alt={m.username}
                                    className="h-8 w-8 rounded-xl object-cover"
                                  />
                                ) : (
                                  <div className="flex h-8 w-8 items-center justify-center rounded-xl bg-white/5 font-bold text-kick">
                                    {m.username.slice(0, 1).toUpperCase()}
                                  </div>
                                )}
                                <span dir="ltr" className="font-bold text-white">
                                  {m.username}
                                </span>
                              </div>
                            </td>
                            <td className="p-3 text-center">
                              {m.is_bot ? (
                                <span className="rounded-lg bg-cyan-500/10 border border-cyan-500/30 px-2 py-0.5 text-[10px] font-bold text-cyan-400">
                                  BOT
                                </span>
                              ) : m.is_online ? (
                                <span className="inline-flex items-center gap-1 rounded-lg bg-kick/10 border border-kick/30 px-2 py-0.5 text-[10px] font-bold text-kick">
                                  <PingDot /> متصل
                                </span>
                              ) : (
                                <span className="rounded-lg bg-gray-500/10 px-2 py-0.5 text-[10px] text-gray-400">
                                  غير متصل
                                </span>
                              )}
                            </td>
                            <td className="p-3 text-center font-bold text-kick tabular-nums">
                              {m.activity_score || 0}
                            </td>
                            <td className="p-3 text-center text-red-400 font-bold tabular-nums">
                              {m.total_bans || 0}
                            </td>
                            <td className="p-3 text-center text-amber-400 font-bold tabular-nums">
                              {m.total_timeouts || 0}
                            </td>
                            <td className="p-3 text-center text-gray-300 tabular-nums">
                              {m.total_messages || 0}
                            </td>
                            <td className="p-3 text-end text-gray-400 text-[11px]">
                              {m.last_seen ? new Date(m.last_seen).toLocaleDateString("ar-EG") : "اليوم"}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT 2: LIVE ACTIONS AUDIT */}
            {activeTab === "actions" && (
              <div className="overflow-hidden rounded-3xl border border-white/10 bg-[#0c1210] p-6 shadow-xl">
                <div className="mb-4 flex items-center justify-between">
                  <h4 className="text-base font-bold text-white flex items-center gap-2">
                    <Activity className="h-5 w-5 text-kick" />
                    سجل إجراءات الإشراف اللحظية (Live Audit)
                  </h4>
                  <span className="text-xs text-gray-400">
                    تحديث فوري لكل حظر، كتم، أو حذف رسالة
                  </span>
                </div>

                {actions.length === 0 ? (
                  <div className="py-12 text-center text-gray-500">
                    <PingDot className="mx-auto mb-3" />
                    بانتظار إجراءات إشراف جديدة من المشرفين في الشات...
                  </div>
                ) : (
                  <div className="space-y-2.5">
                    {actions.map((act, i) => (
                      <div
                        key={act.id || i}
                        className="flex items-center justify-between rounded-2xl border border-white/5 bg-black/40 p-3.5 text-xs transition hover:border-white/10"
                      >
                        <div className="flex items-center gap-3">
                          <span
                            className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-xl ${
                              act.action_type === "ban"
                                ? "bg-red-500/10 text-red-400 border border-red-500/30"
                                : act.action_type === "timeout"
                                ? "bg-amber-500/10 text-amber-400 border border-amber-500/30"
                                : "bg-cyan-500/10 text-cyan-400"
                            }`}
                          >
                            {act.action_type === "ban" ? (
                              <Ban className="h-4 w-4" />
                            ) : act.action_type === "timeout" ? (
                              <Timer className="h-4 w-4" />
                            ) : (
                              <MessageSquare className="h-4 w-4" />
                            )}
                          </span>

                          <div>
                            <div className="font-bold text-white">
                              {act.action_type === "ban"
                                ? "حظر دائم للمستخدم: "
                                : act.action_type === "timeout"
                                ? `كتم مؤقت (${act.duration_seconds ? Math.floor(act.duration_seconds / 60) + " د" : ""}): `
                                : "حذف رسالة: "}
                              <b dir="ltr" className="text-kick">
                                {act.target_username || "مستخدم"}
                              </b>
                            </div>
                            <div className="mt-0.5 text-[11px] text-gray-400">
                              بواسطة المشرف:{" "}
                              <span dir="ltr" className="font-semibold text-gray-300">
                                {act.moderator_username || "BotRix"}
                              </span>{" "}
                              {act.reason && `· السبب: ${act.reason}`}
                            </div>
                          </div>
                        </div>

                        <span className="text-[11px] font-mono text-gray-500 tabular-nums">
                          {act.created_at ? new Date(act.created_at).toLocaleTimeString("ar-EG") : "الآن"}
                        </span>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            )}

            {/* TAB CONTENT 3: WEBHOOK SETTINGS */}
            {activeTab === "webhook" && (
              <div className="rounded-3xl border border-white/10 bg-[#0c1210] p-6 md:p-8 shadow-xl">
                <div className="max-w-xl">
                  <h4 className="text-base font-bold text-white flex items-center gap-2">
                    <Webhook className="h-5 w-5 text-indigo-400" />
                    ربط تنبيهات ديسكورد (Discord Webhook)
                  </h4>
                  <p className="mt-1 text-xs text-gray-400 leading-6">
                    أدخل رابط Webhook من سيرفر ديسكورد الخاص بك ليصلك تنبيه لحظي لكل إجراء حظر أو كتم يتم في قناتك مع اسم المشرف والتفاصيل.
                  </p>

                  <form onSubmit={handleUpdateWebhook} className="mt-6 space-y-4">
                    <div>
                      <label className="block text-xs font-bold text-gray-300 mb-1.5">
                        رابط ديسكورد ويب هوك
                      </label>
                      <input
                        dir="ltr"
                        value={webhookEdit}
                        onChange={(e) => setWebhookEdit(e.target.value)}
                        placeholder="https://discord.com/api/webhooks/..."
                        className="w-full rounded-xl border border-white/10 bg-black/70 px-4 py-3.5 text-xs font-mono outline-none transition focus:border-indigo-400"
                      />
                    </div>

                    {webhookStatus && (
                      <div className="rounded-xl border border-indigo-500/30 bg-indigo-500/10 p-3 text-xs text-indigo-300">
                        {webhookStatus}
                      </div>
                    )}

                    <button
                      type="submit"
                      disabled={webhookLoading}
                      className="flex items-center gap-2 rounded-xl bg-[#5865f2] px-6 py-3 text-xs font-bold text-white shadow-lg transition hover:brightness-110"
                    >
                      <Send className="h-4 w-4" />
                      {webhookLoading ? "جارٍ الحفظ والفحص..." : "حفظ واختبار الويب هوك الآن"}
                    </button>
                  </form>
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </section>
  );
}

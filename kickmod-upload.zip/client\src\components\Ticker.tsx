import { useEffect, useState } from "react";

const base = [
  { name: "stream_creator", v: 8200 },
  { name: "example_live", v: 12400 },
  { name: "gaming_zone", v: 5600 },
  { name: "pro_streamer", v: 3100 },
  { name: "creator_hub", v: 9800 },
  { name: "live_channel", v: 2400 },
  { name: "stream_master", v: 6700 },
  { name: "media_live", v: 4300 },
];

export default function Ticker() {
  const [vals, setVals] = useState(base.map((b) => b.v));
  useEffect(() => {
    const t = setInterval(
      () => setVals((v) => v.map((x, i) => Math.max(base[i].v * 0.9, Math.min(base[i].v * 1.1, x + Math.round((Math.random() - 0.5) * 160))))),
      2000
    );
    return () => clearInterval(t);
  }, []);

  const items = base.map((b, i) => (
    <div key={b.name} className="flex shrink-0 items-center gap-3 px-8">
      <span className="h-1.5 w-1.5 rounded-full bg-red-500 shadow-[0_0_8px_#ef4444]" />
      <span dir="ltr" className="font-bold">
        <span className="text-gray-500">kick.com/</span>
        {b.name}
      </span>
      <span className="rounded-md bg-kick/10 px-2 py-0.5 text-xs font-bold tabular-nums text-kick">
        {Math.round(vals[i]).toLocaleString("en-US")} مشاهد
      </span>
    </div>
  ));

  return (
    <div className="relative border-y border-white/5 bg-black/30 py-4 text-sm">
      <div className="absolute inset-y-0 start-0 z-10 w-24 bg-gradient-to-r from-ink to-transparent" />
      <div className="absolute inset-y-0 end-0 z-10 w-24 bg-gradient-to-l from-ink to-transparent" />
      <div className="overflow-hidden">
        <div className="animate-marquee flex w-max">
          <div className="flex">{items}</div>
          <div className="flex" aria-hidden>{items}</div>
        </div>
      </div>
    </div>
  );
}

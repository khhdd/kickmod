import { useState, useEffect } from "react";
import Navbar from "./components/Navbar";
import Hero from "./components/Hero";
import Ticker from "./components/Ticker";
import Stats from "./components/Stats";
import Features from "./components/Features";
import Dashboard from "./components/Dashboard";
import { CTA, FAQ, Footer, Steps } from "./components/Bottom";

export default function App() {
  const [user, setUser] = useState<any>(null);
  const [channel, setChannel] = useState<any>(null);
  const [loadingSession, setLoadingSession] = useState(true);
  const [openAuthModal, setOpenAuthModal] = useState<"login" | "register" | null>(null);

  // Check authenticated session on mount and handle OAuth redirect
  const checkSession = async () => {
    try {
      // Check URL parameters for OAuth success or error
      const params = new URLSearchParams(window.location.search);
      if (params.get("auth") === "success") {
        window.history.replaceState({}, document.title, window.location.pathname);
      }

      const res = await fetch("/api/auth/me", { credentials: "include" });
      const data = await res.json();
      if (data.authenticated && data.user) {
        setUser(data.user);
        setChannel(data.channel || null);
        localStorage.setItem("kickmod_user", JSON.stringify(data.user));
      } else {
        setUser(null);
        setChannel(null);
        localStorage.removeItem("kickmod_user");
      }
    } catch (err) {
      console.error("Session check error:", err);
    } finally {
      setLoadingSession(false);
    }
  };

  useEffect(() => {
    checkSession();
  }, []);

  return (
    <div dir="rtl" className="noise min-h-screen overflow-x-hidden bg-ink text-white">
      <Navbar
        user={user}
        setUser={setUser}
        channel={channel}
        openModal={openAuthModal}
        setOpenModal={setOpenAuthModal}
        onRefreshSession={checkSession}
      />
      <main>
        <Hero user={user} onOpenAuth={() => setOpenAuthModal("login")} />
        <Ticker />
        <Stats channels={channel ? 1 : 0} />
        <Features />
        <Dashboard
          user={user}
          channel={channel}
          setChannel={setChannel}
          onOpenAuth={() => setOpenAuthModal("login")}
        />
        <Steps />
        <FAQ />
        {!user && <CTA onOpenAuth={() => setOpenAuthModal("register")} />}
      </main>
      <Footer />
    </div>
  );
}

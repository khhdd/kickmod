const { dbAsync } = require('../db/database');

async function resetAllData() {
    console.log('Resetting all moderation and attendance data...');
    try {
        await dbAsync.run('DELETE FROM mod_attendance_sessions');
        await dbAsync.run('DELETE FROM mod_actions');
        await dbAsync.run('DELETE FROM stream_reports');
        if (await dbAsync.get("SELECT name FROM sqlite_master WHERE type='table' AND name='mod_sessions'")) {
            await dbAsync.run('DELETE FROM mod_sessions');
        }
        await dbAsync.run(`
            UPDATE moderators 
            SET total_messages = 0, 
                total_bans = 0, 
                total_timeouts = 0, 
                total_deleted = 0, 
                total_active_seconds = 0, 
                is_online = 0
        `);
        console.log('Successfully reset all attendance and moderation stats.');
        process.exit(0);
    } catch (e) {
        console.error('Reset error:', e);
        process.exit(1);
    }
}

resetAllData();


// KickMod Dashboard Client Engine
let currentChannelId = null;
let currentChannelSlug = null;
let currentView = 'landing'; // 'landing' or 'dashboard'
let actionsChartInstance = null;
let pieChartInstance = null;
let allModeratorsData = [];
let currentModFilter = 'human'; // 'human' (default) or 'all'

/**
 * Accurately parses SQLite datetime strings avoiding timezone drift
 */
function parseSqliteDate(dateStr) {
    if (!dateStr) return null;
    if (dateStr instanceof Date) return dateStr;
    const s = String(dateStr).trim();
    if (s.endsWith('Z') || s.includes('+')) return new Date(s);
    return new Date(s.replace(' ', 'T') + 'Z');
}

/**
 * Universal localized date/time formatter (Egypt / Local Timezone guaranteed)
 */
function formatAppDate(dateStr, options = { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' }) {
    const d = parseSqliteDate(dateStr);
    if (!d || isNaN(d.getTime())) return '-';
    return d.toLocaleDateString('ar-EG', options);
}

// Initialize Socket.io
const socket = io();

socket.on('connect', () => {
    console.log('Connected to KickMod real-time socket server.');
    const statusEl = document.getElementById('systemStatus');
    if (statusEl) {
        statusEl.textContent = 'المحرك المباشر متصل 24/7';
        statusEl.classList.remove('text-red-400');
        statusEl.classList.add('text-gray-400');
    }
});

socket.on('disconnect', () => {
    const statusEl = document.getElementById('systemStatus');
    if (statusEl) {
        statusEl.textContent = 'انقطع الاتصال بالسيرفر';
        statusEl.classList.remove('text-gray-400');
        statusEl.classList.add('text-red-400');
    }
});

// Real-time Event Throttling and Batching to keep 60fps & low CPU
let leaderboardThrottleTimer = null;
function scheduleLeaderboardUpdate(delay = 3500) {
    if (leaderboardThrottleTimer) return;
    leaderboardThrottleTimer = setTimeout(() => {
        leaderboardThrottleTimer = null;
        if (currentView === 'dashboard' && currentChannelId) {
            loadLeaderboard();
            loadBestMods();
        }
    }, delay);
}

let networkStatsThrottleTimer = null;
function scheduleNetworkStatsUpdate(delay = 5000) {
    if (networkStatsThrottleTimer) return;
    networkStatsThrottleTimer = setTimeout(() => {
        networkStatsThrottleTimer = null;
        loadNetworkStats();
    }, delay);
}

// Real-time Event: Moderator Action Executed (Ban, Timeout, Delete)
socket.on('mod_action', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        appendLiveFeedItem(data);
        incrementCounter(data.action_type);

        // Fast in-place pie chart increment
        if (pieChartInstance && pieChartInstance.data && pieChartInstance.data.datasets[0]) {
            const arr = pieChartInstance.data.datasets[0].data;
            if (data.action_type === 'timeout') arr[1] = (arr[1] || 0) + 1;
            else if (data.action_type === 'ban') arr[2] = (arr[2] || 0) + 1;
            pieChartInstance.update('none');
        }

        scheduleLeaderboardUpdate(2500);
    }
    scheduleNetworkStatsUpdate(5000);
});

// Real-time Event: Moderator Chat Message
socket.on('mod_message', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        const msgEl = document.getElementById('statModMessages');
        if (msgEl) {
            msgEl.textContent = parseInt(msgEl.textContent || '0') + 1;
        }
        if (pieChartInstance && pieChartInstance.data && pieChartInstance.data.datasets[0]) {
            const arr = pieChartInstance.data.datasets[0].data;
            arr[0] = (arr[0] || 0) + 1;
            pieChartInstance.update('none');
        }
        scheduleLeaderboardUpdate(3500);
    }
});

// Real-time Event: General Chat Stream
socket.on('chat_stream_message', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        appendLiveChatItem(data);
    }
});

// Real-time Event: Active Chatters Updated
socket.on('active_chatters_updated', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        scheduleLeaderboardUpdate(2000);
    }
    scheduleNetworkStatsUpdate(5000);
});

// Real-time Event: Stats Reset
socket.on('stats_reset', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        loadOverview();
        loadLeaderboard();
        if (typeof loadStreamReports === 'function') {
            loadStreamReports();
        }
    }
});

// Real-time Event: Stream Live / Offline Status Changed
socket.on('stream_status_changed', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        const badge = document.getElementById('liveStatusBadge');
        const txt = document.getElementById('liveStatusText');
        if (data.is_live) {
            if (badge) {
                badge.className = 'absolute -bottom-2 right-2 bg-red-600 text-white font-extrabold text-[10px] uppercase px-2 py-0.5 rounded-md border-2 border-[#07090a] flex items-center gap-1 live-pulse';
                badge.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-white"></span> مباشر الآن';
            }
            if (txt) {
                txt.textContent = 'مباشر الآن';
                txt.className = 'text-xs font-bold text-red-500';
            }
        } else {
            if (badge) {
                badge.className = 'absolute -bottom-2 right-2 bg-gray-700 text-gray-300 font-extrabold text-[10px] uppercase px-2 py-0.5 rounded-md border-2 border-[#07090a] flex items-center gap-1';
                badge.innerHTML = '<span class="w-1.5 h-1.5 rounded-full bg-gray-400"></span> غير متصل (أوفلاين)';
            }
            if (txt) {
                txt.textContent = 'أوفلاين';
                txt.className = 'text-xs font-bold text-gray-400';
            }
        }
        loadOverview();
        if (typeof loadStreamReports === 'function') {
            loadStreamReports();
        }
    }
});

// On Document Ready
document.addEventListener('DOMContentLoaded', () => {
    initCharts();
    checkUserSession();
    loadNetworkStats();

    // Auto-check view routing
    const params = new URLSearchParams(window.location.search);
    if (window.location.pathname.includes('dashboard') || window.location.pathname.includes('live') || params.get('view') === 'dashboard') {
        switchView('dashboard');
    } else {
        loadChannels();
    }

    // Close modal when clicking outside of it (backdrop click)
    ['addChannelModal', 'channelSettingsModal', 'modProfileModal', 'loginModal', 'registerModal', 'discordModal'].forEach(id => {
        const modal = document.getElementById(id);
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeModal(id);
                }
            });
        }
    });

    // Close modal on ESC key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal('addChannelModal');
            closeModal('channelSettingsModal');
            closeModal('modProfileModal');
            closeModal('loginModal');
            closeModal('registerModal');
            closeModal('discordModal');
        }
    });
});

/**
 * Check User Authentication Session
 */
function checkUserSession() {
    const raw = localStorage.getItem('kickmod_user');
    const guestBox = document.getElementById('authGuestButtons');
    const userBox = document.getElementById('authUserMenu');

    if (!raw) {
        if (guestBox) guestBox.classList.remove('hidden');
        if (userBox) userBox.classList.add('hidden');
        return;
    }

    try {
        const user = JSON.parse(raw);
        if (guestBox) guestBox.classList.add('hidden');
        if (userBox) userBox.classList.remove('hidden');

        const nameEl = document.getElementById('userDisplayName');
        if (nameEl) nameEl.textContent = user.discord_username || user.username;

        const avatarEl = document.getElementById('userAvatarImg');
        if (avatarEl && user.discord_avatar) {
            avatarEl.src = user.discord_avatar;
        }
    } catch (e) {
        localStorage.removeItem('kickmod_user');
    }
}

/**
 * User Login Handler
 */
async function handleLoginSubmit(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errEl = document.getElementById('loginError');
    const btn = document.getElementById('loginSubmitBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.textContent = 'جارٍ تسجيل الدخول...';

    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        localStorage.setItem('kickmod_user', JSON.stringify(data.user));
        checkUserSession();
        closeModal('loginModal');
        showToast(`مرحباً بك مجدداً @${data.user.username}!`, 'success');
        await checkDashboardAccess();
    } catch (err) {
        errEl.textContent = err.message || 'فشل تسجيل الدخول';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.textContent = 'تسجيل الدخول';
    }
}

/**
 * User Registration Handler
 */
async function handleRegisterSubmit(e) {
    e.preventDefault();
    const username = document.getElementById('regUsername').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const errEl = document.getElementById('registerError');
    const btn = document.getElementById('registerSubmitBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.textContent = 'جارٍ إنشاء الحساب...';

    try {
        const res = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        localStorage.setItem('kickmod_user', JSON.stringify(data.user));
        checkUserSession();
        closeModal('registerModal');
        showToast(`تم إنشاء حسابك بنجاح @${data.user.username}!`, 'success');
        await checkDashboardAccess();
    } catch (err) {
        errEl.textContent = err.message || 'فشل إنشاء الحساب';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.textContent = 'إنشاء الحساب وبدء الاستخدام';
    }
}

/**
 * Discord Login / Connect Handler
 */
async function handleDiscordSubmit(e) {
    e.preventDefault();
    const discordTag = document.getElementById('discordTagInput').value.trim();
    const errEl = document.getElementById('discordError');
    const btn = document.getElementById('discordSubmitBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ الاتصال بديسكورد...';

    try {
        const res = await fetch('/api/auth/discord', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ discord_tag: discordTag })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        localStorage.setItem('kickmod_user', JSON.stringify(data.user));
        checkUserSession();
        closeModal('discordModal');
        showToast(`تم تسجيل الدخول بنجاح عبر ديسكورد @${data.user.discord_username}!`, 'success');
    } catch (err) {
        errEl.textContent = err.message || 'فشل الاتصال بحساب ديسكورد';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-brands fa-discord text-base"></i> <span>متابعة وتسجيل الدخول بحساب ديسكورد</span>';
    }
}

/**
 * Email OTP Handlers (Send & Verify)
 */
let otpCountdownTimer = null;
let currentOtpEmail = '';

function startOtpCountdown(durationSeconds = 600) {
    if (otpCountdownTimer) clearInterval(otpCountdownTimer);
    let remaining = durationSeconds;
    const cdEl = document.getElementById('otpCountdown');
    
    function updateDisplay() {
        const m = Math.floor(remaining / 60);
        const s = remaining % 60;
        if (cdEl) {
            cdEl.textContent = `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
        }
    }
    
    updateDisplay();
    otpCountdownTimer = setInterval(() => {
        remaining--;
        if (remaining <= 0) {
            clearInterval(otpCountdownTimer);
            if (cdEl) cdEl.textContent = 'منتهي الصلاحية';
        } else {
            updateDisplay();
        }
    }, 1000);
}

function resetOtpStep() {
    if (otpCountdownTimer) clearInterval(otpCountdownTimer);
    const reqForm = document.getElementById('otpRequestForm');
    const verForm = document.getElementById('otpVerifyForm');
    if (reqForm) reqForm.classList.remove('hidden');
    if (verForm) verForm.classList.add('hidden');
    const sendErr = document.getElementById('otpSendError');
    const sendSucc = document.getElementById('otpSendSuccess');
    const verErr = document.getElementById('otpVerifyError');
    if (sendErr) sendErr.classList.add('hidden');
    if (sendSucc) sendSucc.classList.add('hidden');
    if (verErr) verErr.classList.add('hidden');
    const codeInput = document.getElementById('otpCodeInput');
    if (codeInput) codeInput.value = '';
}

async function handleSendOtp(e) {
    if (e && e.preventDefault) e.preventDefault();
    const emailInput = document.getElementById('otpEmailInput');
    const email = emailInput ? emailInput.value.trim().toLowerCase() : '';
    const errEl = document.getElementById('otpSendError');
    const succEl = document.getElementById('otpSendSuccess');
    const btn = document.getElementById('otpSendBtn');

    if (errEl) errEl.classList.add('hidden');
    if (succEl) succEl.classList.add('hidden');

    if (!email || !email.includes('@')) {
        if (errEl) {
            errEl.textContent = 'يرجى إدخال عنوان بريد إلكتروني صحيح.';
            errEl.classList.remove('hidden');
        }
        return;
    }

    currentOtpEmail = email;
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ إرسال كود التحقق...';
    }

    try {
        const res = await fetch('/api/auth/otp/send', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error || 'فشل إرسال كود التحقق.');
        }

        // Show step 2
        document.getElementById('otpRequestForm').classList.add('hidden');
        document.getElementById('otpVerifyForm').classList.remove('hidden');
        startOtpCountdown(600);

        showToast(data.message || 'تم إرسال كود التحقق إلى بريدك الإلكتروني بنجاح!', 'success');
        document.getElementById('otpCodeInput').focus();
    } catch (err) {
        if (errEl) {
            errEl.textContent = err.message;
            errEl.classList.remove('hidden');
        }
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M12 19l9 2-9-18-9 18 9-2zm0 0v-8"></path>
                </svg>
                <span>إرسال كود التحقق</span>
            `;
        }
    }
}

async function handleVerifyOtp(e) {
    e.preventDefault();
    const code = document.getElementById('otpCodeInput').value.trim();
    const errEl = document.getElementById('otpVerifyError');
    const btn = document.getElementById('otpVerifyBtn');

    if (errEl) errEl.classList.add('hidden');

    if (!code || code.length < 6) {
        if (errEl) {
            errEl.textContent = 'يرجى إدخال رمز التحقق المكون من 6 أرقام.';
            errEl.classList.remove('hidden');
        }
        return;
    }

    if (btn) {
        btn.disabled = true;
        btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ التحقق وتسجيل الدخول...';
    }

    try {
        const res = await fetch('/api/auth/otp/verify', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ email: currentOtpEmail, otp_code: code })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error || 'رمز التحقق غير صحيح أو انتهت صلاحيته.');
        }

        localStorage.setItem('kickmod_user', JSON.stringify(data.user));
        checkUserSession();
        closeModal('otpModal');
        resetOtpStep();
        showToast(`مرحباً بك @${data.user.username}! تم تسجيل الدخول بنجاح.`, 'success');
        await checkDashboardAccess();
    } catch (err) {
        if (errEl) {
            errEl.textContent = err.message;
            errEl.classList.remove('hidden');
        }
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.textContent = 'تأكيد وتسجيل الدخول';
        }
    }
}

/**
 * User Logout
 */
async function logoutUser() {
    try {
        await fetch('/api/auth/logout', { method: 'POST', credentials: 'include' });
    } catch (e) {
        console.error(e);
    }
    localStorage.removeItem('kickmod_user');
    checkUserSession();
    showToast('تم تسجيل الخروج بنجاح', 'info');
    if (currentView === 'dashboard') {
        await checkDashboardAccess();
    }
}

/**
 * Quick Channel Form Submission (Landing Page)
 */
async function submitQuickChannel(e) {
    e.preventDefault();
    const slugInput = document.getElementById('quickSlugInput');
    const webhookInput = document.getElementById('quickWebhookInput');
    const btn = document.getElementById('quickChannelBtn');
    const errEl = document.getElementById('quickChannelError');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ التحقق من كيك وبدء الرصد...';

    const slug = slugInput.value.trim().replace(/[^a-zA-Z0-9_-]/g, '').toLowerCase();

    try {
        const res = await fetch('/api/channels', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                slug,
                discord_webhook: webhookInput.value.trim()
            })
        });

        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        showToast(`تمت إضافة القناة @${data.channel.slug} وبدء الرصد 24/7!`, 'success');
        slugInput.value = '';
        webhookInput.value = '';

        await loadChannels(data.channel.id);
        switchView('dashboard');
    } catch (err) {
        errEl.textContent = err.message || 'حدث خطأ أثناء إضافة القناة';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `
            <span>تفعيل المراقبة اللحظية للقناة (24/7)</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
            </svg>
        `;
    }
}

/**
 * Fill channel slug from quick suggestion chips
 */
function setQuickChannel(slug) {
    const input = document.getElementById('quickSlugInput') || document.getElementById('landingSlugInput');
    if (input) {
        input.value = slug;
        input.focus();
    }
}

/**
 * Switch View: Landing (الرئيسية والتسجيل) vs Dashboard (لوحة المراقبة)
 */
async function switchView(viewName) {
    currentView = viewName;
    const landingEl = document.getElementById('landingView');
    const authReqEl = document.getElementById('authRequiredView');
    const setupEl = document.getElementById('setupChannelView');
    const dashboardEl = document.getElementById('dashboardView');
    const btnLanding = document.getElementById('navBtnLanding');
    const btnDashboard = document.getElementById('navBtnDashboard');
    const headerChannelBox = document.getElementById('headerChannelBox');
    const resyncBtn = document.getElementById('resyncBtn');

    if (viewName === 'landing') {
        if (landingEl) landingEl.classList.remove('hidden');
        if (authReqEl) authReqEl.classList.add('hidden');
        if (setupEl) setupEl.classList.add('hidden');
        if (dashboardEl) dashboardEl.classList.add('hidden');

        if (btnLanding) btnLanding.className = 'px-4 py-2 rounded-xl font-black bg-gradient-to-r from-[#53fc18] to-[#34d320] text-black shadow-[0_2px_12px_rgba(83,252,24,0.35)] transition flex items-center gap-1.5';
        if (btnDashboard) btnDashboard.className = 'px-4 py-2 rounded-xl font-bold text-gray-400 hover:text-white hover:bg-white/5 transition flex items-center gap-1.5';

        if (headerChannelBox) headerChannelBox.classList.add('hidden');
        if (resyncBtn) resyncBtn.classList.add('hidden');

        if (window.kmHero3D && typeof window.kmHero3D.resume === 'function') {
            window.kmHero3D.resume();
        }
        loadNetworkStats();
    } else {
        if (btnDashboard) btnDashboard.className = 'px-4 py-2 rounded-xl font-black bg-gradient-to-r from-[#53fc18] to-[#34d320] text-black shadow-[0_2px_12px_rgba(83,252,24,0.35)] transition flex items-center gap-1.5';
        if (btnLanding) btnLanding.className = 'px-4 py-2 rounded-xl font-bold text-gray-400 hover:text-white hover:bg-white/5 transition flex items-center gap-1.5';

        if (window.kmHero3D && typeof window.kmHero3D.pause === 'function') {
            window.kmHero3D.pause();
        }

        // Verify Authentication and Channel Ownership before displaying Dashboard
        await checkDashboardAccess();
    }
}

/**
 * Check User Session & Channel Ownership for Dashboard View
 */
async function checkDashboardAccess() {
    const landingEl = document.getElementById('landingView');
    const authReqEl = document.getElementById('authRequiredView');
    const setupEl = document.getElementById('setupChannelView');
    const dashboardEl = document.getElementById('dashboardView');
    const headerChannelBox = document.getElementById('headerChannelBox');
    const resyncBtn = document.getElementById('resyncBtn');

    if (landingEl) landingEl.classList.add('hidden');

    try {
        const res = await fetch('/api/auth/me', { credentials: 'include' });
        const data = await res.json();

        // 1. User NOT authenticated -> Require Login
        if (!data.authenticated || !data.user) {
            if (authReqEl) authReqEl.classList.remove('hidden');
            if (setupEl) setupEl.classList.add('hidden');
            if (dashboardEl) dashboardEl.classList.add('hidden');
            if (headerChannelBox) headerChannelBox.classList.add('hidden');
            if (resyncBtn) resyncBtn.classList.add('hidden');
            return;
        }

        // 2. User authenticated -> update navbar session
        localStorage.setItem('kickmod_user', JSON.stringify(data.user));
        checkUserSession();

        // 3. User authenticated but has NO channel -> Show "Add Channel" onboarding
        if (!data.channel) {
            if (authReqEl) authReqEl.classList.add('hidden');
            if (setupEl) setupEl.classList.remove('hidden');
            if (dashboardEl) dashboardEl.classList.add('hidden');
            if (headerChannelBox) headerChannelBox.classList.add('hidden');
            if (resyncBtn) resyncBtn.classList.add('hidden');
            return;
        }

        // 4. User has their channel -> Open the Big Dashboard!
        if (authReqEl) authReqEl.classList.add('hidden');
        if (setupEl) setupEl.classList.add('hidden');
        if (dashboardEl) dashboardEl.classList.remove('hidden');
        if (resyncBtn) resyncBtn.classList.remove('hidden');

        // Lock channel to the user's single owned channel
        const select = document.getElementById('channelSelect');
        if (select) {
            select.innerHTML = `<option value="${data.channel.id}" data-slug="${data.channel.slug}" data-avatar="${data.channel.avatar_url || ''}" data-banner="${data.channel.banner_url || ''}" data-webhook="${data.channel.discord_webhook || ''}">${data.channel.name || data.channel.slug} (@${data.channel.slug})</option>`;
            select.value = data.channel.id;
        }
        if (headerChannelBox) headerChannelBox.classList.remove('hidden');

        currentChannelId = data.channel.id;
        currentChannelSlug = data.channel.slug;

        onChannelChanged();
    } catch (err) {
        console.error('Error checking dashboard access:', err);
    }
}

/**
 * Handle First Channel Onboarding Submission
 */
async function handleSetupChannelSubmit(e) {
    e.preventDefault();
    const kickInput = document.getElementById('setupKickInput').value.trim();
    const webhookInput = document.getElementById('setupWebhookInput').value.trim();
    const errEl = document.getElementById('setupChannelError');
    const btn = document.getElementById('setupChannelBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = `<span>جارٍ التفعيل والرصد السحابي...</span>`;

    try {
        const clean = kickInput.replace(/^https?:\/\/(www\.)?kick\.com\//, '').replace(/[^a-zA-Z0-9_-]/g, '');
        if (!clean) {
            throw new Error('يرجى إدخال اسم القناة بشكل صحيح.');
        }

        const res = await fetch('/api/channels', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include',
            body: JSON.stringify({ slug: clean, discord_webhook: webhookInput })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        showToast(`تم ربط وتفعيل قناتك (@${data.channel.slug}) بنجاح!`, 'success');
        await checkDashboardAccess();
    } catch (err) {
        errEl.textContent = err.message || 'فشل تفعيل القناة';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `<span>تفعيل القناة ودخول لوحة التحكم (24/7)</span>`;
    }
}

/**
 * Load Global Network Stats for Landing Page
 */
async function loadNetworkStats() {
    try {
        const res = await fetch('/api/network/stats');
        const data = await res.json();
        if (data.success && data.stats) {
            const s = data.stats;
            const chEl = document.getElementById('netChannelsCount');
            const modsEl = document.getElementById('netModsCount');
            const actEl = document.getElementById('netActionsCount');

            if (chEl) chEl.textContent = s.total_channels || 0;
            if (modsEl) modsEl.textContent = s.currently_online_mods || s.total_human_mods || 0;
            if (actEl) actEl.textContent = s.total_actions_recorded || 0;
        }
    } catch (e) {
        console.warn('Network stats fetch error:', e.message);
    }
}

/**
 * Handle Landing Channel Registration
 */
async function submitLandingRegister(e) {
    e.preventDefault();
    const slugInput = document.getElementById('landingSlugInput');
    const webhookInput = document.getElementById('landingWebhookInput');
    const btn = document.getElementById('landingRegisterBtn');
    const errEl = document.getElementById('landingRegisterError');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ التحقق من كيك وبدء الرصد...';

    const slug = slugInput.value.trim().replace(/[^a-zA-Z0-9_-]/g, '').toLowerCase();

    try {
        const res = await fetch('/api/channels', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                slug,
                discord_webhook: webhookInput.value.trim()
            })
        });

        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        showToast(`تم تسجيل القناة @${data.channel.slug} وبدء الرصد 24/7 بنجاح!`, 'success');
        slugInput.value = '';
        webhookInput.value = '';

        await loadChannels(data.channel.id);
        switchView('dashboard');
    } catch (err) {
        errEl.textContent = err.message || 'حدث خطأ أثناء تسجيل القناة';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `
            <span>تفعيل المراقبة الفورية (24/7)</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
            </svg>
        `;
    }
}

/**
 * Initialize Chart.js
 */
function initCharts() {
    // 1. Actions Bar Chart
    const ctx1 = document.getElementById('actionsChart').getContext('2d');
    actionsChartInstance = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'عمليات الحظر (Bans)',
                    data: [],
                    backgroundColor: 'rgba(239, 68, 68, 0.85)',
                    borderRadius: 6
                },
                {
                    label: 'عمليات الكتم (Timeouts)',
                    data: [],
                    backgroundColor: 'rgba(245, 158, 11, 0.85)',
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#9ca3af', font: { family: 'Cairo', size: 11 } }
                }
            },
            scales: {
                x: {
                    grid: { color: '#1e2428' },
                    ticks: { color: '#9ca3af', font: { size: 10 } }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: '#1e2428' },
                    ticks: { color: '#9ca3af', stepSize: 1, font: { size: 10 } }
                }
            }
        }
    });

    // 2. Task Distribution Doughnut Chart
    const ctx2 = document.getElementById('taskPieChart').getContext('2d');
    pieChartInstance = new Chart(ctx2, {
        type: 'doughnut',
        data: {
            labels: ['رسائل المشرفين', 'عمليات الكتم', 'عمليات الحظر'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: [
                    'rgba(83, 252, 24, 0.85)',
                    'rgba(245, 158, 11, 0.85)',
                    'rgba(239, 68, 68, 0.85)'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#9ca3af', font: { family: 'Cairo', size: 11 } }
                }
            },
            cutout: '68%'
        }
    });
}

/**
 * Load Monitored Channels into Dropdown
 */
async function loadChannels(selectChannelId = null) {
    try {
        const res = await fetch('/api/channels');
        const data = await res.json();

        const select = document.getElementById('channelSelect');
        select.innerHTML = '';

        if (!data.channels || data.channels.length === 0) {
            select.innerHTML = '<option value="">لا توجد قنوات مسجلة</option>';
            document.getElementById('currentChannelName').textContent = 'أضف أول قناة للمراقبة';
            return;
        }

        data.channels.forEach(ch => {
            const opt = document.createElement('option');
            opt.value = ch.id;
            opt.textContent = `${ch.name} (@${ch.slug})`;
            opt.dataset.slug = ch.slug;
            opt.dataset.avatar = ch.avatar_url;
            opt.dataset.banner = ch.banner_url || '';
            opt.dataset.webhook = ch.discord_webhook || '';
            select.appendChild(opt);
        });

        // Set selected channel (prefer selectChannelId or first available channel)
        if (selectChannelId) {
            select.value = selectChannelId;
        } else if (select.options.length > 0) {
            select.selectedIndex = 0;
        }

        currentChannelId = select.value;
        onChannelChanged();
    } catch (err) {
        console.error('Failed to load channels:', err);
    }
}

// Channel Dropdown Change Listener
document.getElementById('channelSelect').addEventListener('change', (e) => {
    currentChannelId = e.target.value;
    onChannelChanged();
});

/**
 * Updates UI and fetches data when channel changes
 */
function onChannelChanged() {
    const select = document.getElementById('channelSelect');
    const selectedOption = select.options[select.selectedIndex];
    if (!selectedOption || !selectedOption.value) return;

    currentChannelId = selectedOption.value;
    currentChannelSlug = selectedOption.dataset.slug;

    // Update Hero Banner & Profile Info
    const avatarUrl = selectedOption.dataset.avatar || 'https://kick.com/favicon.ico';
    const bannerUrl = selectedOption.dataset.banner;

    document.getElementById('currentChannelAvatar').src = avatarUrl;
    document.getElementById('currentChannelName').textContent = selectedOption.textContent.split(' (')[0];
    document.getElementById('currentChannelLink').href = `https://kick.com/${currentChannelSlug}`;
    document.getElementById('currentChannelLink').querySelector('span').textContent = `kick.com/${currentChannelSlug}`;
    document.getElementById('currentChannelMeta').textContent = `رصد مباشر وشامل لمشرفي القناة 24/7`;

    const bannerBg = document.getElementById('channelBannerBg');
    if (bannerBg) {
        if (bannerUrl) {
            bannerBg.style.backgroundImage = `url('${bannerUrl}')`;
        } else {
            bannerBg.style.backgroundImage = `linear-gradient(to right, #131719, #1a2226)`;
        }
    }

    // Reset live feed
    document.getElementById('liveFeedContainer').innerHTML = `
        <div class="text-center py-10 text-gray-500 text-xs">
            <svg class="w-8 h-8 text-[#53fc18] mx-auto mb-2 opacity-60 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
            </svg>
            متصل بقناة ${currentChannelSlug}، بانتظار إجراءات الإشراف...
        </div>
    `;

    // Fetch Overview, Leaderboard, Audit & Best Mods
    loadOverview();
    loadLeaderboard();
    loadBestMods();
    loadAuditLogs();
}

let currentStatsScope = 'live';
let latestOverviewData = null;

function setStatsScope(scope) {
    currentStatsScope = scope; // 'live' | 'month' | 'all'

    const activeCls = 'px-3 py-1.5 rounded-lg font-black bg-[#53fc18] text-black transition flex items-center gap-1.5 shadow-sm';
    const inactiveCls = 'px-3 py-1.5 rounded-lg font-medium text-gray-400 hover:text-white transition flex items-center gap-1.5';

    // Top Overview Scope Buttons
    const btnLive = document.getElementById('scopeBtnLive');
    const btnMonth = document.getElementById('scopeBtnMonth');
    const btnAll = document.getElementById('scopeBtnAll');

    if (btnLive) btnLive.className = scope === 'live' ? activeCls : inactiveCls;
    if (btnMonth) btnMonth.className = scope === 'month' ? activeCls : inactiveCls;
    if (btnAll) btnAll.className = scope === 'all' ? activeCls : inactiveCls;

    // Leaderboard Table Scope Buttons
    const tabLive = document.getElementById('tabScopeBtnLive');
    const tabMonth = document.getElementById('tabScopeBtnMonth');
    const tabAll = document.getElementById('tabScopeBtnAll');

    if (tabLive) tabLive.className = scope === 'live' ? activeCls : inactiveCls;
    if (tabMonth) tabMonth.className = scope === 'month' ? activeCls : inactiveCls;
    if (tabAll) tabAll.className = scope === 'all' ? activeCls : inactiveCls;

    // Scope Badge on Table Header
    const badge = document.getElementById('leaderboardScopeBadge');
    if (badge) {
        if (scope === 'live') {
            badge.className = 'inline-flex items-center gap-1.5 text-xs text-[#53fc18] bg-[#53fc18]/10 px-2.5 py-1 rounded-full border border-[#53fc18]/30 font-bold';
            badge.innerHTML = '<span class="w-2 h-2 rounded-full bg-[#53fc18] live-pulse"></span>اللايف الواحد (Live)';
        } else if (scope === 'month') {
            badge.className = 'inline-flex items-center gap-1.5 text-xs text-cyan-400 bg-cyan-400/10 px-2.5 py-1 rounded-full border border-cyan-400/30 font-bold';
            badge.innerHTML = '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z"></path></svg>لوحة الشهر كله (آخر 30 يوم)';
        } else {
            badge.className = 'inline-flex items-center gap-1.5 text-xs text-amber-400 bg-amber-400/10 px-2.5 py-1 rounded-full border border-amber-400/30 font-bold';
            badge.innerHTML = '<svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path></svg>لوحة الوقت كله (All-Time)';
        }
    }

    renderOverviewScope();
    loadLeaderboard();
}

function renderOverviewScope() {
    if (!latestOverviewData) return;
    const d = latestOverviewData;
    if (currentStatsScope === 'live' && d.live_stats && d.live_stats.is_active) {
        const l = d.live_stats;
        document.getElementById('statTotalBans').textContent = l.bans || 0;
        document.getElementById('statTotalTimeouts').textContent = l.timeouts || 0;
        document.getElementById('statModMessages').textContent = l.messages || 0;
        document.getElementById('statTotalMods').textContent = l.active_mods || 0;
        document.getElementById('statActiveToday').textContent = `${l.duration_minutes || 1} دقيقة بث مباشر`;
    } else if (currentStatsScope === 'month') {
        const m = d.month_stats || {};
        document.getElementById('statTotalBans').textContent = m.bans || 0;
        document.getElementById('statTotalTimeouts').textContent = m.timeouts || 0;
        document.getElementById('statModMessages').textContent = m.messages || 0;
        document.getElementById('statTotalMods').textContent = m.active_mods || 0;
        document.getElementById('statActiveToday').textContent = `إجمالي إحصائيات آخر 30 يوماً`;
    } else {
        const s = d.stats || d.all_time || {};
        document.getElementById('statTotalBans').textContent = s.total_bans || 0;
        document.getElementById('statTotalTimeouts').textContent = s.total_timeouts || 0;
        document.getElementById('statModMessages').textContent = s.total_mod_messages || 0;
        document.getElementById('statTotalMods').textContent = s.total_moderators || 0;
        document.getElementById('statActiveToday').textContent = `${s.active_mods_today || 0} متفاعل اليوم`;
    }
}

async function confirmResetStats() {
    if (!currentChannelId) {
        alert('يرجى اختيار قناة أولاً.');
        return;
    }

    const confirmed = confirm('هل أنت متأكد من تصفير وإعادة تعيين إحصائيات البث والمشرفين؟\nسيتم حفظ وأرشفة البث الحالي والبدء فوراً بجلسة رصد جديدة من الصفر.');
    if (!confirmed) return;

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/reset-stats`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            credentials: 'include'
        });
        const data = await res.json();
        if (!data.success) {
            alert(data.error || 'فشل تصفير الإحصائيات.');
            return;
        }

        // Refresh overview, leaderboard, and reports
        await loadOverview();
        await loadLeaderboard();
        await loadStreamReports();
        alert(data.message || 'تم تصفير الإحصائيات وبدء جلسة جديدة بنجاح!');
    } catch (err) {
        console.error('Reset error:', err);
        alert('حدث خطأ أثناء الاتصال بالسيرفر لتصفير الإحصائيات.');
    }
}

/**
 * Fetch Channel Overview Counters & Chart Data
 */
async function loadOverview() {
    if (!currentChannelId) return;

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/overview`);
        const data = await res.json();
        if (!data.success) return;

        latestOverviewData = data;
        renderOverviewScope();

        const s = data.stats || data.all_time || {};

        // Update Bar Chart
        const labels = (data.dailyActivity || []).map(d => d.date);
        const bansData = (data.dailyActivity || []).map(d => d.bans);
        const timeoutsData = (data.dailyActivity || []).map(d => d.timeouts);

        if (actionsChartInstance) {
            actionsChartInstance.data.labels = labels.length ? labels : ['اليوم'];
            actionsChartInstance.data.datasets[0].data = bansData.length ? bansData : [s.total_bans || 0];
            actionsChartInstance.data.datasets[1].data = timeoutsData.length ? timeoutsData : [s.total_timeouts || 0];
            actionsChartInstance.update();
        }

        // Update Doughnut Chart (Tasks distribution)
        if (pieChartInstance) {
            pieChartInstance.data.datasets[0].data = [
                s.total_mod_messages || 0,
                s.total_timeouts || 0,
                s.total_bans || 0
            ];
            pieChartInstance.update();
        }
    } catch (err) {
        console.error('Failed to load overview:', err);
    }
}

/**
 * Format Active Duration in Accurate Arabic with Live Seconds Ticker Support
 */
function formatActiveDuration(seconds) {
    if (!seconds || seconds <= 0) return '0 ثانية';
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;

    if (hrs > 0) {
        return `${hrs} ساعة و ${mins} د و ${secs} ث`;
    }
    if (mins > 0) {
        return `${mins} دقيقة و ${secs} ثانية`;
    }
    return `${secs} ثانية`;
}

/**
 * Render Attendance Cell with Live Pulsing Visual Badge
 */
function renderAttendanceCell(seconds, isOnline) {
    const formatted = formatActiveDuration(seconds);
    if (currentStatsScope === 'live' && isOnline) {
        return `
            <span class="inline-flex items-center gap-2">
                <span class="relative flex h-2 w-2">
                    <span class="animate-ping absolute inline-flex h-full w-full rounded-full bg-[#53fc18] opacity-75"></span>
                    <span class="relative inline-flex rounded-full h-2 w-2 bg-[#53fc18]"></span>
                </span>
                <span class="live-active-text text-[#53fc18] font-mono tracking-wider font-bold">${formatted}</span>
                <span class="text-[9px] bg-[#53fc18]/15 text-[#53fc18] border border-[#53fc18]/30 px-1 py-0.5 rounded font-black tracking-wider uppercase">LIVE</span>
            </span>
        `;
    }
    return `<span class="${seconds > 0 ? 'text-[#53fc18]' : 'text-gray-400'} font-mono font-bold">${formatted}</span>`;
}

/**
 * Live 1-Second Attendance Ticker for Online Moderators
 */
let liveAttendanceTicker = null;
function startLiveAttendanceTicker() {
    if (liveAttendanceTicker) clearInterval(liveAttendanceTicker);
    if (currentStatsScope !== 'live') return;
    liveAttendanceTicker = setInterval(() => {
        const liveCells = document.querySelectorAll('.live-mod-duration[data-online="1"]');
        liveCells.forEach(cell => {
            let secs = parseInt(cell.getAttribute('data-seconds'), 10) || 0;
            secs += 1;
            cell.setAttribute('data-seconds', secs);
            const textSpan = cell.querySelector('.live-active-text');
            if (textSpan) {
                textSpan.textContent = formatActiveDuration(secs);
            } else {
                cell.innerHTML = renderAttendanceCell(secs, true);
            }
        });

        // Also tick MVP time in header card if MVP is online
        const mvpScoreEl = document.getElementById('mvpScore');
        if (mvpScoreEl && mvpScoreEl.dataset.online === '1') {
            let mvpSecs = (parseInt(mvpScoreEl.dataset.seconds, 10) || 0) + 1;
            mvpScoreEl.dataset.seconds = mvpSecs;
            const pts = mvpScoreEl.dataset.points || '0';
            mvpScoreEl.textContent = `${pts} نقطة • ${formatActiveDuration(mvpSecs)}`;
        }
    }, 1000);
}

/**
 * Filter Mode (Human Only vs All including Bots)
 */
function setModFilter(type) {
    currentModFilter = type;
    const btnHuman = document.getElementById('filterBtnHuman');
    const btnAll = document.getElementById('filterBtnAll');

    if (type === 'human') {
        btnHuman.className = 'px-3 py-1 rounded-lg font-bold bg-[#53fc18] text-black transition';
        btnAll.className = 'px-3 py-1 rounded-lg font-medium text-gray-400 hover:text-white transition';
    } else {
        btnAll.className = 'px-3 py-1 rounded-lg font-bold bg-[#53fc18] text-black transition';
        btnHuman.className = 'px-3 py-1 rounded-lg font-medium text-gray-400 hover:text-white transition';
    }

    filterLeaderboard();
}

/**
 * Fetch and Render Moderators Leaderboard
 */
async function loadLeaderboard() {
    if (!currentChannelId) return;

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/leaderboard?scope=${currentStatsScope}`);
        const data = await res.json();
        if (!data.success) return;

        allModeratorsData = data.moderators || [];
        filterLeaderboard();
    } catch (err) {
        console.error('Failed to load leaderboard:', err);
    }
}

let filterDebounceTimer = null;
function filterLeaderboard() {
    clearTimeout(filterDebounceTimer);
    filterDebounceTimer = setTimeout(() => {
        const q = (document.getElementById('searchModInput')?.value || '').trim().toLowerCase();

        let filtered = allModeratorsData;
        if (currentModFilter === 'human') {
            filtered = filtered.filter(m => !m.is_bot);
        }

        if (q) {
            filtered = filtered.filter(m => m.username.toLowerCase().includes(q));
        }

        renderLeaderboard(filtered);
    }, 120);
}

function renderLeaderboard(moderators) {
    const tbody = document.getElementById('leaderboardBody');
    if (!moderators.length) {
        tbody.innerHTML = `<tr><td colspan="9" class="text-center py-10 text-gray-500">لا يوجد مشرفين يطابقون هذا الفلتر حالياً.</td></tr>`;
        return;
    }

    let html = '';
    moderators.forEach((mod, idx) => {
        let rankBadge = `<span class="font-bold text-gray-400">#${idx + 1}</span>`;
        if (idx === 0) {
            rankBadge = `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-400/20 text-amber-400 font-extrabold text-xs border border-amber-400/50">1</span>`;
        } else if (idx === 1) {
            rankBadge = `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-gray-300/20 text-gray-300 font-extrabold text-xs border border-gray-400/50">2</span>`;
        } else if (idx === 2) {
            rankBadge = `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-700/20 text-amber-600 font-extrabold text-xs border border-amber-700/50">3</span>`;
        }

        const lastSeen = mod.last_seen ? formatAppDate(mod.last_seen, { hour: '2-digit', minute: '2-digit' }) : 'غير محدد';
        const activeTimeStr = formatActiveDuration(mod.total_active_seconds);
        const onlineIndicator = mod.is_online
            ? `<span class="w-2 h-2 rounded-full bg-[#53fc18] live-pulse inline-block" title="متواجد حالياً"></span>`
            : `<span class="w-2 h-2 rounded-full bg-gray-600 inline-block" title="غير متصل"></span>`;

        const botBadge = mod.is_bot
            ? `<span class="text-[9px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-1.5 py-0.2 rounded font-mono">BOT</span>`
            : `<span class="text-[9px] bg-[#53fc18]/10 text-[#53fc18] border border-[#53fc18]/30 px-1.5 py-0.2 rounded">مشرف</span>`;

        const safeUsername = encodeURIComponent(mod.username);
        const avatarHtml = mod.avatar_url
            ? `<img src="${mod.avatar_url}" alt="${mod.username}" class="w-8 h-8 rounded-lg object-cover bg-black border border-[#2a3439]" onerror="this.onerror=null; this.src='https://kick.com/favicon.ico';">`
            : `<div class="w-8 h-8 rounded-lg bg-black border border-[#2a3439] flex items-center justify-center font-bold text-xs text-[#53fc18]">${mod.username.charAt(0).toUpperCase()}</div>`;

        html += `
            <tr class="hover:bg-[#161c1f] transition">
                <td class="px-6 py-4">${rankBadge}</td>
                <td class="px-6 py-4">
                    <div class="flex items-center gap-3">
                        ${avatarHtml}
                        <div>
                            <div class="flex items-center gap-1.5">
                                ${onlineIndicator}
                                <span class="font-bold text-white">${mod.username}</span>
                                ${botBadge}
                            </div>
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4 font-semibold text-red-400">${mod.total_bans}</td>
                <td class="px-6 py-4 font-semibold text-amber-400">${mod.total_timeouts}</td>
                <td class="px-6 py-4 text-gray-300 font-mono">${mod.total_messages}</td>
                <td class="px-6 py-4 font-mono font-bold text-[#53fc18] live-mod-duration"
                    data-username="${mod.username}"
                    data-seconds="${mod.total_active_seconds || 0}"
                    data-online="${mod.is_online ? '1' : '0'}">
                    ${renderAttendanceCell(mod.total_active_seconds || 0, mod.is_online)}
                </td>
                <td class="px-6 py-4 whitespace-nowrap text-center">
                    <div class="inline-flex flex-row items-center justify-center gap-1.5 bg-[#53fc18]/10 text-[#53fc18] font-bold px-3 py-1 rounded-full text-xs border border-[#53fc18]/25" style="display: inline-flex !important; flex-direction: row !important; white-space: nowrap !important; min-width: 72px;">
                        <span class="font-mono text-sm leading-none">${mod.activity_score}</span>
                        <span class="text-[11px] font-sans leading-none">نقطة</span>
                    </div>
                </td>
                <td class="px-6 py-4 text-xs text-gray-400">${lastSeen}</td>
                <td class="px-6 py-4 text-center">
                    <button onclick="openModProfile('${safeUsername}')" class="text-xs bg-[#1a2024] hover:bg-[#252e34] border border-[#2a3439] text-gray-300 hover:text-white px-3 py-1.5 rounded-lg transition active:scale-95">
                        عرض السجل
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
    startLiveAttendanceTicker();
}

/**
 * Parse Kick Emotes into Real Animated Images
 */
function parseKickEmotes(text) {
    if (!text) return '';
    return text.replace(/\[emote:(\d+):([a-zA-Z0-9_-]+)\]/g, (match, id, name) => {
        return `<img src="https://files.kick.com/emotes/${id}/fullsize" alt="${name}" title="${name}" class="inline-block h-6 w-6 align-middle mx-0.5 object-contain hover:scale-125 transition-transform" loading="lazy">`;
    });
}

/**
 * Toggle between Mod Actions Feed and Live Chat Stream
 */
function toggleSideFeed(type) {
    const actionsBox = document.getElementById('liveFeedContainer');
    const chatBox = document.getElementById('liveChatContainer');
    const btnActions = document.getElementById('feedBtnActions');
    const btnChat = document.getElementById('feedBtnChat');

    if (type === 'actions') {
        actionsBox.classList.remove('hidden');
        chatBox.classList.add('hidden');
        btnActions.className = 'text-xs font-bold text-[#53fc18] bg-[#53fc18]/10 px-2.5 py-1 rounded-lg transition flex items-center gap-1.5';
        btnChat.className = 'text-xs font-medium text-gray-400 hover:text-white px-2.5 py-1 rounded-lg transition flex items-center gap-1';
    } else {
        actionsBox.classList.add('hidden');
        chatBox.classList.remove('hidden');
        btnChat.className = 'text-xs font-bold text-[#53fc18] bg-[#53fc18]/10 px-2.5 py-1 rounded-lg transition flex items-center gap-1';
        btnActions.className = 'text-xs font-medium text-gray-400 hover:text-white px-2.5 py-1 rounded-lg transition flex items-center gap-1.5';
    }
}

let liveChatCount = 0;
let liveChatQueue = [];
let liveChatFlushTimer = null;

function appendLiveChatItem(data) {
    liveChatCount++;
    const badgeEl = document.getElementById('chatCounterBadge');
    if (badgeEl) {
        badgeEl.textContent = `${liveChatCount} رسالة`;
    }

    const container = document.getElementById('liveChatContainer');
    // If live chat tab is hidden, skip all DOM creation to maintain peak performance
    if (!container || container.classList.contains('hidden')) {
        return;
    }

    liveChatQueue.push(data);
    if (!liveChatFlushTimer) {
        liveChatFlushTimer = setTimeout(() => {
            requestAnimationFrame(flushLiveChatQueue);
        }, 120);
    }
}

function flushLiveChatQueue() {
    liveChatFlushTimer = null;
    const container = document.getElementById('liveChatContainer');
    if (!container || liveChatQueue.length === 0) return;

    if (container.querySelector('.text-center')) {
        container.innerHTML = '';
    }

    const batch = liveChatQueue.splice(0, 5); // Take at most 5 items per frame
    const fragment = document.createDocumentFragment();

    batch.forEach(data => {
        const item = document.createElement('div');
        item.className = 'action-row-new p-2 rounded-lg bg-[#0b0e0f] border border-[#1e2428] flex items-start gap-2';

        let senderBadge = '';
        if (data.is_broadcaster) {
            senderBadge = '<span class="text-[9px] bg-red-500/20 text-red-400 border border-red-500/40 px-1 py-0.5 rounded font-bold">ستريمر</span>';
        } else if (data.is_bot) {
            senderBadge = '<span class="text-[9px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 px-1 py-0.5 rounded font-bold">BOT</span>';
        } else if (data.is_mod) {
            senderBadge = '<span class="text-[9px] bg-[#53fc18]/20 text-[#53fc18] border border-[#53fc18]/40 px-1 py-0.5 rounded font-bold">MOD</span>';
        }

        const parsedContent = parseKickEmotes(data.content);
        const senderColor = data.sender_color || '#e5e7eb';

        item.innerHTML = `
            <div class="flex-1 min-w-0">
                <div class="flex items-center gap-1.5 mb-0.5">
                    ${senderBadge}
                    <span class="font-bold text-[11px] truncate" style="color: ${senderColor}">${data.sender}:</span>
                </div>
                <p class="text-gray-200 text-xs break-words">${parsedContent}</p>
            </div>
            <span class="text-[9px] text-gray-600 font-mono mt-0.5">الآن</span>
        `;
        fragment.appendChild(item);
    });

    container.insertBefore(fragment, container.firstChild);

    while (container.children.length > 25) {
        container.removeChild(container.lastChild);
    }

    if (liveChatQueue.length > 0) {
        liveChatFlushTimer = setTimeout(() => {
            requestAnimationFrame(flushLiveChatQueue);
        }, 150);
    }
}

/**
 * Append Action to Real-Time Live Feed Card
 */
function appendLiveFeedItem(data) {
    const container = document.getElementById('liveFeedContainer');
    if (container.querySelector('svg')) {
        container.innerHTML = '';
    }

    let badgeClass = 'text-red-400 bg-red-500/10 border-red-500/20';
    let actionLabel = 'قام بحظر';

    if (data.action_type === 'timeout') {
        badgeClass = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
        actionLabel = `كتم (${data.duration_seconds >= 60 ? Math.round(data.duration_seconds / 60) + 'د' : data.duration_seconds + 'ث'})`;
    } else if (data.action_type === 'unban') {
        badgeClass = 'text-blue-400 bg-blue-500/10 border-blue-500/20';
        actionLabel = 'ألغى حظر';
    }

    const item = document.createElement('div');
    item.className = `action-row-new p-2.5 rounded-xl border bg-[#0b0e0f] ${badgeClass} text-xs flex items-center justify-between`;
    item.innerHTML = `
        <div class="flex items-center gap-2">
            <span><strong>${data.moderator}</strong> ${actionLabel} <strong>${data.target_user}</strong></span>
        </div>
        <span class="text-[10px] text-gray-500 font-mono">الآن</span>
    `;

    container.insertBefore(item, container.firstChild);

    if (container.children.length > 20) {
        container.removeChild(container.lastChild);
    }
}

function incrementCounter(actionType) {
    if (actionType === 'ban') {
        const el = document.getElementById('statTotalBans');
        if (el) el.textContent = parseInt(el.textContent || '0') + 1;
    } else if (actionType === 'timeout') {
        const el = document.getElementById('statTotalTimeouts');
        if (el) el.textContent = parseInt(el.textContent || '0') + 1;
    }
}

/**
 * Switch Tab (Leaderboard vs Audit Log vs Stream Reports)
 */
function switchTab(tabId) {
    document.getElementById('leaderboardTab').classList.add('hidden');
    document.getElementById('auditTab').classList.add('hidden');
    document.getElementById('reportsTab').classList.add('hidden');

    document.getElementById('tabBtnLeaderboard').className = 'pb-3 px-2 border-b-2 border-transparent text-gray-400 hover:text-white font-medium text-sm flex items-center gap-2 transition';
    document.getElementById('tabBtnAudit').className = 'pb-3 px-2 border-b-2 border-transparent text-gray-400 hover:text-white font-medium text-sm flex items-center gap-2 transition';
    document.getElementById('tabBtnReports').className = 'pb-3 px-2 border-b-2 border-transparent text-gray-400 hover:text-white font-medium text-sm flex items-center gap-2 transition';

    document.getElementById(tabId).classList.remove('hidden');

    if (tabId === 'leaderboardTab') {
        document.getElementById('tabBtnLeaderboard').className = 'pb-3 px-2 border-b-2 border-[#53fc18] text-[#53fc18] font-bold text-sm flex items-center gap-2 transition';
        loadLeaderboard();
        loadBestMods();
    } else if (tabId === 'auditTab') {
        document.getElementById('tabBtnAudit').className = 'pb-3 px-2 border-b-2 border-[#53fc18] text-[#53fc18] font-bold text-sm flex items-center gap-2 transition';
        loadAuditLogs();
    } else {
        document.getElementById('tabBtnReports').className = 'pb-3 px-2 border-b-2 border-[#53fc18] text-[#53fc18] font-bold text-sm flex items-center gap-2 transition';
        loadStreamReports();
    }
}

/**
 * Fetch and Render Best Moderators Showcase Cards
 */
async function loadBestMods() {
    if (!currentChannelId) return;
    try {
        const res = await fetch(`/api/channels/${currentChannelId}/best-mods`);
        const data = await res.json();
        if (!data.success) return;

        // 1. MVP
        if (data.mvp) {
            const mvpScoreEl = document.getElementById('mvpScore');
            const mvpSecs = data.mvp.total_active_seconds || 0;
            document.getElementById('mvpName').textContent = data.mvp.username;
            mvpScoreEl.textContent = `${data.mvp.activity_score} نقطة • ${formatActiveDuration(mvpSecs)}`;
            mvpScoreEl.dataset.seconds = mvpSecs;
            mvpScoreEl.dataset.online = data.mvp.is_online ? '1' : '0';
            mvpScoreEl.dataset.points = data.mvp.activity_score;
            if (data.mvp.avatar_url) document.getElementById('mvpAvatar').src = data.mvp.avatar_url;
        } else {
            document.getElementById('mvpName').textContent = 'جاري الرصد...';
            document.getElementById('mvpScore').textContent = 'بانتظار تفاعل المودز';
            document.getElementById('mvpScore').removeAttribute('data-online');
        }

        // 2. Enforcer
        if (data.enforcer) {
            document.getElementById('enforcerName').textContent = data.enforcer.username;
            document.getElementById('enforcerActions').textContent = `${data.enforcer.total_bans} حظر • ${data.enforcer.total_timeouts} كتم`;
            if (data.enforcer.avatar_url) document.getElementById('enforcerAvatar').src = data.enforcer.avatar_url;
        } else {
            document.getElementById('enforcerName').textContent = 'لا توجد إجراءات ردع';
            document.getElementById('enforcerActions').textContent = '0 حظر أو كتم';
        }

        // 3. Chatter
        if (data.chatter) {
            document.getElementById('chatterName').textContent = data.chatter.username;
            document.getElementById('chatterMsgs').textContent = `${data.chatter.total_messages} رسالة في الشات`;
            if (data.chatter.avatar_url) document.getElementById('chatterAvatar').src = data.chatter.avatar_url;
        } else {
            document.getElementById('chatterName').textContent = 'لا توجد رسائل بعد';
            document.getElementById('chatterMsgs').textContent = '0 رسالة';
        }

        // 4. Inactive Count
        document.getElementById('inactiveCount').textContent = data.inactive_count || 0;
    } catch (e) {
        console.error('Failed to load best mods:', e);
    }
}

/**
 * Fetch and Render Stream Reports with Analytics & Status
 */
async function loadStreamReports() {
    if (!currentChannelId) return;
    try {
        const res = await fetch(`/api/channels/${currentChannelId}/stream-reports`);
        const data = await res.json();
        const tbody = document.getElementById('streamReportsBody');
        if (!data.reports || !data.reports.length) {
            tbody.innerHTML = `<tr><td colspan="8" class="text-center py-10 text-gray-400">
                لا توجد تقارير بثوث سابقة. اضغط على زر "توليد تقرير تحليلي فوري" لإنشاء تحليل متقدم لحالة البث الحالي فوراً.
            </td></tr>`;
            return;
        }

        let html = '';
        data.reports.forEach(r => {
            const date = formatAppDate(r.started_at, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
            const isLive = !r.ended_at;
            const statusBadge = isLive
                ? `<span class="inline-flex items-center gap-1.5 text-[11px] font-bold bg-[#53fc18]/15 text-[#53fc18] border border-[#53fc18]/30 px-2.5 py-0.5 rounded-full"><span class="w-1.5 h-1.5 rounded-full bg-[#53fc18] live-pulse"></span>مباشر الآن</span>`
                : `<span class="text-[11px] font-bold bg-gray-500/15 text-gray-400 border border-gray-500/30 px-2.5 py-0.5 rounded-full">بث منتهي</span>`;

            html += `
                <tr class="hover:bg-[#161c1f] transition">
                    <td class="px-6 py-4 font-mono text-gray-300">${date}</td>
                    <td class="px-6 py-4">
                        <div class="font-bold text-white">${r.title || 'بث مباشر'}</div>
                        <div class="text-[11px] text-gray-500">${r.category || 'Kick Live'}</div>
                    </td>
                    <td class="px-6 py-4 text-xs font-mono font-bold text-[#53fc18]">${r.duration_minutes} دقيقة</td>
                    <td class="px-6 py-4 font-bold text-white">${r.active_mods_count} مشرفين</td>
                    <td class="px-6 py-4 font-semibold text-red-400 font-mono">${r.total_bans}</td>
                    <td class="px-6 py-4 font-semibold text-amber-400 font-mono">${r.total_timeouts}</td>
                    <td class="px-6 py-4">${statusBadge}</td>
                    <td class="px-6 py-4 text-center">
                        <button onclick="openStreamReportAnalytics(${r.id})" class="px-3.5 py-1.5 rounded-xl bg-[#53fc18]/15 hover:bg-[#53fc18]/25 text-[#53fc18] font-bold text-xs border border-[#53fc18]/30 transition flex items-center gap-1.5 active:scale-95 mx-auto">
                            <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                            </svg>
                            <span>عرض التحليل</span>
                        </button>
                    </td>
                </tr>
            `;
        });
        tbody.innerHTML = html;
    } catch (e) {
        console.error('Failed to load stream reports:', e);
    }
}

/**
 * Generate Instant Stream Analytics Report
 */
let currentAnalyticsReportId = null;

async function generateInstantReport() {
    if (!currentChannelId) return;
    const btn = document.getElementById('genReportBtn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="inline-block animate-spin mr-1">⌛</span> جاري توليد التقرير التحليلي...`;
    }

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/stream-reports/generate-current`, {
            method: 'POST'
        });
        const data = await res.json();
        if (!data.success || !data.analytics) {
            showToast(data.error || 'تعذر توليد التقرير التحليلي', 'error');
            return;
        }

        renderStreamAnalyticsModal(data.analytics);
        loadStreamReports(); // Refresh table in background
    } catch (e) {
        showToast('فشل الاتصال بالخادم لتوليد التقرير', 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `
                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 19v-6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2a2 2 0 002-2zm0 0V9a2 2 0 012-2h2a2 2 0 012 2v10m-6 0a2 2 0 002 2h2a2 2 0 002-2m0 0V5a2 2 0 012-2h2a2 2 0 012 2v14a2 2 0 01-2 2h-2a2 2 0 01-2-2z"></path>
                </svg>
                <span>توليد تقرير تحليلي فوري</span>
            `;
        }
    }
}

/**
 * Open Stream Analytics Report Details Modal
 */
async function openStreamReportAnalytics(reportId) {
    if (!currentChannelId || !reportId) return;
    try {
        const res = await fetch(`/api/channels/${currentChannelId}/stream-reports/${reportId}/analytics`);
        const data = await res.json();
        if (!data.success || !data.analytics) {
            showToast(data.error || 'تعذر جلب تفاصيل التقرير', 'error');
            return;
        }

        renderStreamAnalyticsModal(data.analytics);
    } catch (e) {
        showToast('حدث خطأ أثناء تحميل بيانات التقرير', 'error');
    }
}

/**
 * Render Data inside Stream Analytics Modal (Visual Shapes & Pure Vector SVGs - No Emojis)
 */
function renderStreamAnalyticsModal(analytics) {
    currentAnalyticsReportId = analytics.report.id;

    document.getElementById('reportModalTitle').textContent = analytics.report.title;
    const isLive = analytics.report.is_live;
    const statusBadge = document.getElementById('reportModalStatusBadge');
    if (statusBadge) {
        statusBadge.innerHTML = isLive
            ? `<span class="inline-flex items-center gap-1.5"><span class="w-1.5 h-1.5 rounded-full bg-[#53fc18] live-pulse"></span><span>مباشر الآن</span></span>`
            : `<span>بث مؤرشف</span>`;
        statusBadge.className = isLive
            ? 'text-xs px-2.5 py-0.5 rounded-full font-bold bg-[#53fc18]/15 text-[#53fc18] border border-[#53fc18]/30'
            : 'text-xs px-2.5 py-0.5 rounded-full font-bold bg-gray-500/15 text-gray-400 border border-gray-500/30';
    }

    const startDate = formatAppDate(analytics.report.started_at, {
        month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
    });
    document.getElementById('reportModalDate').textContent = `تاريخ بدء البث: ${startDate} | التصنيف: ${analytics.report.category}`;

    document.getElementById('reportDurationVal').textContent = analytics.summary.duration_formatted;
    document.getElementById('reportAttendanceRateVal').textContent = `${analytics.summary.attendance_rate}%`;
    document.getElementById('reportActionsVal').textContent = `${analytics.summary.total_actions} (${analytics.summary.total_bans} حظر • ${analytics.summary.total_timeouts} كتم)`;
    document.getElementById('reportMvpVal').textContent = analytics.summary.mvp_name ? `@${analytics.summary.mvp_name}` : 'لا يوجد تفاعل بعد';

    // 1. VISUAL SHAPE: Attendance Radial Gauge
    const rate = Math.max(0, Math.min(100, analytics.summary.attendance_rate || 0));
    const ring = document.getElementById('reportAttendanceRing');
    const ringText = document.getElementById('reportAttendanceRingText');
    if (ring) {
        // Circumference = 2 * PI * 40 = 251.2
        const offset = 251.2 - (251.2 * rate) / 100;
        ring.style.strokeDashoffset = offset;
    }
    if (ringText) ringText.textContent = `${rate}%`;
    const activeCount = analytics.summary.active_mods_count || 0;
    const totalCount = analytics.summary.total_mods_count || 0;
    const absentCount = Math.max(0, totalCount - activeCount);
    const activeCountEl = document.getElementById('reportActiveModsCountTxt');
    const absentCountEl = document.getElementById('reportAbsentModsCountTxt');
    if (activeCountEl) activeCountEl.textContent = activeCount;
    if (absentCountEl) absentCountEl.textContent = absentCount;

    // 2. VISUAL SHAPE: Enforcement Ratio Bar (Bans vs Timeouts)
    const bans = analytics.summary.total_bans || 0;
    const timeouts = analytics.summary.total_timeouts || 0;
    const totalActs = bans + timeouts;
    const bansPct = totalActs > 0 ? Math.round((bans / totalActs) * 100) : 50;
    const timeoutsPct = totalActs > 0 ? (100 - bansPct) : 50;
    const bansBar = document.getElementById('reportBansBar');
    const timeoutsBar = document.getElementById('reportTimeoutsBar');
    if (bansBar) bansBar.style.width = `${bansPct}%`;
    if (timeoutsBar) timeoutsBar.style.width = `${timeoutsPct}%`;
    const bansCountEl = document.getElementById('reportBansCountTxt');
    const timeoutsCountEl = document.getElementById('reportTimeoutsCountTxt');
    const ratioEl = document.getElementById('reportEnforcementRatioTxt');
    if (bansCountEl) bansCountEl.textContent = bans;
    if (timeoutsCountEl) timeoutsCountEl.textContent = timeouts;
    if (ratioEl) ratioEl.textContent = `${bans} حظر : ${timeouts} كتم`;

    // 3. VISUAL SHAPE: Stream Coverage Signal Indicator
    const covLabel = document.getElementById('reportCoverageQualityLabel');
    const covPct = document.getElementById('reportCoveragePercentTxt');
    if (covPct) covPct.textContent = `${rate}%`;
    for (let i = 1; i <= 4; i++) {
        const bar = document.getElementById(`covBar${i}`);
        if (bar) {
            const threshold = i * 25;
            if (rate >= threshold - 12) {
                bar.className = 'h-3 rounded-md bg-[#53fc18] shadow-[0_0_8px_rgba(83,252,24,0.3)] transition-all';
            } else {
                bar.className = 'h-3 rounded-md bg-[#1a2226] transition-all';
            }
        }
    }
    if (covLabel) {
        covLabel.textContent = rate >= 75 ? 'تغطية ممتازة' : (rate >= 50 ? 'تغطية مقبولة' : 'تغطية ضعيفة');
        covLabel.className = rate >= 75 ? 'text-[#53fc18] font-bold text-[11px]' : (rate >= 50 ? 'text-amber-400 font-bold text-[11px]' : 'text-red-400 font-bold text-[11px]');
    }

    // Team Rating Badge (No Emojis)
    const ratingTxt = document.getElementById('reportTeamRatingTxt');
    if (ratingTxt) {
        const cleanRating = (analytics.summary.team_rating || 'ممتاز').replace(/[\u{1F300}-\u{1F9FF}]/gu, '').trim();
        ratingTxt.textContent = cleanRating;
    }
    const ratingBadge = document.getElementById('reportTeamRatingBadge');
    if (ratingBadge) {
        ratingBadge.className = `text-xs px-3 py-1 rounded-full font-extrabold bg-[#53fc18]/20 ${analytics.summary.team_rating_color} border border-current flex items-center gap-1.5`;
    }

    // Insights List (Pure SVG icons)
    const insightsList = document.getElementById('reportInsightsList');
    if (insightsList) {
        insightsList.innerHTML = analytics.insights.map(txt => {
            const cleanTxt = txt.replace(/[\u{1F300}-\u{1F9FF}]/gu, '').trim();
            return `
                <li class="flex items-start gap-2.5">
                    <svg class="w-3.5 h-3.5 text-[#53fc18] flex-shrink-0 mt-0.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2.5" d="M5 13l4 4L19 7"></path>
                    </svg>
                    <span>${cleanTxt}</span>
                </li>
            `;
        }).join('');
    }

    // Moderators Matrix Table with Visual Progress Bars & No Emojis
    const tbody = document.getElementById('reportModsTableBody');
    if (tbody) {
        if (!analytics.moderators.length) {
            tbody.innerHTML = `<tr><td colspan="7" class="text-center py-6 text-gray-500">لا يوجد مشرفين مسجلين لهذه القناة بعد.</td></tr>`;
        } else {
            tbody.innerHTML = analytics.moderators.map(m => {
                const presenceColor = m.status === 'active' ? 'text-[#53fc18]' : (m.status === 'partial' ? 'text-amber-400' : 'text-gray-500');
                const presenceBadge = m.status === 'active'
                    ? `<span class="inline-flex items-center gap-1.5 bg-[#53fc18]/10 text-[#53fc18] border border-[#53fc18]/30 px-2 py-0.5 rounded-full text-[11px] font-bold"><span class="w-1.5 h-1.5 rounded-full bg-[#53fc18]"></span><span>حاضر</span></span>`
                    : (m.status === 'partial'
                        ? `<span class="inline-flex items-center gap-1.5 bg-amber-400/10 text-amber-400 border border-amber-400/30 px-2 py-0.5 rounded-full text-[11px] font-bold"><span class="w-1.5 h-1.5 rounded-full bg-amber-400"></span><span>جزئي</span></span>`
                        : `<span class="inline-flex items-center gap-1.5 bg-red-500/10 text-red-400 border border-red-500/30 px-2 py-0.5 rounded-full text-[11px] font-bold"><span class="w-1.5 h-1.5 rounded-full bg-red-500"></span><span>غائب</span></span>`);

                const avatar = m.avatar_url
                    ? `<img src="${m.avatar_url}" class="w-6 h-6 rounded-md object-cover bg-black border border-white/10">`
                    : `<div class="w-6 h-6 rounded-md bg-black border border-white/10 flex items-center justify-center font-bold text-[10px] text-[#53fc18]">${m.username.charAt(0).toUpperCase()}</div>`;

                const mvpBadge = m.badge
                    ? `<span class="inline-flex items-center gap-1 text-[9px] bg-amber-400/20 text-amber-300 border border-amber-400/40 px-1.5 py-0.5 rounded-md font-bold">
                        <svg class="w-3 h-3 text-amber-400" viewBox="0 0 20 20" fill="currentColor">
                            <path d="M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z"/>
                        </svg>
                        <span>MVP</span>
                    </span>`
                    : '';

                return `
                    <tr class="hover:bg-[#151b1e] transition">
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2">
                                ${avatar}
                                <span class="font-bold text-white">${m.username}</span>
                                ${mvpBadge}
                            </div>
                        </td>
                        <td class="px-4 py-3">${presenceBadge}</td>
                        <td class="px-4 py-3 font-mono font-bold ${presenceColor}">${formatActiveDuration(m.active_seconds)}</td>
                        <td class="px-4 py-3">
                            <div class="flex items-center gap-2">
                                <div class="w-16 sm:w-20 bg-[#1a2226] rounded-full h-1.5 overflow-hidden">
                                    <div class="bg-gradient-to-r from-[#53fc18] to-[#34d320] h-full rounded-full transition-all duration-500" style="width: ${m.presence_percent}%"></div>
                                </div>
                                <span class="font-mono font-bold text-white text-[11px]">${m.presence_percent}%</span>
                            </div>
                        </td>
                        <td class="px-4 py-3 text-red-400 font-mono font-bold">${m.bans}</td>
                        <td class="px-4 py-3 text-amber-400 font-mono font-bold">${m.timeouts}</td>
                        <td class="px-4 py-3 whitespace-nowrap">
                            <span class="whitespace-nowrap inline-flex items-center justify-center gap-1 font-mono font-bold text-[#53fc18] bg-[#53fc18]/10 border border-[#53fc18]/25 px-2.5 py-0.5 rounded-full text-xs">
                                <span>${m.score}</span>
                                <span class="text-[10px] font-sans">نقطة</span>
                            </span>
                        </td>
                    </tr>
                `;
            }).join('');
        }
    }

    openModal('streamAnalyticsModal');
}

/**
 * Send Stream Report to Discord Webhook
 */
async function sendReportToDiscord() {
    if (!currentChannelId || !currentAnalyticsReportId) return;
    const btn = document.getElementById('sendDiscordBtn');
    if (btn) {
        btn.disabled = true;
        btn.innerHTML = `<span class="inline-block animate-spin mr-1">⌛</span> جاري الإرسال...`;
    }

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/stream-reports/${currentAnalyticsReportId}/send-discord`, {
            method: 'POST'
        });
        const data = await res.json();
        if (data.success) {
            showToast(data.message || 'تم إرسال التقرير التحليلي للديسكورد بنجاح!', 'success');
        } else {
            showToast(data.error || 'تعذر إرسال التقرير لديسكورد', 'error');
        }
    } catch (e) {
        showToast('حدث خطأ أثناء الإرسال لديسكورد', 'error');
    } finally {
        if (btn) {
            btn.disabled = false;
            btn.innerHTML = `<i class="fa-brands fa-discord text-sm"></i><span>إرسال للديسكورد</span>`;
        }
    }
}

/**
 * Open Moderator Profile Drill-down Modal
 */
async function openModProfile(rawUsername) {
    if (!currentChannelId) return;
    const username = decodeURIComponent(rawUsername);

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/moderator/${encodeURIComponent(username)}`);
        const data = await res.json();
        if (!data.success) {
            showToast('تعذر جلب ملف المشرف', 'error');
            return;
        }

        const m = data.moderator;
        const avatarImg = document.getElementById('profileModAvatarImg');
        if (avatarImg) {
            avatarImg.src = m.avatar_url || 'https://kick.com/favicon.ico';
        }

        document.getElementById('profileModUsername').textContent = m.username;
        const badgeEl = document.getElementById('profileModBadge');
        if (badgeEl) {
            badgeEl.textContent = m.is_bot ? 'بوت معتمد' : 'مشرف معتمد';
            badgeEl.className = m.is_bot
                ? 'text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded-full font-mono'
                : 'text-xs bg-[#53fc18]/10 text-[#53fc18] border border-[#53fc18]/30 px-2 py-0.5 rounded-full font-normal';
        }

        document.getElementById('profileModBans').textContent = m.total_bans;
        document.getElementById('profileModTimeouts').textContent = m.total_timeouts;
        document.getElementById('profileModMessages').textContent = m.total_messages;
        document.getElementById('profileModActiveTime').textContent = formatActiveDuration(m.total_active_seconds);

        const firstSeen = m.first_seen ? formatAppDate(m.first_seen, { month: 'short', day: 'numeric', year: 'numeric' }) : '-';
        const lastSeen = m.last_seen ? formatAppDate(m.last_seen, { hour: '2-digit', minute: '2-digit' }) : '-';
        document.getElementById('profileModMeta').textContent = `أول تواجد: ${firstSeen} | آخر تفاعل: ${lastSeen}`;

        // Render Action Timeline
        const timeline = document.getElementById('profileModTimeline');
        if (!data.actions.length) {
            timeline.innerHTML = '<div class="text-center py-6 text-gray-500 text-xs">لا توجد عمليات حظر أو كتم سابقة لهذا المشرف.</div>';
        } else {
            let html = '';
            data.actions.forEach(a => {
                const date = formatAppDate(a.created_at, { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
                html += `
                    <div class="flex items-center justify-between text-xs p-2 bg-[#131719] border border-[#1e2428] rounded-lg">
                        <div class="flex items-center gap-2">
                            <span class="font-bold ${a.action_type === 'ban' ? 'text-red-400' : 'text-amber-400'}">[${a.action_type.toUpperCase()}]</span>
                            <span>ضد: <strong class="text-white">${a.target_username}</strong></span>
                        </div>
                        <span class="text-gray-500 font-mono text-[11px]">${date}</span>
                    </div>
                `;
            });
            timeline.innerHTML = html;
        }

        openModal('modProfileModal');
    } catch (err) {
        console.error('Failed to load mod profile:', err);
        showToast('خطأ أثناء تحميل بيانات المشرف', 'error');
    }
}

/**
 * Handle Add Channel Form Submission
 */
async function submitAddChannel(e) {
    e.preventDefault();
    const slugInput = document.getElementById('newChannelSlug');
    const webhookInput = document.getElementById('newChannelWebhook');
    const errEl = document.getElementById('addChannelError');
    const btn = document.getElementById('addChannelSubmitBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ التحقق...';

    const cleanSlug = slugInput.value.trim().replace(/[^a-zA-Z0-9_-]/g, '').toLowerCase();

    try {
        const res = await fetch('/api/channels', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                slug: cleanSlug,
                discord_webhook: webhookInput.value.trim()
            })
        });

        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        slugInput.value = '';
        webhookInput.value = '';
        closeModal('addChannelModal');
        showToast(`تمت إضافة قناة @${data.channel.slug} وتفعيل المراقبة 24/7!`, 'success');
        await loadChannels(data.channel.id);
        switchView('dashboard');
    } catch (err) {
        errEl.textContent = err.message || 'حدث خطأ أثناء إضافة القناة';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>إضافة وتفعيل</span>';
    }
}

/**
 * Channel Settings & Discord Webhook
 */
function openChannelSettings() {
    if (!currentChannelId) return;
    const select = document.getElementById('channelSelect');
    const selectedOption = select.options[select.selectedIndex];
    document.getElementById('settingsChannelTitle').textContent = `إعدادات قناة ${selectedOption.textContent}`;
    document.getElementById('settingsWebhookInput').value = selectedOption.dataset.webhook || '';
    document.getElementById('webhookSaveStatus').textContent = '';
    openModal('channelSettingsModal');
}

async function saveWebhook() {
    if (!currentChannelId) return;
    const webhookUrl = document.getElementById('settingsWebhookInput').value.trim();
    const statusEl = document.getElementById('webhookSaveStatus');
    statusEl.textContent = 'جارٍ الحفظ والفحص...';

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/webhook`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ discord_webhook: webhookUrl })
        });
        const data = await res.json();
        if (data.success) {
            statusEl.textContent = data.webhookValid ? 'تم الحفظ وإرسال إشعار تجريبي بنجاح' : 'تم الحفظ بنجاح.';
            statusEl.className = 'text-xs text-[#53fc18]';
            const select = document.getElementById('channelSelect');
            select.options[select.selectedIndex].dataset.webhook = webhookUrl;
            showToast('تم حفظ رابط الويب هوك بنجاح', 'success');
        } else {
            statusEl.textContent = 'حدث خطأ: ' + data.error;
            statusEl.className = 'text-xs text-red-400';
        }
    } catch (err) {
        statusEl.textContent = 'خطأ بالاتصال بالسيرفر';
        statusEl.className = 'text-xs text-red-400';
    }
}

async function deleteCurrentChannel() {
    if (!currentChannelId) return;
    if (!confirm('هل أنت متأكد من حذف هذه القناة وجميع سجلاتها من المراقبة؟')) return;

    try {
        const res = await fetch(`/api/channels/${currentChannelId}`, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) {
            closeModal('channelSettingsModal');
            showToast('تم حذف القناة وسجلاتها', 'info');
            await loadChannels();
        }
    } catch (err) {
        showToast('حدث خطأ أثناء الحذف', 'error');
    }
}

/**
 * Fetch and Render Mod Actions Audit Log
 */
async function loadAuditLogs() {
    if (!currentChannelId) return;

    const filterType = document.getElementById('actionFilterSelect')?.value || 'all';
    try {
        const res = await fetch(`/api/channels/${currentChannelId}/actions?type=${filterType}`);
        const data = await res.json();
        if (!data.success) return;

        const tbody = document.getElementById('auditLogsBody');
        if (!data.actions.length) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center py-10 text-gray-500">لا توجد عمليات إشراف مسجلة بعد.</td></tr>`;
            return;
        }

        let html = '';
        data.actions.forEach(act => {
            let badge = '';
            let durationText = '-';

            if (act.action_type === 'ban') {
                badge = `<span class="bg-red-500/10 text-red-400 border border-red-500/30 px-2 py-0.5 rounded text-xs font-semibold">حظر دائم</span>`;
            } else if (act.action_type === 'timeout') {
                const mins = act.duration_seconds >= 60 ? `${Math.round(act.duration_seconds / 60)} دقيقة` : `${act.duration_seconds} ثانية`;
                badge = `<span class="bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded text-xs font-semibold">كتم مؤقت</span>`;
                durationText = mins;
            } else if (act.action_type === 'unban') {
                badge = `<span class="bg-blue-500/10 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded text-xs font-semibold">إلغاء حظر</span>`;
            } else {
                badge = `<span class="bg-purple-500/10 text-purple-400 border border-purple-500/30 px-2 py-0.5 rounded text-xs font-semibold">حذف رسالة</span>`;
            }

            const time = formatAppDate(act.created_at, {
                month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            });

            html += `
                <tr class="hover:bg-[#161c1f] transition">
                    <td class="px-6 py-3.5 font-bold text-white">${act.moderator_username}</td>
                    <td class="px-6 py-3.5">${badge}</td>
                    <td class="px-6 py-3.5 text-gray-300 font-mono">${act.target_username || 'الرسالة'}</td>
                    <td class="px-6 py-3.5 text-xs text-gray-400">${durationText} ${act.reason ? `(${act.reason})` : ''}</td>
                    <td class="px-6 py-3.5 text-xs text-gray-400 font-mono">${time}</td>
                </tr>
            `;
        });

        tbody.innerHTML = html;
    } catch (err) {
        console.error('Failed to load audit logs:', err);
    }
}

/**
 * Simulate Test Action (Ban or Timeout) to test dashboard live
 */
async function simulateTestAction() {
    if (!currentChannelId) {
        showToast('يرجى اختيار أو إضافة قناة أولاً!', 'error');
        return;
    }

    const types = ['timeout', 'ban'];
    const randomType = types[Math.floor(Math.random() * types.length)];
    const sampleMods = ['KALACLIPS', 'LeMo_99', 'Mai_Essam', 'AL3OTIBI', 'ItsJadeer'];
    const sampleTargets = ['Spammer123', 'ToxicViewer', 'TrollGuy', 'BotUser_9'];

    const randomMod = sampleMods[Math.floor(Math.random() * sampleMods.length)];
    const randomTarget = sampleTargets[Math.floor(Math.random() * sampleTargets.length)];

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/simulate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action_type: randomType,
                moderator: randomMod,
                target_user: randomTarget,
                duration: randomType === 'timeout' ? 300 : 0
            })
        });
        const data = await res.json();
        if (data.success) {
            showToast(`تم تنفيذ تجربة إجراء (${randomType === 'ban' ? 'حظر' : 'كتم'}) بواسطة ${randomMod}!`, 'success');
        } else {
            showToast('فشل تنفيذ التجربة: ' + (data.error || 'خطأ'), 'error');
        }
    } catch (err) {
        console.error('Failed to simulate action:', err);
        showToast('خطأ بالاتصال أثناء التجربة', 'error');
    }
}

/**
 * Export CSV / JSON with direct download link (bypasses popup blocker)
 */
function exportData(format) {
    if (!currentChannelId) {
        showToast('يرجى اختيار قناة أولاً للتصدير!', 'error');
        return;
    }

    showToast(`جارٍ تحضير ملف الـ ${format.toUpperCase()}...`, 'info');
    const downloadUrl = `/api/channels/${currentChannelId}/export?format=${format}`;
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = `kickmod_${currentChannelSlug || 'channel'}_audit.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

/**
 * Force Resync Channel Data & Active Chatters
 */
async function forceResyncChannel() {
    if (!currentChannelId) {
        showToast('يرجى اختيار قناة أولاً!', 'error');
        return;
    }

    const icon = document.getElementById('resyncBtnIcon');
    const btn = document.getElementById('resyncBtn');
    if (icon) icon.classList.add('fa-spin');
    if (btn) btn.disabled = true;

    showToast('جارٍ مزامنة المشرفين وبيانات القناة من سيرفرات كيك...', 'info');

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/resync`, { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            showToast('تمت المزامنة الفورية وتحديث المشرفين بنجاح!', 'success');
            await loadChannels(currentChannelId);
            await loadOverview();
            await loadLeaderboard();
            await loadBestMods();
            await loadAuditLogs();
        } else {
            showToast('حدث خطأ أثناء المزامنة: ' + (data.error || 'فشل الاتصال'), 'error');
        }
    } catch (e) {
        showToast('تعذر الاتصال بالسيرفر للمزامنة', 'error');
    } finally {
        if (icon) icon.classList.remove('fa-spin');
        if (btn) btn.disabled = false;
    }
}

/**
 * Toast Notifications (Clean SVGs - No Emojis)
 */
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    const colors = {
        success: 'bg-[#131719] border-[#53fc18] text-[#53fc18]',
        error: 'bg-[#131719] border-red-500 text-red-400',
        info: 'bg-[#131719] border-blue-500 text-blue-400'
    };

    toast.className = `pointer-events-auto flex items-center gap-2.5 px-4 py-3 rounded-xl border ${colors[type] || colors.info} shadow-2xl text-xs font-bold transition-all duration-300 transform translate-y-2 opacity-0 backdrop-blur-md`;
    toast.innerHTML = `
        <span class="w-2 h-2 rounded-full ${type === 'error' ? 'bg-red-400' : (type === 'success' ? 'bg-[#53fc18]' : 'bg-blue-400')}"></span>
        <span>${message}</span>
    `;

    container.appendChild(toast);
    requestAnimationFrame(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
    });

    setTimeout(() => {
        toast.classList.add('translate-y-2', 'opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

/**
 * Modal Helpers
 */
function openModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('hidden');
}

function closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
}

// KickMod Dashboard Client Engine
let currentChannelId = null;
let currentChannelSlug = null;
let currentView = 'landing'; // 'landing' or 'dashboard'
let actionsChartInstance = null;
let pieChartInstance = null;
let allModeratorsData = [];
let currentModFilter = 'human'; // 'human' (default) or 'all'

// Initialize Socket.io
const socket = io();

socket.on('connect', () => {
    console.log('Connected to KickMod real-time socket server.');
    const statusEl = document.getElementById('systemStatus');
    if (statusEl) {
        statusEl.textContent = 'المحرك المباشر متصل 24/7';
        statusEl.classList.remove('text-red-400');
        statusEl.classList.add('text-gray-400');
    }
});

socket.on('disconnect', () => {
    const statusEl = document.getElementById('systemStatus');
    if (statusEl) {
        statusEl.textContent = 'انقطع الاتصال بالسيرفر';
        statusEl.classList.remove('text-gray-400');
        statusEl.classList.add('text-red-400');
    }
});

// Real-time Event: Moderator Action Executed (Ban, Timeout, Delete)
socket.on('mod_action', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        appendLiveFeedItem(data);
        incrementCounter(data.action_type);
        loadLeaderboard();
        loadOverview();
        loadBestMods();
    }
    loadNetworkStats();
});

// Real-time Event: Moderator Chat Message
socket.on('mod_message', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        const msgEl = document.getElementById('statModMessages');
        if (msgEl) {
            msgEl.textContent = parseInt(msgEl.textContent || '0') + 1;
        }
        loadLeaderboard();
        loadOverview();
        loadBestMods();
    }
});

// Real-time Event: General Chat Stream
socket.on('chat_stream_message', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        appendLiveChatItem(data);
    }
});

// Real-time Event: Active Chatters Updated
socket.on('active_chatters_updated', (data) => {
    if (currentChannelId && String(data.channel_id) === String(currentChannelId)) {
        loadLeaderboard();
        loadBestMods();
    }
    loadNetworkStats();
});

// On Document Ready
document.addEventListener('DOMContentLoaded', () => {
    initCharts();
    loadChannels();
    loadNetworkStats();
    checkUserSession();

    // Close modal when clicking outside of it (backdrop click)
    ['addChannelModal', 'channelSettingsModal', 'modProfileModal', 'loginModal', 'registerModal', 'discordModal'].forEach(id => {
        const modal = document.getElementById(id);
        if (modal) {
            modal.addEventListener('click', (e) => {
                if (e.target === modal) {
                    closeModal(id);
                }
            });
        }
    });

    // Close modal on ESC key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape') {
            closeModal('addChannelModal');
            closeModal('channelSettingsModal');
            closeModal('modProfileModal');
            closeModal('loginModal');
            closeModal('registerModal');
            closeModal('discordModal');
        }
    });
});

/**
 * Check User Authentication Session
 */
function checkUserSession() {
    const raw = localStorage.getItem('kickmod_user');
    const guestBox = document.getElementById('authGuestButtons');
    const userBox = document.getElementById('authUserMenu');

    if (!raw) {
        if (guestBox) guestBox.classList.remove('hidden');
        if (userBox) userBox.classList.add('hidden');
        return;
    }

    try {
        const user = JSON.parse(raw);
        if (guestBox) guestBox.classList.add('hidden');
        if (userBox) userBox.classList.remove('hidden');

        const nameEl = document.getElementById('userDisplayName');
        if (nameEl) nameEl.textContent = user.discord_username || user.username;

        const avatarEl = document.getElementById('userAvatarImg');
        if (avatarEl && user.discord_avatar) {
            avatarEl.src = user.discord_avatar;
        }
    } catch (e) {
        localStorage.removeItem('kickmod_user');
    }
}

/**
 * User Login Handler
 */
async function handleLoginSubmit(e) {
    e.preventDefault();
    const username = document.getElementById('loginUsername').value.trim();
    const password = document.getElementById('loginPassword').value;
    const errEl = document.getElementById('loginError');
    const btn = document.getElementById('loginSubmitBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.textContent = 'جارٍ تسجيل الدخول...';

    try {
        const res = await fetch('/api/auth/login', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, password })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        localStorage.setItem('kickmod_user', JSON.stringify(data.user));
        checkUserSession();
        closeModal('loginModal');
        showToast(`مرحباً بك مجدداً @${data.user.username}!`, 'success');
    } catch (err) {
        errEl.textContent = err.message || 'فشل تسجيل الدخول';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.textContent = 'تسجيل الدخول';
    }
}

/**
 * User Registration Handler
 */
async function handleRegisterSubmit(e) {
    e.preventDefault();
    const username = document.getElementById('regUsername').value.trim();
    const email = document.getElementById('regEmail').value.trim();
    const password = document.getElementById('regPassword').value;
    const errEl = document.getElementById('registerError');
    const btn = document.getElementById('registerSubmitBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.textContent = 'جارٍ إنشاء الحساب...';

    try {
        const res = await fetch('/api/auth/register', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ username, email, password })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        localStorage.setItem('kickmod_user', JSON.stringify(data.user));
        checkUserSession();
        closeModal('registerModal');
        showToast(`تم إنشاء حسابك بنجاح @${data.user.username}!`, 'success');
    } catch (err) {
        errEl.textContent = err.message || 'فشل إنشاء الحساب';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.textContent = 'إنشاء الحساب وبدء الاستخدام';
    }
}

/**
 * Discord Login / Connect Handler
 */
async function handleDiscordSubmit(e) {
    e.preventDefault();
    const discordTag = document.getElementById('discordTagInput').value.trim();
    const errEl = document.getElementById('discordError');
    const btn = document.getElementById('discordSubmitBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ الاتصال بديسكورد...';

    try {
        const res = await fetch('/api/auth/discord', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ discord_tag: discordTag })
        });
        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        localStorage.setItem('kickmod_user', JSON.stringify(data.user));
        checkUserSession();
        closeModal('discordModal');
        showToast(`تم تسجيل الدخول بنجاح عبر ديسكورد @${data.user.discord_username}!`, 'success');
    } catch (err) {
        errEl.textContent = err.message || 'فشل الاتصال بحساب ديسكورد';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<i class="fa-brands fa-discord text-base"></i> <span>متابعة وتسجيل الدخول بحساب ديسكورد</span>';
    }
}

/**
 * User Logout
 */
function logoutUser() {
    localStorage.removeItem('kickmod_user');
    checkUserSession();
    showToast('تم تسجيل الخروج بنجاح', 'info');
}

/**
 * Quick Channel Form Submission (Landing Page)
 */
async function submitQuickChannel(e) {
    e.preventDefault();
    const slugInput = document.getElementById('quickSlugInput');
    const webhookInput = document.getElementById('quickWebhookInput');
    const btn = document.getElementById('quickChannelBtn');
    const errEl = document.getElementById('quickChannelError');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ التحقق من كيك وبدء الرصد...';

    const slug = slugInput.value.trim().replace(/[^a-zA-Z0-9_-]/g, '').toLowerCase();

    try {
        const res = await fetch('/api/channels', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                slug,
                discord_webhook: webhookInput.value.trim()
            })
        });

        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        showToast(`تمت إضافة القناة @${data.channel.slug} وبدء الرصد 24/7!`, 'success');
        slugInput.value = '';
        webhookInput.value = '';

        await loadChannels(data.channel.id);
        switchView('dashboard');
    } catch (err) {
        errEl.textContent = err.message || 'حدث خطأ أثناء إضافة القناة';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `
            <span>تفعيل المراقبة اللحظية للقناة (24/7)</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
            </svg>
        `;
    }
}

/**
 * Switch View: Landing (الرئيسية والتسجيل) vs Dashboard (لوحة المراقبة)
 */
function switchView(viewName) {
    currentView = viewName;
    const landingEl = document.getElementById('landingView');
    const dashboardEl = document.getElementById('dashboardView');
    const btnLanding = document.getElementById('navBtnLanding');
    const btnDashboard = document.getElementById('navBtnDashboard');

    if (viewName === 'landing') {
        landingEl.classList.remove('hidden');
        dashboardEl.classList.add('hidden');
        btnLanding.className = 'px-3.5 py-1.5 rounded-lg font-bold bg-[#53fc18] text-black transition flex items-center gap-1.5';
        btnDashboard.className = 'px-3.5 py-1.5 rounded-lg font-medium text-gray-400 hover:text-white transition flex items-center gap-1.5';
        loadNetworkStats();
    } else {
        landingEl.classList.add('hidden');
        dashboardEl.classList.remove('hidden');
        btnDashboard.className = 'px-3.5 py-1.5 rounded-lg font-bold bg-[#53fc18] text-black transition flex items-center gap-1.5';
        btnLanding.className = 'px-3.5 py-1.5 rounded-lg font-medium text-gray-400 hover:text-white transition flex items-center gap-1.5';
        if (currentChannelId) {
            loadOverview();
            loadLeaderboard();
            loadBestMods();
            loadAuditLogs();
        }
    }
}

/**
 * Load Global Network Stats for Landing Page
 */
async function loadNetworkStats() {
    try {
        const res = await fetch('/api/network/stats');
        const data = await res.json();
        if (data.success && data.stats) {
            const s = data.stats;
            const chEl = document.getElementById('netChannelsCount');
            const modsEl = document.getElementById('netModsCount');
            const actEl = document.getElementById('netActionsCount');

            if (chEl) chEl.textContent = s.total_channels || 0;
            if (modsEl) modsEl.textContent = s.currently_online_mods || s.total_human_mods || 0;
            if (actEl) actEl.textContent = s.total_actions_recorded || 0;
        }
    } catch (e) {
        console.warn('Network stats fetch error:', e.message);
    }
}

/**
 * Handle Landing Channel Registration
 */
async function submitLandingRegister(e) {
    e.preventDefault();
    const slugInput = document.getElementById('landingSlugInput');
    const webhookInput = document.getElementById('landingWebhookInput');
    const btn = document.getElementById('landingRegisterBtn');
    const errEl = document.getElementById('landingRegisterError');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ التحقق من كيك وبدء الرصد...';

    const slug = slugInput.value.trim().replace(/[^a-zA-Z0-9_-]/g, '').toLowerCase();

    try {
        const res = await fetch('/api/channels', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                slug,
                discord_webhook: webhookInput.value.trim()
            })
        });

        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        showToast(`تم تسجيل القناة @${data.channel.slug} وبدء الرصد 24/7 بنجاح!`, 'success');
        slugInput.value = '';
        webhookInput.value = '';

        await loadChannels(data.channel.id);
        switchView('dashboard');
    } catch (err) {
        errEl.textContent = err.message || 'حدث خطأ أثناء تسجيل القناة';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = `
            <span>تفعيل المراقبة الفورية (24/7)</span>
            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M14 5l7 7m0 0l-7 7m7-7H3"></path>
            </svg>
        `;
    }
}

/**
 * Initialize Chart.js
 */
function initCharts() {
    // 1. Actions Bar Chart
    const ctx1 = document.getElementById('actionsChart').getContext('2d');
    actionsChartInstance = new Chart(ctx1, {
        type: 'bar',
        data: {
            labels: [],
            datasets: [
                {
                    label: 'عمليات الحظر (Bans)',
                    data: [],
                    backgroundColor: 'rgba(239, 68, 68, 0.85)',
                    borderRadius: 6
                },
                {
                    label: 'عمليات الكتم (Timeouts)',
                    data: [],
                    backgroundColor: 'rgba(245, 158, 11, 0.85)',
                    borderRadius: 6
                }
            ]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    labels: { color: '#9ca3af', font: { family: 'Cairo', size: 11 } }
                }
            },
            scales: {
                x: {
                    grid: { color: '#1e2428' },
                    ticks: { color: '#9ca3af', font: { size: 10 } }
                },
                y: {
                    beginAtZero: true,
                    grid: { color: '#1e2428' },
                    ticks: { color: '#9ca3af', stepSize: 1, font: { size: 10 } }
                }
            }
        }
    });

    // 2. Task Distribution Doughnut Chart
    const ctx2 = document.getElementById('taskPieChart').getContext('2d');
    pieChartInstance = new Chart(ctx2, {
        type: 'doughnut',
        data: {
            labels: ['رسائل المشرفين', 'عمليات الكتم', 'عمليات الحظر'],
            datasets: [{
                data: [0, 0, 0],
                backgroundColor: [
                    'rgba(83, 252, 24, 0.85)',
                    'rgba(245, 158, 11, 0.85)',
                    'rgba(239, 68, 68, 0.85)'
                ],
                borderWidth: 0
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: { color: '#9ca3af', font: { family: 'Cairo', size: 11 } }
                }
            },
            cutout: '68%'
        }
    });
}

/**
 * Load Monitored Channels into Dropdown
 */
async function loadChannels(selectChannelId = null) {
    try {
        const res = await fetch('/api/channels');
        const data = await res.json();

        const select = document.getElementById('channelSelect');
        select.innerHTML = '';

        if (!data.channels || data.channels.length === 0) {
            select.innerHTML = '<option value="">لا توجد قنوات مسجلة</option>';
            document.getElementById('currentChannelName').textContent = 'أضف أول قناة للمراقبة';
            return;
        }

        data.channels.forEach(ch => {
            const opt = document.createElement('option');
            opt.value = ch.id;
            opt.textContent = `${ch.name} (@${ch.slug})`;
            opt.dataset.slug = ch.slug;
            opt.dataset.avatar = ch.avatar_url;
            opt.dataset.banner = ch.banner_url || '';
            opt.dataset.webhook = ch.discord_webhook || '';
            select.appendChild(opt);
        });

        // Set selected channel (prefer selectChannelId or sa3dola or 3mr)
        if (selectChannelId) {
            select.value = selectChannelId;
        } else {
            const preferred = Array.from(select.options).find(o => o.dataset.slug === 'sa3dola') ||
                              Array.from(select.options).find(o => o.dataset.slug === '3mr');
            if (preferred) {
                select.value = preferred.value;
            }
        }

        currentChannelId = select.value;
        onChannelChanged();
    } catch (err) {
        console.error('Failed to load channels:', err);
    }
}

// Channel Dropdown Change Listener
document.getElementById('channelSelect').addEventListener('change', (e) => {
    currentChannelId = e.target.value;
    onChannelChanged();
});

/**
 * Updates UI and fetches data when channel changes
 */
function onChannelChanged() {
    const select = document.getElementById('channelSelect');
    const selectedOption = select.options[select.selectedIndex];
    if (!selectedOption || !selectedOption.value) return;

    currentChannelId = selectedOption.value;
    currentChannelSlug = selectedOption.dataset.slug;

    // Update Hero Banner & Profile Info
    const avatarUrl = selectedOption.dataset.avatar || 'https://kick.com/favicon.ico';
    const bannerUrl = selectedOption.dataset.banner;

    document.getElementById('currentChannelAvatar').src = avatarUrl;
    document.getElementById('currentChannelName').textContent = selectedOption.textContent.split(' (')[0];
    document.getElementById('currentChannelLink').href = `https://kick.com/${currentChannelSlug}`;
    document.getElementById('currentChannelLink').querySelector('span').textContent = `kick.com/${currentChannelSlug}`;
    document.getElementById('currentChannelMeta').textContent = `رصد مباشر وشامل لمشرفي القناة 24/7`;

    const bannerBg = document.getElementById('channelBannerBg');
    if (bannerBg) {
        if (bannerUrl) {
            bannerBg.style.backgroundImage = `url('${bannerUrl}')`;
        } else {
            bannerBg.style.backgroundImage = `linear-gradient(to right, #131719, #1a2226)`;
        }
    }

    // Reset live feed
    document.getElementById('liveFeedContainer').innerHTML = `
        <div class="text-center py-10 text-gray-500 text-xs">
            <svg class="w-8 h-8 text-[#53fc18] mx-auto mb-2 opacity-60 animate-pulse" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z"></path>
            </svg>
            متصل بقناة ${currentChannelSlug}، بانتظار إجراءات الإشراف...
        </div>
    `;

    // Fetch Overview, Leaderboard, Audit & Best Mods
    loadOverview();
    loadLeaderboard();
    loadBestMods();
    loadAuditLogs();
}

/**
 * Fetch Channel Overview Counters & Chart Data
 */
async function loadOverview() {
    if (!currentChannelId) return;

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/overview`);
        const data = await res.json();
        if (!data.success) return;

        const s = data.stats;
        document.getElementById('statTotalMods').textContent = s.total_moderators || 0;
        document.getElementById('statActiveToday').textContent = `${s.active_mods_today || 0} متفاعل اليوم`;
        document.getElementById('statTotalBans').textContent = s.total_bans || 0;
        document.getElementById('statTotalTimeouts').textContent = s.total_timeouts || 0;
        document.getElementById('statModMessages').textContent = s.total_mod_messages || 0;

        // Update Bar Chart
        const labels = (data.dailyActivity || []).map(d => d.date);
        const bansData = (data.dailyActivity || []).map(d => d.bans);
        const timeoutsData = (data.dailyActivity || []).map(d => d.timeouts);

        if (actionsChartInstance) {
            actionsChartInstance.data.labels = labels.length ? labels : ['اليوم'];
            actionsChartInstance.data.datasets[0].data = bansData.length ? bansData : [s.total_bans || 0];
            actionsChartInstance.data.datasets[1].data = timeoutsData.length ? timeoutsData : [s.total_timeouts || 0];
            actionsChartInstance.update();
        }

        // Update Doughnut Chart (Tasks distribution)
        if (pieChartInstance) {
            pieChartInstance.data.datasets[0].data = [
                s.total_mod_messages || 0,
                s.total_timeouts || 0,
                s.total_bans || 0
            ];
            pieChartInstance.update();
        }
    } catch (err) {
        console.error('Failed to load overview:', err);
    }
}

/**
 * Format Active Duration in Accurate Arabic (No Emojis)
 */
function formatActiveDuration(seconds) {
    if (!seconds || seconds <= 0) return 'أقل من دقيقة';
    if (seconds < 60) return `${seconds} ثانية`;
    const hrs = Math.floor(seconds / 3600);
    const mins = Math.floor((seconds % 3600) / 60);
    if (hrs > 0) {
        return `${hrs} ساعة و ${mins} دقيقة`;
    }
    return `${mins} دقيقة`;
}

/**
 * Filter Mode (Human Only vs All including Bots)
 */
function setModFilter(type) {
    currentModFilter = type;
    const btnHuman = document.getElementById('filterBtnHuman');
    const btnAll = document.getElementById('filterBtnAll');

    if (type === 'human') {
        btnHuman.className = 'px-3 py-1 rounded-lg font-bold bg-[#53fc18] text-black transition';
        btnAll.className = 'px-3 py-1 rounded-lg font-medium text-gray-400 hover:text-white transition';
    } else {
        btnAll.className = 'px-3 py-1 rounded-lg font-bold bg-[#53fc18] text-black transition';
        btnHuman.className = 'px-3 py-1 rounded-lg font-medium text-gray-400 hover:text-white transition';
    }

    filterLeaderboard();
}

/**
 * Fetch and Render Moderators Leaderboard
 */
async function loadLeaderboard() {
    if (!currentChannelId) return;

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/leaderboard`);
        const data = await res.json();
        if (!data.success) return;

        allModeratorsData = data.moderators || [];
        filterLeaderboard();
    } catch (err) {
        console.error('Failed to load leaderboard:', err);
    }
}

function filterLeaderboard() {
    const q = (document.getElementById('searchModInput')?.value || '').trim().toLowerCase();
    
    let filtered = allModeratorsData;
    if (currentModFilter === 'human') {
        filtered = filtered.filter(m => !m.is_bot);
    }

    if (q) {
        filtered = filtered.filter(m => m.username.toLowerCase().includes(q));
    }

    renderLeaderboard(filtered);
}

function renderLeaderboard(moderators) {
    const tbody = document.getElementById('leaderboardBody');
    if (!moderators.length) {
        tbody.innerHTML = `<tr><td colspan="9" class="text-center py-10 text-gray-500">لا يوجد مشرفين يطابقون هذا الفلتر حالياً.</td></tr>`;
        return;
    }

    let html = '';
    moderators.forEach((mod, idx) => {
        let rankBadge = `<span class="font-bold text-gray-400">#${idx + 1}</span>`;
        if (idx === 0) {
            rankBadge = `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-400/20 text-amber-400 font-extrabold text-xs border border-amber-400/50">1</span>`;
        } else if (idx === 1) {
            rankBadge = `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-gray-300/20 text-gray-300 font-extrabold text-xs border border-gray-400/50">2</span>`;
        } else if (idx === 2) {
            rankBadge = `<span class="inline-flex items-center justify-center w-6 h-6 rounded-full bg-amber-700/20 text-amber-600 font-extrabold text-xs border border-amber-700/50">3</span>`;
        }

        const lastSeen = mod.last_seen ? new Date(mod.last_seen).toLocaleDateString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : 'غير محدد';
        const activeTimeStr = formatActiveDuration(mod.total_active_seconds);
        const onlineIndicator = mod.is_online 
            ? `<span class="w-2 h-2 rounded-full bg-[#53fc18] live-pulse inline-block" title="متواجد حالياً"></span>`
            : `<span class="w-2 h-2 rounded-full bg-gray-600 inline-block" title="غير متصل"></span>`;

        const botBadge = mod.is_bot 
            ? `<span class="text-[9px] bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-1.5 py-0.2 rounded font-mono">BOT</span>`
            : `<span class="text-[9px] bg-[#53fc18]/10 text-[#53fc18] border border-[#53fc18]/30 px-1.5 py-0.2 rounded">مشرف</span>`;

        const safeUsername = encodeURIComponent(mod.username);
        const avatarHtml = mod.avatar_url
            ? `<img src="${mod.avatar_url}" alt="${mod.username}" class="w-8 h-8 rounded-lg object-cover bg-black border border-[#2a3439]" onerror="this.onerror=null; this.src='https://kick.com/favicon.ico';">`
            : `<div class="w-8 h-8 rounded-lg bg-black border border-[#2a3439] flex items-center justify-center font-bold text-xs text-[#53fc18]">${mod.username.charAt(0).toUpperCase()}</div>`;

        html += `
            <tr class="hover:bg-[#161c1f] transition">
                <td class="px-6 py-4">${rankBadge}</td>
                <td class="px-6 py-4">
                    <div class="flex items-center gap-3">
                        ${avatarHtml}
                        <div>
                            <div class="flex items-center gap-1.5">
                                ${onlineIndicator}
                                <span class="font-bold text-white">${mod.username}</span>
                                ${botBadge}
                            </div>
                        </div>
                    </div>
                </td>
                <td class="px-6 py-4 font-semibold text-red-400">${mod.total_bans}</td>
                <td class="px-6 py-4 font-semibold text-amber-400">${mod.total_timeouts}</td>
                <td class="px-6 py-4 text-gray-300 font-mono">${mod.total_messages}</td>
                <td class="px-6 py-4 font-mono font-bold text-[#53fc18]">${activeTimeStr}</td>
                <td class="px-6 py-4">
                    <span class="bg-[#53fc18]/10 text-[#53fc18] font-bold px-2.5 py-1 rounded-full text-xs">
                        ${mod.activity_score} نقطة
                    </span>
                </td>
                <td class="px-6 py-4 text-xs text-gray-400">${lastSeen}</td>
                <td class="px-6 py-4 text-center">
                    <button onclick="openModProfile('${safeUsername}')" class="text-xs bg-[#1a2024] hover:bg-[#252e34] border border-[#2a3439] text-gray-300 hover:text-white px-3 py-1.5 rounded-lg transition active:scale-95">
                        عرض السجل
                    </button>
                </td>
            </tr>
        `;
    });

    tbody.innerHTML = html;
}

/**
 * Parse Kick Emotes into Real Animated Images
 */
function parseKickEmotes(text) {
    if (!text) return '';
    return text.replace(/\[emote:(\d+):([a-zA-Z0-9_-]+)\]/g, (match, id, name) => {
        return `<img src="https://files.kick.com/emotes/${id}/fullsize" alt="${name}" title="${name}" class="inline-block h-6 w-6 align-middle mx-0.5 object-contain hover:scale-125 transition-transform" loading="lazy">`;
    });
}

/**
 * Toggle between Mod Actions Feed and Live Chat Stream
 */
function toggleSideFeed(type) {
    const actionsBox = document.getElementById('liveFeedContainer');
    const chatBox = document.getElementById('liveChatContainer');
    const btnActions = document.getElementById('feedBtnActions');
    const btnChat = document.getElementById('feedBtnChat');

    if (type === 'actions') {
        actionsBox.classList.remove('hidden');
        chatBox.classList.add('hidden');
        btnActions.className = 'text-xs font-bold text-[#53fc18] bg-[#53fc18]/10 px-2.5 py-1 rounded-lg transition flex items-center gap-1.5';
        btnChat.className = 'text-xs font-medium text-gray-400 hover:text-white px-2.5 py-1 rounded-lg transition flex items-center gap-1';
    } else {
        actionsBox.classList.add('hidden');
        chatBox.classList.remove('hidden');
        btnChat.className = 'text-xs font-bold text-[#53fc18] bg-[#53fc18]/10 px-2.5 py-1 rounded-lg transition flex items-center gap-1';
        btnActions.className = 'text-xs font-medium text-gray-400 hover:text-white px-2.5 py-1 rounded-lg transition flex items-center gap-1.5';
    }
}

let liveChatCount = 0;
function appendLiveChatItem(data) {
    const container = document.getElementById('liveChatContainer');
    if (container.querySelector('.text-center')) {
        container.innerHTML = '';
    }

    liveChatCount++;
    const badgeEl = document.getElementById('chatCounterBadge');
    if (badgeEl) {
        badgeEl.textContent = `${liveChatCount} رسالة`;
    }

    const item = document.createElement('div');
    item.className = 'action-row-new p-2 rounded-lg bg-[#0b0e0f] border border-[#1e2428] flex items-start gap-2';

    let senderBadge = '';
    if (data.is_broadcaster) {
        senderBadge = '<span class="text-[9px] bg-red-500/20 text-red-400 border border-red-500/40 px-1 py-0.5 rounded font-bold">ستريمر</span>';
    } else if (data.is_bot) {
        senderBadge = '<span class="text-[9px] bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 px-1 py-0.5 rounded font-bold">BOT</span>';
    } else if (data.is_mod) {
        senderBadge = '<span class="text-[9px] bg-[#53fc18]/20 text-[#53fc18] border border-[#53fc18]/40 px-1 py-0.5 rounded font-bold">MOD</span>';
    }

    const parsedContent = parseKickEmotes(data.content);
    const senderColor = data.sender_color || '#e5e7eb';

    item.innerHTML = `
        <div class="flex-1 min-w-0">
            <div class="flex items-center gap-1.5 mb-0.5">
                ${senderBadge}
                <span class="font-bold text-[11px] truncate" style="color: ${senderColor}">${data.sender}:</span>
            </div>
            <p class="text-gray-200 text-xs break-words">${parsedContent}</p>
        </div>
        <span class="text-[9px] text-gray-600 font-mono mt-0.5">الآن</span>
    `;

    container.insertBefore(item, container.firstChild);
    if (container.children.length > 30) {
        container.removeChild(container.lastChild);
    }
}

/**
 * Append Action to Real-Time Live Feed Card
 */
function appendLiveFeedItem(data) {
    const container = document.getElementById('liveFeedContainer');
    if (container.querySelector('svg')) {
        container.innerHTML = '';
    }

    let badgeClass = 'text-red-400 bg-red-500/10 border-red-500/20';
    let actionLabel = 'قام بحظر';

    if (data.action_type === 'timeout') {
        badgeClass = 'text-amber-400 bg-amber-500/10 border-amber-500/20';
        actionLabel = `كتم (${data.duration_seconds >= 60 ? Math.round(data.duration_seconds / 60) + 'د' : data.duration_seconds + 'ث'})`;
    } else if (data.action_type === 'unban') {
        badgeClass = 'text-blue-400 bg-blue-500/10 border-blue-500/20';
        actionLabel = 'ألغى حظر';
    }

    const item = document.createElement('div');
    item.className = `action-row-new p-2.5 rounded-xl border bg-[#0b0e0f] ${badgeClass} text-xs flex items-center justify-between`;
    item.innerHTML = `
        <div class="flex items-center gap-2">
            <span><strong>${data.moderator}</strong> ${actionLabel} <strong>${data.target_user}</strong></span>
        </div>
        <span class="text-[10px] text-gray-500 font-mono">الآن</span>
    `;

    container.insertBefore(item, container.firstChild);

    if (container.children.length > 20) {
        container.removeChild(container.lastChild);
    }
}

function incrementCounter(actionType) {
    if (actionType === 'ban') {
        const el = document.getElementById('statTotalBans');
        if (el) el.textContent = parseInt(el.textContent || '0') + 1;
    } else if (actionType === 'timeout') {
        const el = document.getElementById('statTotalTimeouts');
        if (el) el.textContent = parseInt(el.textContent || '0') + 1;
    }
}

/**
 * Switch Tab (Leaderboard vs Audit Log vs Stream Reports)
 */
function switchTab(tabId) {
    document.getElementById('leaderboardTab').classList.add('hidden');
    document.getElementById('auditTab').classList.add('hidden');
    document.getElementById('reportsTab').classList.add('hidden');

    document.getElementById('tabBtnLeaderboard').className = 'pb-3 px-2 border-b-2 border-transparent text-gray-400 hover:text-white font-medium text-sm flex items-center gap-2 transition';
    document.getElementById('tabBtnAudit').className = 'pb-3 px-2 border-b-2 border-transparent text-gray-400 hover:text-white font-medium text-sm flex items-center gap-2 transition';
    document.getElementById('tabBtnReports').className = 'pb-3 px-2 border-b-2 border-transparent text-gray-400 hover:text-white font-medium text-sm flex items-center gap-2 transition';

    document.getElementById(tabId).classList.remove('hidden');

    if (tabId === 'leaderboardTab') {
        document.getElementById('tabBtnLeaderboard').className = 'pb-3 px-2 border-b-2 border-[#53fc18] text-[#53fc18] font-bold text-sm flex items-center gap-2 transition';
        loadLeaderboard();
        loadBestMods();
    } else if (tabId === 'auditTab') {
        document.getElementById('tabBtnAudit').className = 'pb-3 px-2 border-b-2 border-[#53fc18] text-[#53fc18] font-bold text-sm flex items-center gap-2 transition';
        loadAuditLogs();
    } else {
        document.getElementById('tabBtnReports').className = 'pb-3 px-2 border-b-2 border-[#53fc18] text-[#53fc18] font-bold text-sm flex items-center gap-2 transition';
        loadStreamReports();
    }
}

/**
 * Fetch and Render Best Moderators Showcase Cards
 */
async function loadBestMods() {
    if (!currentChannelId) return;
    try {
        const res = await fetch(`/api/channels/${currentChannelId}/best-mods`);
        const data = await res.json();
        if (!data.success) return;

        // 1. MVP
        if (data.mvp) {
            document.getElementById('mvpName').textContent = data.mvp.username;
            document.getElementById('mvpScore').textContent = `${data.mvp.activity_score} نقطة • ${formatActiveDuration(data.mvp.total_active_seconds)}`;
            if (data.mvp.avatar_url) document.getElementById('mvpAvatar').src = data.mvp.avatar_url;
        } else {
            document.getElementById('mvpName').textContent = 'جاري الرصد...';
            document.getElementById('mvpScore').textContent = 'بانتظار تفاعل المودز';
        }

        // 2. Enforcer
        if (data.enforcer) {
            document.getElementById('enforcerName').textContent = data.enforcer.username;
            document.getElementById('enforcerActions').textContent = `${data.enforcer.total_bans} حظر • ${data.enforcer.total_timeouts} كتم`;
            if (data.enforcer.avatar_url) document.getElementById('enforcerAvatar').src = data.enforcer.avatar_url;
        } else {
            document.getElementById('enforcerName').textContent = 'لا توجد إجراءات ردع';
            document.getElementById('enforcerActions').textContent = '0 حظر أو كتم';
        }

        // 3. Chatter
        if (data.chatter) {
            document.getElementById('chatterName').textContent = data.chatter.username;
            document.getElementById('chatterMsgs').textContent = `${data.chatter.total_messages} رسالة في الشات`;
            if (data.chatter.avatar_url) document.getElementById('chatterAvatar').src = data.chatter.avatar_url;
        } else {
            document.getElementById('chatterName').textContent = 'لا توجد رسائل بعد';
            document.getElementById('chatterMsgs').textContent = '0 رسالة';
        }

        // 4. Inactive Count
        document.getElementById('inactiveCount').textContent = data.inactive_count || 0;
    } catch (e) {
        console.error('Failed to load best mods:', e);
    }
}

/**
 * Fetch and Render Stream Reports
 */
async function loadStreamReports() {
    if (!currentChannelId) return;
    try {
        const res = await fetch(`/api/channels/${currentChannelId}/stream-reports`);
        const data = await res.json();
        const tbody = document.getElementById('streamReportsBody');
        if (!data.reports || !data.reports.length) {
            tbody.innerHTML = `<tr><td colspan="7" class="text-center py-10 text-gray-400">
                البث المباشر قيد التسجيل والحفظ في الخلفية 24/7. سيتم تسجيل تقرير الجلسة وتفاصيل حضور المشرفين تلقائياً.
            </td></tr>`;
            return;
        }

        let html = '';
        data.reports.forEach(r => {
            const date = new Date(r.started_at).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
            html += `
                <tr class="hover:bg-[#161c1f] transition">
                    <td class="px-6 py-4 font-mono text-gray-300">${date}</td>
                    <td class="px-6 py-4 font-bold text-white">${r.title || 'بث مباشر'}</td>
                    <td class="px-6 py-4 text-xs font-mono text-[#53fc18]">${r.duration_minutes} دقيقة</td>
                    <td class="px-6 py-4 font-bold text-white">${r.active_mods_count} مشرفين</td>
                    <td class="px-6 py-4 font-semibold text-red-400 font-mono">${r.total_bans}</td>
                    <td class="px-6 py-4 font-semibold text-amber-400 font-mono">${r.total_timeouts}</td>
                    <td class="px-6 py-4 text-gray-300 font-mono">${r.total_mod_messages}</td>
                </tr>
            `;
        });
        tbody.innerHTML = html;
    } catch (e) {
        console.error('Failed to load stream reports:', e);
    }
}

/**
 * Open Moderator Profile Drill-down Modal
 */
async function openModProfile(rawUsername) {
    if (!currentChannelId) return;
    const username = decodeURIComponent(rawUsername);

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/moderator/${encodeURIComponent(username)}`);
        const data = await res.json();
        if (!data.success) {
            showToast('تعذر جلب ملف المشرف', 'error');
            return;
        }

        const m = data.moderator;
        const avatarImg = document.getElementById('profileModAvatarImg');
        if (avatarImg) {
            avatarImg.src = m.avatar_url || 'https://kick.com/favicon.ico';
        }

        document.getElementById('profileModUsername').textContent = m.username;
        const badgeEl = document.getElementById('profileModBadge');
        if (badgeEl) {
            badgeEl.textContent = m.is_bot ? 'بوت معتمد' : 'مشرف معتمد';
            badgeEl.className = m.is_bot
                ? 'text-xs bg-cyan-500/10 text-cyan-400 border border-cyan-500/30 px-2 py-0.5 rounded-full font-mono'
                : 'text-xs bg-[#53fc18]/10 text-[#53fc18] border border-[#53fc18]/30 px-2 py-0.5 rounded-full font-normal';
        }

        document.getElementById('profileModBans').textContent = m.total_bans;
        document.getElementById('profileModTimeouts').textContent = m.total_timeouts;
        document.getElementById('profileModMessages').textContent = m.total_messages;
        document.getElementById('profileModActiveTime').textContent = formatActiveDuration(m.total_active_seconds);

        const firstSeen = m.first_seen ? new Date(m.first_seen).toLocaleDateString('ar-EG') : '-';
        const lastSeen = m.last_seen ? new Date(m.last_seen).toLocaleDateString('ar-EG', { hour: '2-digit', minute: '2-digit' }) : '-';
        document.getElementById('profileModMeta').textContent = `أول تواجد: ${firstSeen} | آخر تفاعل: ${lastSeen}`;

        // Render Action Timeline
        const timeline = document.getElementById('profileModTimeline');
        if (!data.actions.length) {
            timeline.innerHTML = '<div class="text-center py-6 text-gray-500 text-xs">لا توجد عمليات حظر أو كتم سابقة لهذا المشرف.</div>';
        } else {
            let html = '';
            data.actions.forEach(a => {
                const date = new Date(a.created_at).toLocaleDateString('ar-EG', { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' });
                html += `
                    <div class="flex items-center justify-between text-xs p-2 bg-[#131719] border border-[#1e2428] rounded-lg">
                        <div class="flex items-center gap-2">
                            <span class="font-bold ${a.action_type === 'ban' ? 'text-red-400' : 'text-amber-400'}">[${a.action_type.toUpperCase()}]</span>
                            <span>ضد: <strong class="text-white">${a.target_username}</strong></span>
                        </div>
                        <span class="text-gray-500 font-mono text-[11px]">${date}</span>
                    </div>
                `;
            });
            timeline.innerHTML = html;
        }

        openModal('modProfileModal');
    } catch (err) {
        console.error('Failed to load mod profile:', err);
        showToast('خطأ أثناء تحميل بيانات المشرف', 'error');
    }
}

/**
 * Handle Add Channel Form Submission
 */
async function submitAddChannel(e) {
    e.preventDefault();
    const slugInput = document.getElementById('newChannelSlug');
    const webhookInput = document.getElementById('newChannelWebhook');
    const errEl = document.getElementById('addChannelError');
    const btn = document.getElementById('addChannelSubmitBtn');

    errEl.classList.add('hidden');
    btn.disabled = true;
    btn.innerHTML = '<i class="fa-solid fa-spinner animate-spin"></i> جارٍ التحقق...';

    const cleanSlug = slugInput.value.trim().replace(/[^a-zA-Z0-9_-]/g, '').toLowerCase();

    try {
        const res = await fetch('/api/channels', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                slug: cleanSlug,
                discord_webhook: webhookInput.value.trim()
            })
        });

        const data = await res.json();
        if (!data.success) {
            throw new Error(data.error);
        }

        slugInput.value = '';
        webhookInput.value = '';
        closeModal('addChannelModal');
        showToast(`تمت إضافة قناة @${data.channel.slug} وتفعيل المراقبة 24/7!`, 'success');
        await loadChannels(data.channel.id);
        switchView('dashboard');
    } catch (err) {
        errEl.textContent = err.message || 'حدث خطأ أثناء إضافة القناة';
        errEl.classList.remove('hidden');
    } finally {
        btn.disabled = false;
        btn.innerHTML = '<span>إضافة وتفعيل</span>';
    }
}

/**
 * Channel Settings & Discord Webhook
 */
function openChannelSettings() {
    if (!currentChannelId) return;
    const select = document.getElementById('channelSelect');
    const selectedOption = select.options[select.selectedIndex];
    document.getElementById('settingsChannelTitle').textContent = `إعدادات قناة ${selectedOption.textContent}`;
    document.getElementById('settingsWebhookInput').value = selectedOption.dataset.webhook || '';
    document.getElementById('webhookSaveStatus').textContent = '';
    openModal('channelSettingsModal');
}

async function saveWebhook() {
    if (!currentChannelId) return;
    const webhookUrl = document.getElementById('settingsWebhookInput').value.trim();
    const statusEl = document.getElementById('webhookSaveStatus');
    statusEl.textContent = 'جارٍ الحفظ والفحص...';

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/webhook`, {
            method: 'PATCH',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ discord_webhook: webhookUrl })
        });
        const data = await res.json();
        if (data.success) {
            statusEl.textContent = data.webhookValid ? 'تم الحفظ وإرسال إشعار تجريبي بنجاح' : 'تم الحفظ بنجاح.';
            statusEl.className = 'text-xs text-[#53fc18]';
            const select = document.getElementById('channelSelect');
            select.options[select.selectedIndex].dataset.webhook = webhookUrl;
            showToast('تم حفظ رابط الويب هوك بنجاح', 'success');
        } else {
            statusEl.textContent = 'حدث خطأ: ' + data.error;
            statusEl.className = 'text-xs text-red-400';
        }
    } catch (err) {
        statusEl.textContent = 'خطأ بالاتصال بالسيرفر';
        statusEl.className = 'text-xs text-red-400';
    }
}

async function deleteCurrentChannel() {
    if (!currentChannelId) return;
    if (!confirm('هل أنت متأكد من حذف هذه القناة وجميع سجلاتها من المراقبة؟')) return;

    try {
        const res = await fetch(`/api/channels/${currentChannelId}`, { method: 'DELETE' });
        const data = await res.json();
        if (data.success) {
            closeModal('channelSettingsModal');
            showToast('تم حذف القناة وسجلاتها', 'info');
            await loadChannels();
        }
    } catch (err) {
        showToast('حدث خطأ أثناء الحذف', 'error');
    }
}

/**
 * Fetch and Render Mod Actions Audit Log
 */
async function loadAuditLogs() {
    if (!currentChannelId) return;

    const filterType = document.getElementById('actionFilterSelect')?.value || 'all';
    try {
        const res = await fetch(`/api/channels/${currentChannelId}/actions?type=${filterType}`);
        const data = await res.json();
        if (!data.success) return;

        const tbody = document.getElementById('auditLogsBody');
        if (!data.actions.length) {
            tbody.innerHTML = `<tr><td colspan="5" class="text-center py-10 text-gray-500">لا توجد عمليات إشراف مسجلة بعد.</td></tr>`;
            return;
        }

        let html = '';
        data.actions.forEach(act => {
            let badge = '';
            let durationText = '-';

            if (act.action_type === 'ban') {
                badge = `<span class="bg-red-500/10 text-red-400 border border-red-500/30 px-2 py-0.5 rounded text-xs font-semibold">حظر دائم</span>`;
            } else if (act.action_type === 'timeout') {
                const mins = act.duration_seconds >= 60 ? `${Math.round(act.duration_seconds / 60)} دقيقة` : `${act.duration_seconds} ثانية`;
                badge = `<span class="bg-amber-500/10 text-amber-400 border border-amber-500/30 px-2 py-0.5 rounded text-xs font-semibold">كتم مؤقت</span>`;
                durationText = mins;
            } else if (act.action_type === 'unban') {
                badge = `<span class="bg-blue-500/10 text-blue-400 border border-blue-500/30 px-2 py-0.5 rounded text-xs font-semibold">إلغاء حظر</span>`;
            } else {
                badge = `<span class="bg-purple-500/10 text-purple-400 border border-purple-500/30 px-2 py-0.5 rounded text-xs font-semibold">حذف رسالة</span>`;
            }

            const time = new Date(act.created_at).toLocaleDateString('ar-EG', {
                month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit'
            });

            html += `
                <tr class="hover:bg-[#161c1f] transition">
                    <td class="px-6 py-3.5 font-bold text-white">${act.moderator_username}</td>
                    <td class="px-6 py-3.5">${badge}</td>
                    <td class="px-6 py-3.5 text-gray-300 font-mono">${act.target_username || 'الرسالة'}</td>
                    <td class="px-6 py-3.5 text-xs text-gray-400">${durationText} ${act.reason ? `(${act.reason})` : ''}</td>
                    <td class="px-6 py-3.5 text-xs text-gray-400 font-mono">${time}</td>
                </tr>
            `;
        });

        tbody.innerHTML = html;
    } catch (err) {
        console.error('Failed to load audit logs:', err);
    }
}

/**
 * Simulate Test Action (Ban or Timeout) to test dashboard live
 */
async function simulateTestAction() {
    if (!currentChannelId) {
        showToast('يرجى اختيار أو إضافة قناة أولاً!', 'error');
        return;
    }

    const types = ['timeout', 'ban'];
    const randomType = types[Math.floor(Math.random() * types.length)];
    const sampleMods = ['KALACLIPS', 'LeMo_99', 'Mai_Essam', 'AL3OTIBI', 'ItsJadeer'];
    const sampleTargets = ['Spammer123', 'ToxicViewer', 'TrollGuy', 'BotUser_9'];

    const randomMod = sampleMods[Math.floor(Math.random() * sampleMods.length)];
    const randomTarget = sampleTargets[Math.floor(Math.random() * sampleTargets.length)];

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/simulate`, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                action_type: randomType,
                moderator: randomMod,
                target_user: randomTarget,
                duration: randomType === 'timeout' ? 300 : 0
            })
        });
        const data = await res.json();
        if (data.success) {
            showToast(`تم تنفيذ تجربة إجراء (${randomType === 'ban' ? 'حظر' : 'كتم'}) بواسطة ${randomMod}!`, 'success');
        } else {
            showToast('فشل تنفيذ التجربة: ' + (data.error || 'خطأ'), 'error');
        }
    } catch (err) {
        console.error('Failed to simulate action:', err);
        showToast('خطأ بالاتصال أثناء التجربة', 'error');
    }
}

/**
 * Export CSV / JSON with direct download link (bypasses popup blocker)
 */
function exportData(format) {
    if (!currentChannelId) {
        showToast('يرجى اختيار قناة أولاً للتصدير!', 'error');
        return;
    }

    showToast(`جارٍ تحضير ملف الـ ${format.toUpperCase()}...`, 'info');
    const downloadUrl = `/api/channels/${currentChannelId}/export?format=${format}`;
    const a = document.createElement('a');
    a.href = downloadUrl;
    a.download = `kickmod_${currentChannelSlug || 'channel'}_audit.${format}`;
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

/**
 * Force Resync Channel Data & Active Chatters
 */
async function forceResyncChannel() {
    if (!currentChannelId) {
        showToast('يرجى اختيار قناة أولاً!', 'error');
        return;
    }

    const icon = document.getElementById('resyncBtnIcon');
    const btn = document.getElementById('resyncBtn');
    if (icon) icon.classList.add('fa-spin');
    if (btn) btn.disabled = true;

    showToast('جارٍ مزامنة المشرفين وبيانات القناة من سيرفرات كيك...', 'info');

    try {
        const res = await fetch(`/api/channels/${currentChannelId}/resync`, { method: 'POST' });
        const data = await res.json();
        if (data.success) {
            showToast('تمت المزامنة الفورية وتحديث المشرفين بنجاح!', 'success');
            await loadChannels(currentChannelId);
            await loadOverview();
            await loadLeaderboard();
            await loadBestMods();
            await loadAuditLogs();
        } else {
            showToast('حدث خطأ أثناء المزامنة: ' + (data.error || 'فشل الاتصال'), 'error');
        }
    } catch (e) {
        showToast('تعذر الاتصال بالسيرفر للمزامنة', 'error');
    } finally {
        if (icon) icon.classList.remove('fa-spin');
        if (btn) btn.disabled = false;
    }
}

/**
 * Toast Notifications (Clean SVGs - No Emojis)
 */
function showToast(message, type = 'info') {
    const container = document.getElementById('toastContainer');
    if (!container) return;

    const toast = document.createElement('div');
    const colors = {
        success: 'bg-[#131719] border-[#53fc18] text-[#53fc18]',
        error: 'bg-[#131719] border-red-500 text-red-400',
        info: 'bg-[#131719] border-blue-500 text-blue-400'
    };

    toast.className = `pointer-events-auto flex items-center gap-2.5 px-4 py-3 rounded-xl border ${colors[type] || colors.info} shadow-2xl text-xs font-bold transition-all duration-300 transform translate-y-2 opacity-0 backdrop-blur-md`;
    toast.innerHTML = `
        <span class="w-2 h-2 rounded-full ${type === 'error' ? 'bg-red-400' : (type === 'success' ? 'bg-[#53fc18]' : 'bg-blue-400')}"></span>
        <span>${message}</span>
    `;

    container.appendChild(toast);
    requestAnimationFrame(() => {
        toast.classList.remove('translate-y-2', 'opacity-0');
    });

    setTimeout(() => {
        toast.classList.add('translate-y-2', 'opacity-0');
        setTimeout(() => toast.remove(), 300);
    }, 3500);
}

/**
 * Modal Helpers
 */
function openModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.remove('hidden');
}

function closeModal(id) {
    const el = document.getElementById(id);
    if (el) el.classList.add('hidden');
}

const Pusher = require('pusher-js');
const crypto = require('crypto');
const { dbAsync } = require('../db/database');
const { sendModActionEmbed } = require('./discordService');

/**
 * Accurately parses SQLite datetime strings avoiding timezone drift
 */
function parseSqliteDate(dateStr) {
    if (!dateStr) return new Date();
    if (typeof dateStr !== 'string') return new Date(dateStr);
    const cleaned = dateStr.includes('T') ? dateStr : dateStr.replace(' ', 'T');
    return new Date(cleaned.endsWith('Z') ? cleaned : cleaned + 'Z');
}

class KickService {
    constructor() {
        this.activeConnections = new Map(); // slug -> { pusher, channel }
        this.io = null;
        this.workerInterval = null;
    }

    setSocketIO(ioInstance) {
        this.io = ioInstance;
    }

    /**
     * Resolves Kick Channel Details
     */
    async resolveChannel(slug) {
        const cleanSlug = slug.trim().toLowerCase();
        
        // Attempt 1: Official v1 endpoint with chatroom metadata
        try {
            const controller = new AbortController();
            const timeout = setTimeout(() => controller.abort(), 6000);
            const res = await fetch(`https://kick.com/api/v1/channels/${cleanSlug}`, {
                signal: controller.signal,
                headers: {
                    'User-Agent': 'Mozilla/5.0',
                    'Accept': 'application/json'
                }
            });
            clearTimeout(timeout);

            if (res.ok) {
                const data = await res.json();
                const chatroomId = data.chatroom?.id;
                if (!chatroomId) throw new Error('Could not find chatroomId in v1 response');

                return {
                    slug: data.slug || cleanSlug,
                    name: data.user?.username || cleanSlug,
                    kick_channel_id: data.id,
                    chatroom_id: chatroomId,
                    avatar_url: data.user?.profile_pic || 'https://kick.com/favicon.ico',
                    banner_url: data.banner_image?.url || null,
                    is_live: !!data.livestream
                };
            }
        } catch (e) {
            console.warn(`[KickService] v1 fetch failed for ${cleanSlug}, trying fallback:`, e.message);
        }

        // Attempt 2: Official Kick Developer API
        try {
            const tokenRes = await fetch('https://id.kick.com/oauth/token', {
                method: 'POST',
                headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
                body: new URLSearchParams({
                    client_id: process.env.KICK_CLIENT_ID || '01M7KBB170ZT4RE995TPP7FRG0',
                    client_secret: process.env.KICK_CLIENT_SECRET || 'f6be34c54ed657c860e7eb72fde2f4787cbed2bef7b17a56c83725af22e75723',
                    grant_type: 'client_credentials'
                })
            });

            if (tokenRes.ok) {
                const tokenData = await tokenRes.json();
                const bearer = tokenData.access_token;

                const chanRes = await fetch(`https://api.kick.com/public/v1/channels?slug=${cleanSlug}`, {
                    headers: { 'Authorization': `Bearer ${bearer}`, 'Accept': 'application/json' }
                });

                if (chanRes.ok) {
                    const chanData = await chanRes.json();
                    const ch = chanData.data?.[0];
                    if (ch) {
                        let avatarUrl = 'https://kick.com/favicon.ico';
                        let userName = ch.slug;
                        let bannerUrl = ch.banner_picture || null;
                        
                        let kickChanId = ch.broadcaster_user_id;
                        if (ch.banner_picture) {
                            const chanMatch = ch.banner_picture.match(/channel\/(\d+)/);
                            if (chanMatch) kickChanId = parseInt(chanMatch[1]);
                        }

                        try {
                            const userRes = await fetch(`https://api.kick.com/public/v1/users?id=${ch.broadcaster_user_id}`, {
                                headers: { 'Authorization': `Bearer ${bearer}`, 'Accept': 'application/json' }
                            });
                            if (userRes.ok) {
                                const userData = await userRes.json();
                                const u = userData.data?.[0];
                                if (u) {
                                    if (u.profile_picture) avatarUrl = u.profile_picture;
                                    if (u.name) userName = u.name;
                                }
                            }
                        } catch (ue) {
                            console.warn('[KickService] User profile pic fetch fallback:', ue.message);
                        }

                        return {
                            slug: ch.slug || cleanSlug,
                            name: userName,
                            kick_channel_id: kickChanId,
                            chatroom_id: kickChanId,
                            avatar_url: avatarUrl,
                            banner_url: bannerUrl,
                            is_live: ch.stream?.is_live || false
                        };
                    }
                }
            }
        } catch (e) {
            console.error(`[KickService] Official API failed for ${cleanSlug}:`, e.message);
        }

        throw new Error(`تعذر العثور على قناة "${slug}" على منصة Kick. يرجى التأكد من كتابة الاسم بالشكل الصحيح.`);
    }

    /**
     * Obtains dynamic Pusher credentials from Kick realtime negotiation endpoint
     */
    async getPusherCredentials(channelId) {
        const url = `https://web.kick.com/api/v1/realtime/channels/${channelId}/chat/connection`;
        try {
            const res = await fetch(url, {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36'
                },
                body: JSON.stringify({
                    client: {
                        id: crypto.randomUUID(),
                        type: 'web'
                    },
                    capabilities: {
                        accepted_providers: [{ provider: 'pusher' }]
                    }
                })
            });

            if (res.ok) {
                const data = await res.json();
                const conn = data?.data?.connections?.[0];
                if (conn && conn.credentials) {
                    return {
                        app_key: conn.credentials.app_key,
                        cluster: conn.credentials.cluster
                    };
                }
            }
        } catch (err) {
            console.warn(`Could not negotiate dynamic pusher key for channel ${channelId}, falling back to default`, err.message);
        }

        // Reliable fallback values
        return {
            app_key: '34bf7a0ff419a2a775b9',
            cluster: 'us2'
        };
    }

    /**
     * Subscribes to real-time chat & moderation events for a given channel
     */
    async startMonitoring(channelRecord) {
        const slug = channelRecord.slug.toLowerCase();

        // Disconnect existing if any
        this.stopMonitoring(slug);

        console.log(`[KickService] Initializing real-time monitor for channel: ${slug} (Chatroom: ${channelRecord.chatroom_id})`);

        const credentials = await this.getPusherCredentials(channelRecord.kick_channel_id);

        const pusher = new Pusher(credentials.app_key, {
            cluster: credentials.cluster,
            forceTLS: true
        });

        const chatChannelName = `chatrooms.${channelRecord.chatroom_id}.v2`;
        const channel = pusher.subscribe(chatChannelName);

        channel.bind('pusher:subscription_succeeded', () => {
            console.log(`[KickService] ✅ Connected and listening to channel: ${slug}`);
            if (this.io) {
                this.io.emit('channel_connected', { channel_id: channelRecord.id, slug });
            }
        });

        // 1. Handle Chat Messages (track active mods and their messages)
        channel.bind('App\\Events\\ChatMessageEvent', async (rawData) => {
            try {
                const data = typeof rawData === 'string' ? JSON.parse(rawData) : rawData;
                await this.handleChatMessage(channelRecord, data);
            } catch (err) {
                console.error('[KickService] ChatMessage parse error:', err.message);
            }
        });

        // 2. Handle Moderation Bans & Timeouts
        channel.bind('App\\Events\\UserBannedEvent', async (rawData) => {
            try {
                const data = typeof rawData === 'string' ? JSON.parse(rawData) : rawData;
                await this.handleUserBanned(channelRecord, data);
            } catch (err) {
                console.error('[KickService] UserBanned parse error:', err.message);
            }
        });

        // 3. Handle Message Deletions
        channel.bind('App\\Events\\MessageDeletedEvent', async (rawData) => {
            try {
                const data = typeof rawData === 'string' ? JSON.parse(rawData) : rawData;
                await this.handleMessageDeleted(channelRecord, data);
            } catch (err) {
                console.error('[KickService] MessageDeleted parse error:', err.message);
            }
        });

        // 4. Handle Unbans
        channel.bind('App\\Events\\UserUnbannedEvent', async (rawData) => {
            try {
                const data = typeof rawData === 'string' ? JSON.parse(rawData) : rawData;
                await this.handleUserUnbanned(channelRecord, data);
            } catch (err) {
                console.error('[KickService] UserUnbanned parse error:', err.message);
            }
        });

        // Initial chatters sync and setup periodic polling
        this.syncActiveChatters(channelRecord);
        const chatterInterval = setInterval(() => {
            this.syncActiveChatters(channelRecord);
        }, 45000);

        this.activeConnections.set(slug, { pusher, channel, channelRecord, chatterInterval });
    }

    /**
     * Poll Kick active-chatters endpoint to discover all lurking and active moderators
     */
    async syncActiveChatters(channelRecord) {
        if (!channelRecord.kick_channel_id) return;
        try {
            const url = `https://web.kick.com/api/v1/channels/${channelRecord.kick_channel_id}/chat/active-chatters`;
            const res = await fetch(url, {
                headers: { 'User-Agent': 'Mozilla/5.0', 'Accept': 'application/json' }
            });
            if (!res.ok) return;

            const data = await res.json();
            const onlineMods = data.data?.moderators || [];
            const KNOWN_BOTS = ['botrix', 'nightbot', 'streamlabs', 'kickbot', 'streamelements', 'moobot'];
            const onlineSet = new Set(onlineMods.map(m => m.username.toLowerCase()));

            for (const mod of onlineMods) {
                const isBot = KNOWN_BOTS.includes(mod.username.toLowerCase()) || /bot$/i.test(mod.username);
                
                await dbAsync.run(`
                    INSERT INTO moderators (channel_id, username, avatar_url, first_seen, last_seen, is_online, is_bot)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1, ?)
                    ON CONFLICT(channel_id, username) DO UPDATE SET
                        last_seen = CURRENT_TIMESTAMP,
                        is_online = 1,
                        avatar_url = COALESCE(?, avatar_url)
                `, [channelRecord.id, mod.username, mod.profile_picture, isBot ? 1 : 0, mod.profile_picture]);

                await this.trackModeratorAttendance(channelRecord.id, mod.username);
            }

            // Mark any mod not in online list as is_online = 0 and close their open attendance session
            if (onlineSet.size > 0) {
                const allMods = await dbAsync.all('SELECT username FROM moderators WHERE channel_id = ?', [channelRecord.id]);
                for (const m of allMods) {
                    if (!onlineSet.has(m.username.toLowerCase())) {
                        await dbAsync.run('UPDATE moderators SET is_online = 0 WHERE channel_id = ? AND username = ?', [channelRecord.id, m.username]);
                        await dbAsync.run(`
                            UPDATE mod_attendance_sessions 
                            SET ended_at = last_ping_at 
                            WHERE channel_id = ? AND moderator_username = ? AND ended_at IS NULL
                        `, [channelRecord.id, m.username]);
                    }
                }
            }

            if (this.io) {
                this.io.emit('active_chatters_updated', {
                    channel_id: channelRecord.id,
                    channel_slug: channelRecord.slug,
                    online_count: onlineMods.length,
                    online_mods: onlineMods.map(m => m.username)
                });
            }
        } catch (e) {
            console.warn(`[KickService] syncActiveChatters error for ${channelRecord.slug}:`, e.message);
        }
    }

    /**
     * Process incoming chat messages to identify and log moderator activity
     */
    async handleChatMessage(channelRecord, data) {
        const sender = data?.sender;
        if (!sender) return;

        const badges = sender.identity?.badges || [];
        const badgesV2 = sender.identity?.badges_v2 || [];

        const isMod = badges.some(b => b.type === 'moderator' || b.text === 'Moderator') ||
                      badgesV2.some(b => b.badge_type === 'moderator' || b.name === 'moderator');

        const isBroadcaster = badges.some(b => b.type === 'broadcaster' || b.text === 'Broadcaster') ||
                              badgesV2.some(b => b.badge_type === 'broadcaster' || b.name === 'broadcaster') ||
                              sender.username.toLowerCase() === channelRecord.slug.toLowerCase();

        const KNOWN_BOTS = ['botrix', 'nightbot', 'streamlabs', 'kickbot', 'streamelements', 'moobot'];
        const isBot = KNOWN_BOTS.includes(sender.username.toLowerCase()) || 
                      /bot$/i.test(sender.username) || 
                      badges.some(b => b.type === 'bot' || b.text?.toLowerCase().includes('bot'));

        // Broadcast general chat message to live chat preview with color & badges
        if (this.io) {
            this.io.emit('chat_stream_message', {
                channel_id: channelRecord.id,
                channel_slug: channelRecord.slug,
                sender: sender.username,
                sender_color: sender.identity?.color || '#53fc18',
                content: data.content,
                is_mod: isMod,
                is_broadcaster: isBroadcaster,
                is_bot: isBot,
                timestamp: new Date().toISOString()
            });
        }

        // Only track moderators and broadcasters
        if (!isMod && !isBroadcaster) return;

        const username = sender.username;
        const userId = sender.id;
        const profilePic = sender.profile_pic || null;

        console.log(`[KickService] 🛡️ Moderator message in ${channelRecord.slug} by ${username} (Bot: ${isBot}): "${data.content}"`);

        // Upsert Moderator in database with is_bot flag
        await dbAsync.run(`
            INSERT INTO moderators (channel_id, username, user_id, avatar_url, first_seen, last_seen, total_messages, is_online, is_bot)
            VALUES (?, ?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 1, 1, ?)
            ON CONFLICT(channel_id, username) DO UPDATE SET
                last_seen = CURRENT_TIMESTAMP,
                total_messages = total_messages + 1,
                is_online = 1,
                is_bot = ?,
                avatar_url = COALESCE(?, avatar_url)
        `, [channelRecord.id, username, userId, profilePic, isBot ? 1 : 0, isBot ? 1 : 0, profilePic]);

        // Track Mod Attendance Session (مدة التواجد)
        await this.trackModeratorAttendance(channelRecord.id, username);

        // Upsert daily session
        await dbAsync.run(`
            INSERT INTO mod_sessions (channel_id, moderator_username, session_date, messages_count, actions_count, last_activity)
            VALUES (?, ?, CURRENT_DATE, 1, 0, CURRENT_TIMESTAMP)
            ON CONFLICT(channel_id, moderator_username, session_date) DO UPDATE SET
                messages_count = messages_count + 1,
                last_activity = CURRENT_TIMESTAMP
        `, [channelRecord.id, username]);

        // Emit real-time mod message event to live dashboard
        if (this.io) {
            this.io.emit('mod_message', {
                channel_id: channelRecord.id,
                channel_slug: channelRecord.slug,
                moderator: username,
                content: data.content,
                is_broadcaster: isBroadcaster,
                timestamp: new Date().toISOString()
            });
        }
    }

    /**
     * Attendance Time Tracker (حساب مدة وساعات تواجد المود بدقة متناهية بناءً على الوقت الحقيقي)
     */
    async trackModeratorAttendance(channelId, username) {
        try {
            const activeReport = await dbAsync.get(
                'SELECT id, started_at FROM stream_reports WHERE channel_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1',
                [channelId]
            );
            const streamReportId = activeReport ? activeReport.id : null;
            const reportStartedAt = activeReport ? activeReport.started_at : null;

            // Resolve canonical casing for moderator username from DB
            const existingMod = await dbAsync.get(
                'SELECT username FROM moderators WHERE channel_id = ? AND LOWER(username) = LOWER(?)',
                [channelId, username]
            );
            const canonicalUser = existingMod ? existingMod.username : username;

            const activeSession = await dbAsync.get(`
                SELECT * FROM mod_attendance_sessions 
                WHERE channel_id = ? AND LOWER(moderator_username) = LOWER(?) AND ended_at IS NULL
                ORDER BY id DESC LIMIT 1
            `, [channelId, canonicalUser]);

            const now = new Date();

            if (activeSession) {
                const lastPing = parseSqliteDate(activeSession.last_ping_at);
                const diffMinutes = (now.getTime() - lastPing.getTime()) / (1000 * 60);

                if (diffMinutes <= 10) {
                    // Ongoing session: accurately calculate total elapsed seconds from session start
                    const startTime = parseSqliteDate(activeSession.started_at);
                    const durationSec = Math.max(1, Math.round((now.getTime() - startTime.getTime()) / 1000));

                    await dbAsync.run(`
                        UPDATE mod_attendance_sessions 
                        SET last_ping_at = CURRENT_TIMESTAMP, duration_seconds = ?, stream_report_id = COALESCE(stream_report_id, ?)
                        WHERE id = ?
                    `, [durationSec, streamReportId, activeSession.id]);

                    // Calculate live active seconds for current stream report (or cumulative if no live report)
                    let liveSeconds = durationSec;
                    if (streamReportId) {
                        const sumRow = await dbAsync.get(`
                            SELECT COALESCE(SUM(duration_seconds), 0) as s 
                            FROM mod_attendance_sessions 
                            WHERE channel_id = ? AND LOWER(moderator_username) = LOWER(?) 
                            AND (stream_report_id = ? OR started_at >= ?)
                        `, [channelId, canonicalUser, streamReportId, reportStartedAt]);
                        liveSeconds = sumRow ? sumRow.s : durationSec;
                    }

                    await dbAsync.run(`
                        UPDATE moderators 
                        SET total_active_seconds = ?, is_online = 1, last_seen = CURRENT_TIMESTAMP
                        WHERE channel_id = ? AND username = ?
                    `, [liveSeconds, channelId, canonicalUser]);
                    return;
                } else {
                    // Previous session timed out (>10 mins inactivity): close it
                    await dbAsync.run(`
                        UPDATE mod_attendance_sessions 
                        SET ended_at = last_ping_at 
                        WHERE id = ?
                    `, [activeSession.id]);
                }
            }

            // Start a new attendance session linked to current live stream
            await dbAsync.run(`
                INSERT INTO mod_attendance_sessions (channel_id, stream_report_id, moderator_username, started_at, last_ping_at, duration_seconds)
                VALUES (?, ?, ?, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP, 0)
            `, [channelId, streamReportId, canonicalUser]);

            let initialLiveSecs = 0;
            if (streamReportId) {
                const sumRow = await dbAsync.get(`
                    SELECT COALESCE(SUM(duration_seconds), 0) as s 
                    FROM mod_attendance_sessions 
                    WHERE channel_id = ? AND LOWER(moderator_username) = LOWER(?) 
                    AND (stream_report_id = ? OR started_at >= ?)
                `, [channelId, canonicalUser, streamReportId, reportStartedAt]);
                initialLiveSecs = sumRow ? sumRow.s : 0;
            }

            await dbAsync.run(`
                UPDATE moderators 
                SET total_active_seconds = ?, is_online = 1, last_seen = CURRENT_TIMESTAMP
                WHERE channel_id = ? AND username = ?
            `, [initialLiveSecs, channelId, canonicalUser]);
        } catch (err) {
            console.error('[AttendanceTracker Error]:', err.message);
        }
    }

    /**
     * Process User Banned / Timed out event
     */
    async handleUserBanned(channelRecord, data) {
        console.log(`[KickService] UserBanned event received:`, JSON.stringify(data));
        const targetUser = data?.user?.username || 'Unknown';
        const targetUserId = data?.user?.id || null;
        const rawModName = data?.banned_by?.username || 'Channel Mod';
        const expiresAt = data?.expires_at; // ISO date string if timeout, null/undefined if permanent ban

        // Canonical moderator name lookup
        const existingMod = await dbAsync.get(
            'SELECT username FROM moderators WHERE channel_id = ? AND LOWER(username) = LOWER(?)',
            [channelRecord.id, rawModName]
        );
        const moderator = existingMod ? existingMod.username : rawModName;

        let actionType = 'ban';
        let durationSeconds = 0;

        if (expiresAt) {
            const expiryTime = new Date(expiresAt).getTime();
            const now = Date.now();
            if (expiryTime > now) {
                durationSeconds = Math.round((expiryTime - now) / 1000);
            }
            // If duration is more than 365 days or explicitly marked permanent, classify as ban
            if (durationSeconds >= 31536000 || data?.permanent === true || data?.is_permanent === true) {
                actionType = 'ban';
            } else {
                actionType = 'timeout';
            }
        } else {
            // Null or missing expires_at means permanent ban on Kick
            actionType = 'ban';
        }

        // Look up active stream report to save action per live
        const activeReport = await dbAsync.get(
            'SELECT id FROM stream_reports WHERE channel_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1',
            [channelRecord.id]
        );
        const streamReportId = activeReport ? activeReport.id : null;

        // 1. Insert into Audit Log with stream_report_id
        await dbAsync.run(`
            INSERT INTO mod_actions (channel_id, stream_report_id, moderator_username, action_type, target_username, target_user_id, duration_seconds)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `, [channelRecord.id, streamReportId, moderator, actionType, targetUser, targetUserId, durationSeconds]);

        if (streamReportId) {
            if (actionType === 'ban') {
                await dbAsync.run('UPDATE stream_reports SET total_bans = total_bans + 1 WHERE id = ?', [streamReportId]);
            } else {
                await dbAsync.run('UPDATE stream_reports SET total_timeouts = total_timeouts + 1 WHERE id = ?', [streamReportId]);
            }
        }

        // 2. Update Moderator Stats (upsert with canonical username)
        if (actionType === 'ban') {
            await dbAsync.run(`
                INSERT INTO moderators (channel_id, username, total_bans, last_seen)
                VALUES (?, ?, 1, CURRENT_TIMESTAMP)
                ON CONFLICT(channel_id, username) DO UPDATE SET
                    total_bans = total_bans + 1,
                    last_seen = CURRENT_TIMESTAMP
            `, [channelRecord.id, moderator]);
        } else {
            await dbAsync.run(`
                INSERT INTO moderators (channel_id, username, total_timeouts, last_seen)
                VALUES (?, ?, 1, CURRENT_TIMESTAMP)
                ON CONFLICT(channel_id, username) DO UPDATE SET
                    total_timeouts = total_timeouts + 1,
                    last_seen = CURRENT_TIMESTAMP
            `, [channelRecord.id, moderator]);
        }

        // 3. Update Daily Session actions
        await this.trackModeratorAttendance(channelRecord.id, moderator);
        await dbAsync.run(`
            INSERT INTO mod_sessions (channel_id, moderator_username, session_date, messages_count, actions_count, last_activity)
            VALUES (?, ?, CURRENT_DATE, 0, 1, CURRENT_TIMESTAMP)
            ON CONFLICT(channel_id, moderator_username, session_date) DO UPDATE SET
                actions_count = actions_count + 1,
                last_activity = CURRENT_TIMESTAMP
        `, [channelRecord.id, moderator]);

        // 4. Send to Discord Webhook if configured
        if (channelRecord.discord_webhook) {
            sendModActionEmbed(channelRecord.discord_webhook, {
                channelName: channelRecord.slug,
                moderator,
                actionType,
                targetUser,
                durationSeconds
            });
        }

        // 5. Emit to Socket.io for live UI update
        if (this.io) {
            this.io.emit('mod_action', {
                channel_id: channelRecord.id,
                channel_slug: channelRecord.slug,
                moderator,
                action_type: actionType,
                target_user: targetUser,
                duration_seconds: durationSeconds,
                created_at: new Date().toISOString()
            });
        }
    }

    /**
     * Process message deletion
     */
    async handleMessageDeleted(channelRecord, data) {
        const messageId = data?.message?.id || null;
        await dbAsync.run(`
            INSERT INTO mod_actions (channel_id, moderator_username, action_type, reason)
            VALUES (?, 'Moderator', 'delete_message', ?)
        `, [channelRecord.id, `Deleted message ID: ${messageId}`]);

        if (this.io) {
            this.io.emit('mod_action', {
                channel_id: channelRecord.id,
                channel_slug: channelRecord.slug,
                moderator: 'Moderator',
                action_type: 'delete_message',
                target_user: 'Message',
                duration_seconds: 0,
                created_at: new Date().toISOString()
            });
        }
    }

    /**
     * Process unban
     */
    async handleUserUnbanned(channelRecord, data) {
        const targetUser = data?.user?.username || 'Unknown';
        const moderator = data?.unbanned_by?.username || 'Moderator';

        await dbAsync.run(`
            INSERT INTO mod_actions (channel_id, moderator_username, action_type, target_username)
            VALUES (?, ?, 'unban', ?)
        `, [channelRecord.id, moderator, targetUser]);

        if (this.io) {
            this.io.emit('mod_action', {
                channel_id: channelRecord.id,
                channel_slug: channelRecord.slug,
                moderator,
                action_type: 'unban',
                target_user: targetUser,
                duration_seconds: 0,
                created_at: new Date().toISOString()
            });
        }
    }

    /**
     * Stop monitoring a channel
     */
    stopMonitoring(slug) {
        const cleanSlug = slug.toLowerCase();
        if (this.activeConnections.has(cleanSlug)) {
            const { pusher, chatterInterval } = this.activeConnections.get(cleanSlug);
            if (chatterInterval) clearInterval(chatterInterval);
            pusher.disconnect();
            this.activeConnections.delete(cleanSlug);
            console.log(`[KickService] Stopped monitoring for: ${cleanSlug}`);
        }
    }

    /**
     * Boot up monitoring for all active channels in the database and launch 24/7 worker
     */
    async loadAndStartAllChannels() {
        const channels = await dbAsync.all('SELECT * FROM channels WHERE is_monitored = 1');
        console.log(`[KickService] Found ${channels.length} active channel(s) in database.`);
        for (const ch of channels) {
            try {
                await this.startMonitoring(ch);
            } catch (err) {
                console.error(`[KickService] Error starting channel ${ch.slug}:`, err.message);
            }
        }

        // Start continuous 24/7 background worker
        this.start24x7Worker();
    }

    /**
     * Continuous 24/7 Background Watcher for all registered channels
     */
    start24x7Worker() {
        if (this.workerInterval) clearInterval(this.workerInterval);

        console.log('[KickService] 🔄 24/7 Continuous Background Stream & Moderation Worker Started');
        
        // Execute every 60 seconds
        this.workerInterval = setInterval(async () => {
            try {
                const channels = await dbAsync.all('SELECT * FROM channels WHERE is_monitored = 1');
                for (const ch of channels) {
                    try {
                        // Check channel live status
                        const details = await this.resolveChannel(ch.slug);
                        
                        // Update banner or avatar if updated on Kick
                        if (details.banner_url && details.banner_url !== ch.banner_url) {
                            await dbAsync.run('UPDATE channels SET banner_url = ? WHERE id = ?', [details.banner_url, ch.id]);
                        }
                        if (details.avatar_url && details.avatar_url !== ch.avatar_url) {
                            await dbAsync.run('UPDATE channels SET avatar_url = ? WHERE id = ?', [details.avatar_url, ch.id]);
                        }

                        // Ensure WebSocket Pusher is connected
                        if (!this.activeConnections.has(ch.slug.toLowerCase())) {
                            await this.startMonitoring(ch);
                        }

                        // Sync active chatters & attendance
                        await this.syncActiveChatters(ch);

                        // Stream sessions recording
                        if (details.is_live) {
                            const activeReport = await dbAsync.get(
                                'SELECT * FROM stream_reports WHERE channel_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1',
                                [ch.id]
                            );

                            const currentOnline = await dbAsync.get(
                                'SELECT COUNT(*) as count FROM moderators WHERE channel_id = ? AND is_online = 1',
                                [ch.id]
                            );

                            if (!activeReport) {
                                const newRep = await dbAsync.run(`
                                    INSERT INTO stream_reports (channel_id, title, category, started_at, active_mods_count)
                                    VALUES (?, ?, ?, CURRENT_TIMESTAMP, ?)
                                `, [ch.id, `بث مباشر قناة ${ch.slug}`, 'Kick Live', currentOnline?.count || 1]);

                                console.log(`[KickService] 🔴 Live stream started for channel: ${ch.slug} (Report #${newRep.lastID})`);

                                if (this.io) {
                                    this.io.emit('stream_status_changed', {
                                        channel_id: ch.id,
                                        channel_slug: ch.slug,
                                        is_live: true,
                                        report_id: newRep.lastID,
                                        started_at: new Date().toISOString()
                                    });
                                }
                            } else {
                                const startTime = parseSqliteDate(activeReport.started_at);
                                const durationMinutes = Math.max(1, Math.round((Date.now() - startTime.getTime()) / (1000 * 60)));
                                
                                const actCounts = await dbAsync.get(`
                                    SELECT 
                                        COUNT(CASE WHEN action_type = 'ban' THEN 1 END) as bans,
                                        COUNT(CASE WHEN action_type = 'timeout' THEN 1 END) as timeouts
                                    FROM mod_actions 
                                    WHERE channel_id = ? AND (stream_report_id = ? OR created_at >= ?)
                                `, [ch.id, activeReport.id, activeReport.started_at]);

                                await dbAsync.run(`
                                    UPDATE stream_reports 
                                    SET duration_minutes = ?,
                                        active_mods_count = MAX(active_mods_count, ?),
                                        total_bans = ?,
                                        total_timeouts = ?
                                    WHERE id = ?
                                `, [durationMinutes, currentOnline?.count || 0, actCounts?.bans || 0, actCounts?.timeouts || 0, activeReport.id]);
                            }
                        } else {
                            // Channel is offline: check if there was an active live report and close it
                            const activeReport = await dbAsync.get(
                                'SELECT * FROM stream_reports WHERE channel_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1',
                                [ch.id]
                            );
                            if (activeReport) {
                                console.log(`[KickService] ⏹️ Live stream ended for channel: ${ch.slug}. Closing report #${activeReport.id}`);
                                
                                // 1. Close stream report with ended_at
                                await dbAsync.run(
                                    'UPDATE stream_reports SET ended_at = CURRENT_TIMESTAMP WHERE id = ?',
                                    [activeReport.id]
                                );

                                // 2. Close open attendance sessions
                                await dbAsync.run(
                                    'UPDATE mod_attendance_sessions SET ended_at = CURRENT_TIMESTAMP WHERE channel_id = ? AND ended_at IS NULL',
                                    [ch.id]
                                );

                                // 3. Mark moderators offline
                                await dbAsync.run(
                                    'UPDATE moderators SET is_online = 0 WHERE channel_id = ?',
                                    [ch.id]
                                );

                                // 4. Emit real-time status changed event
                                if (this.io) {
                                    this.io.emit('stream_status_changed', {
                                        channel_id: ch.id,
                                        channel_slug: ch.slug,
                                        is_live: false,
                                        report_id: activeReport.id,
                                        ended_at: new Date().toISOString()
                                    });
                                }
                            }
                        }
                    } catch (chErr) {
                        // Skip individual channel error
                    }
                }
            } catch (err) {
                console.error('[KickService 24/7 Worker Error]:', err.message);
            }
        }, 60000);
    }
}

const kickService = new KickService();
module.exports = kickService;

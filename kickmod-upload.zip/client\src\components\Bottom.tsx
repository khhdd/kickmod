import { useState } from "react";
import { ChevronDown, Link as LinkIcon, ShieldCheck, Sparkles, UserCheck } from "lucide-react";
import { Reveal, SectionTitle } from "./ui";
import { DiscordIcon } from "./Navbar";

const steps = [
  { icon: UserCheck, title: "سجّل دخولك", desc: "ادخل بحسابك عبر ديسكورد أو أنشئ حساباً جديداً خلال ثوانٍ." },
  { icon: LinkIcon, title: "اربط قناتك", desc: "أدخل اسم قناتك على كيك، واربط ويب هوك ديسكورد لو حبيت." },
  { icon: Sparkles, title: "اترك الباقي علينا", desc: "يبدأ الرصد والتوثيق والتنبيه تلقائياً على مدار الساعة." },
];

export function Steps() {
  return (
    <section id="steps" className="px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <SectionTitle badge="كيف يعمل" title="ثلاث خطوات" accent="وتبدأ" />
        <div className="relative grid gap-6 md:grid-cols-3">
          <div className="absolute inset-x-[16%] top-10 hidden h-px bg-gradient-to-l from-transparent via-kick/40 to-transparent md:block" />
          {steps.map((s, i) => (
            <Reveal key={s.title} delay={i * 120}>
              <div className="relative text-center">
                <div className="relative mx-auto mb-6 flex h-20 w-20 items-center justify-center rounded-3xl border border-kick/40 bg-[#0b100e] text-kick shadow-[0_0_35px_rgba(83,252,24,0.2)]">
                  <s.icon className="h-8 w-8" />
                  <span className="absolute -top-3 -end-3 flex h-8 w-8 items-center justify-center rounded-full bg-kick text-sm font-black text-black">
                    {i + 1}
                  </span>
                </div>
                <h3 className="mb-2 text-xl font-extrabold">{s.title}</h3>
                <p className="mx-auto max-w-xs text-sm leading-7 text-gray-400">{s.desc}</p>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

const faqs = [
  { q: "هل الخدمة مجانية؟", a: "نعم، يمكنك البدء بالمراقبة مجاناً وإضافة قناتك فوراً دون بطاقة بنكية." },
  { q: "هل أحتاج لتثبيت أي برنامج؟", a: "لا. النظام يعمل بالكامل في السحابة على مدار الساعة، وكل ما تحتاجه هو اسم قناتك." },
  { q: "كيف أحصل على رابط ديسكورد ويب هوك؟", a: "من إعدادات الروم في ديسكورد ← Integrations ← Webhooks ← New Webhook ثم انسخ الرابط والصقه في الخانة." },
  { q: "هل يمكنني مراقبة أكثر من قناة؟", a: "بالتأكيد، أضف عدد القنوات الذي تريده وسيتم رصدها جميعاً بالتوازي." },
];

export function FAQ() {
  const [open, setOpen] = useState<number | null>(0);
  return (
    <section id="faq" className="px-4 py-24">
      <div className="mx-auto max-w-3xl">
        <SectionTitle badge="الأسئلة الشائعة" title="كل اللي تحتاج" accent="تعرفه" />
        <div className="space-y-3">
          {faqs.map((f, i) => (
            <Reveal key={f.q} delay={i * 70}>
              <div className={`glass overflow-hidden rounded-2xl transition ${open === i ? "border-kick/30" : ""}`}>
                <button
                  onClick={() => setOpen(open === i ? null : i)}
                  className="flex w-full items-center justify-between gap-4 px-6 py-5 text-start font-bold"
                >
                  {f.q}
                  <ChevronDown className={`h-5 w-5 shrink-0 text-kick transition-transform duration-300 ${open === i ? "rotate-180" : ""}`} />
                </button>
                <div className={`grid transition-all duration-300 ${open === i ? "grid-rows-[1fr]" : "grid-rows-[0fr]"}`}>
                  <div className="overflow-hidden">
                    <p className="px-6 pb-5 text-sm leading-7 text-gray-400">{f.a}</p>
                  </div>
                </div>
              </div>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

export function CTA({ onOpenAuth }: { onOpenAuth?: () => void }) {
  return (
    <section className="px-4 py-16">
      <Reveal>
        <div className="relative mx-auto max-w-5xl overflow-hidden rounded-[2rem] border border-kick/30 bg-gradient-to-br from-[#0f1a10] to-[#070a08] px-6 py-16 text-center">
          <div className="absolute -top-20 start-1/2 h-60 w-96 -translate-x-1/2 rounded-full bg-kick/30 blur-[100px]" />
          <div className="grid-bg absolute inset-0 opacity-60" />
          <div className="relative">
            <h2 className="text-3xl font-black md:text-5xl">جاهز تبدأ تراقب مشرفينك؟</h2>
            <p className="mx-auto mt-4 max-w-xl text-gray-400">انضم الآن وفعّل المراقبة السحابية لقناتك خلال ثوانٍ.</p>
            <div className="mt-8 flex flex-wrap justify-center gap-3">
              <button
                onClick={onOpenAuth}
                className="btn-shine rounded-2xl bg-kick px-8 py-4 text-sm font-extrabold text-black shadow-[0_10px_40px_-8px_rgba(83,252,24,0.7)] transition hover:-translate-y-0.5"
              >
                ابدأ مجاناً
              </button>
              <a href="/api/auth/discord/login" className="flex items-center gap-2 rounded-2xl bg-[#5865f2] px-8 py-4 text-sm font-bold transition hover:-translate-y-0.5">
                <DiscordIcon className="h-5 w-5" /> الدخول عبر ديسكورد
              </a>
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="border-t border-white/5 px-4 py-10">
      <div className="mx-auto flex max-w-6xl flex-col items-center justify-between gap-4 text-sm text-gray-500 md:flex-row">
        <div className="flex items-center gap-3">
          <span className="flex h-9 w-9 items-center justify-center rounded-xl border border-kick/50 bg-kick/10 text-kick">
            <ShieldCheck className="h-4 w-4" />
          </span>
          <span dir="ltr" className="font-black tracking-[0.2em] text-white">
            KICK<span className="text-kick">MOD</span>
          </span>
        </div>
        <p>© {new Date().getFullYear()} KICKMOD · جميع الحقوق محفوظة · غير تابع رسمياً لمنصة Kick</p>
      </div>
    </footer>
  );
}

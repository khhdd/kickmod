@echo off
title KickMod - Kick Moderator Tracker & Dashboard
echo Starting KickMod Server...
cd /d "%~dp0"
npm start
pause


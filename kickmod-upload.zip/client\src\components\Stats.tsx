import { useEffect, useState } from "react";
import { Activity, Radio, ShieldAlert, Users } from "lucide-react";
import { Reveal, useInView } from "./ui";

function CountUp({ to, run }: { to: number; run: boolean }) {
  const [v, setV] = useState(0);
  useEffect(() => {
    if (!run) return;
    let raf = 0;
    const start = performance.now();
    const tick = (t: number) => {
      const p = Math.min((t - start) / 1400, 1);
      setV(Math.round(to * (1 - Math.pow(1 - p, 3))));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [run, to]);
  return <>{v}</>;
}

export default function Stats({ channels }: { channels: number }) {
  const [ref, seen] = useInView<HTMLDivElement>();
  const [netStats, setNetStats] = useState({
    total_channels: channels,
    total_human_mods: 29,
    total_actions_recorded: 102,
  });

  useEffect(() => {
    fetch('/api/network/stats')
      .then((r) => r.json())
      .then((d) => {
        if (d.stats) {
          setNetStats(d.stats);
        }
      })
      .catch(console.error);
  }, [channels]);

  const items = [
    { label: "القنوات المسجلة", icon: Radio, value: netStats.total_channels || channels, text: "text-white", glow: "from-white/10" },
    { label: "مشرفون قيد الرصد", icon: Users, value: netStats.total_human_mods || 29, text: "text-kick", glow: "from-kick/15" },
    { label: "إجراءات وعقوبات موثقة", icon: ShieldAlert, value: netStats.total_actions_recorded || 102, text: "text-amber-400", glow: "from-amber-400/15" },
    { label: "مدة المراقبة السحابية", icon: Activity, value: null, text: "text-cyan-400", glow: "from-cyan-400/15" },
  ];

  return (
    <section className="px-4 py-10">
      <div ref={ref} className="mx-auto grid max-w-6xl grid-cols-2 gap-4 lg:grid-cols-4">
        {items.map((s, i) => (
          <Reveal key={s.label} delay={i * 90}>
            <div className="glass group relative overflow-hidden rounded-3xl p-6 text-center transition duration-300 hover:-translate-y-1 hover:border-white/20">
              <div className={`absolute inset-0 bg-gradient-to-b ${s.glow} to-transparent opacity-60`} />
              <div className="relative">
                <div className="mb-4 flex items-center justify-center gap-2 text-xs font-bold text-kick">
                  <span className="h-px w-4 bg-kick/60" />
                  <s.icon className="h-3.5 w-3.5" />
                  {s.label}
                </div>
                <div className={`text-5xl font-black tabular-nums ${s.text}`}>
                  {s.value === null ? "24/7" : <CountUp to={s.value} run={seen} />}
                </div>
              </div>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

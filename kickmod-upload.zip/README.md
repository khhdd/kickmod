# 🛡️ KickMod — المنصة المتكاملة لمراقبة وإدارة مشرفي كيك (Multi-Channel Kick Moderator Tracker)

منصة ويب متكاملة تتيح لأي ستريمر أو فريق إشراف على منصة **Kick (كيك)** ربط قناتهم ومتابعة نشاط المشرفين (المودز) لحظة بلحظة مع لوحة تحكم تفاعلية وإحصائيات مباشرة وربط مع Discord.

---

## ✨ المميزات الرئيسية

1. **دعم تعدد القنوات (Multi-Channel / Multi-Tenant):**
   * يمكن لأي قناة كيك إضافة قناتها لمراقبة المشرفين بنقرة واحدة بمجرد كتابة اسم القناة (Slug).
   * إمكانية التنقل بين القنوات المختلفة ومتابعة كل قناة وإشرافها بشكل منفصل.

2. **الرصد اللحظي المباشر (Real-Time Live Feed):**
   * رصد فوري لجميع عمليات الحظر الدائم (**Bans**) مع تحديد اسم المود والمستخدم المحظور.
   * رصد عمليات الكتم المؤقت (**Timeouts**) مع حساب مدة الكتم بالدقائق/الثواني.
   * رصد مسح الرسائل وإلغاء الحظر (**Unbans**).
   * رصد وتتبع رسائل المودز في الشات وتحديث وقت آخر ظهور لهم.

3. **لوحة صدارة وتقييم المشرفين (Moderators Leaderboard):**
   * احتساب نقاط تفاعل لكل مشرف بناءً على نشاطه:
     * **5 نقاط** لكل عملية حظر دائم.
     * **3 نقاط** لكل عملية كتم مؤقت.
     * **نقطة واحدة** لكل رسالة تفاعلية في الشات.
   * إمكانية النقر على أي مشرف لعرض ملفه الشخصي الكامل (سجل الإجراءات، الأيام النشطة، إجمالي الحظر والكتم).

4. **سجل الرقابة الكامل (Audit Log):**
   * جدول تاريخي لجميع الإجراءات مع فلاتر (حظر فقط، كتم فقط، إلغاء حظر).
   * إمكانية تصدير السجل بضغطة زر بصيغة **CSV (Excel)** أو **JSON**.

5. **تنبيهات ديسكورد فورية (Discord Webhook Integration):**
   * إرسال بطاقات تنبيهات احترافية (Embeds) بروابط وألوان مخصصة لكل إجراء في روم المودز على Discord فور حدوثه.

6. **تصميم احترافي بستايل كيك الداكن (Dark Kick Aesthetic):**
   * واجهة متجاوبة وعصرية باللون الأسود والأخضر النيوني الخاص بمنصة كيك مع رسوم بيانية تفاعلية (Chart.js) ومؤشرات حالة حية (WebSockets).

---

## 🚀 طريقة التشغيل السريع

### 1. تشغيل السيرفر
يمكنك تشغيله بطريقتين:
* **الطريقة الأولى (مباشرة):** النقر مرتين على ملف [`start.bat`](file:///c:/Users/KHD/Desktop/ModreatorOnly/start.bat).
* **الطريقة الثانية (عبر موجه الأوامر):**
  ```bash
  npm start
  ```

### 2. فتح لوحة التحكم في المتصفح
افتح المتصفح وانتقل إلى:
👉 **[http://localhost:3000](http://localhost:3000)**

---

## ⚙️ هيكلية المشروع
* [`server.js`](file:///c:/Users/KHD/Desktop/ModreatorOnly/server.js): خادم Express الرئيسي مع Socket.io للبث المباشر.
* [`services/kickService.js`](file:///c:/Users/KHD/Desktop/ModreatorOnly/services/kickService.js): محرك الربط مع Kick وWebSocket لقراءة الأحداث.
* [`services/discordService.js`](file:///c:/Users/KHD/Desktop/ModreatorOnly/services/discordService.js): خدمة إرسال التنبيهات لديسكورد.
* [`routes/api.js`](file:///c:/Users/KHD/Desktop/ModreatorOnly/routes/api.js): واجهة برمجة التطبيقات (REST API).
* [`db/database.js`](file:///c:/Users/KHD/Desktop/ModreatorOnly/db/database.js): قاعدة بيانات SQLite مدمجة ومستقرة.
* [`public/`](file:///c:/Users/KHD/Desktop/ModreatorOnly/public): واجهة المستخدم (HTML5, TailwindCSS, Chart.js, Socket.io-client).
* [`.env`](file:///c:/Users/KHD/Desktop/ModreatorOnly/.env): مفاتيح Kick API الرسمية والإعدادات.


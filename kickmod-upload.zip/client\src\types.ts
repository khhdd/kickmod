export type Channel = { id: number; name: string; webhook: string };

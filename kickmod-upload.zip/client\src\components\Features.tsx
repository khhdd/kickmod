import { BarChart3, Bell, Bot, Eye, FileText, Gavel } from "lucide-react";
import { Reveal, SectionTitle, SpotCard } from "./ui";

const features = [
  {
    icon: Eye,
    title: "رصد الحضور الصامت",
    desc: "اعرف أي مشرف متواجد فعلاً في الشات حتى لو لم يكتب رسالة واحدة، مع سجل زمني دقيق لكل جلسة.",
    span: "lg:col-span-2",
    color: "text-kick bg-kick/10",
  },
  {
    icon: Bot,
    title: "عزل البوتات التلقائية",
    desc: "خوارزمية تميّز الحسابات الآلية وتفصلها عن المشاهدين الحقيقيين.",
    span: "",
    color: "text-cyan-400 bg-cyan-400/10",
  },
  {
    icon: Gavel,
    title: "توثيق الحظر والكتم",
    desc: "كل عقوبة تُسجّل لحظياً باسم المشرف والسبب والمدة.",
    span: "",
    color: "text-red-400 bg-red-400/10",
  },
  {
    icon: Bell,
    title: "تنبيهات ديسكورد فورية",
    desc: "اربط Webhook واحد وستصلك كل الأحداث المهمة في روم المودز في نفس اللحظة.",
    span: "lg:col-span-2",
    color: "text-indigo-300 bg-indigo-400/10",
  },
  {
    icon: BarChart3,
    title: "تقييم أداء المشرفين",
    desc: "نقاط نشاط وتقارير تساعدك تعرف من يستحق الترقية ومن يحتاج متابعة.",
    span: "",
    color: "text-amber-400 bg-amber-400/10",
  },
  {
    icon: FileText,
    title: "تقارير جاهزة",
    desc: "ملخصات يومية وأسبوعية تلقائياً بدون أي مجهود.",
    span: "",
    color: "text-emerald-300 bg-emerald-400/10",
  },
];

export default function Features() {
  return (
    <section id="features" className="relative px-4 py-24">
      <div className="mx-auto max-w-6xl">
        <SectionTitle
          badge="المميزات"
          title="كل ما تحتاجه لإدارة"
          accent="مجتمعك بذكاء"
          desc="أدوات احترافية مصممة خصيصاً لبيئة كيك، تعمل في السحابة بلا توقف وبلا إعداد معقد."
        />
        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-4">
          {features.map((f, i) => (
            <Reveal key={f.title} delay={i * 70} className={f.span}>
              <SpotCard className="h-full p-7 transition duration-300 hover:-translate-y-1">
                <div className={`mb-5 flex h-12 w-12 items-center justify-center rounded-2xl ${f.color}`}>
                  <f.icon className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-lg font-extrabold">{f.title}</h3>
                <p className="text-sm leading-7 text-gray-400">{f.desc}</p>
              </SpotCard>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

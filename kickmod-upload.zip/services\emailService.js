const nodemailer = require('nodemailer');

/**
 * Configure Nodemailer Transporter
 * Supports Brevo, Outlook, Mailgun, Mailtrap, or any custom SMTP
 */
function getTransporter() {
    const host = process.env.SMTP_HOST;
    const port = parseInt(process.env.SMTP_PORT || '587', 10);
    const user = process.env.SMTP_USER;
    const pass = process.env.SMTP_PASS;

    if (host && user && pass) {
        return nodemailer.createTransport({
            host,
            port,
            secure: port === 465,
            auth: { user, pass }
        });
    }

    // Generic SMTP user/pass with host default (e.g. Brevo)
    if (user && pass) {
        return nodemailer.createTransport({
            host: host || 'smtp-relay.brevo.com',
            port: port || 587,
            secure: false,
            auth: { user, pass }
        });
    }

    return null;
}

/**
 * Render Ultra-Clean, Gorgeous Cyberpunk Dark Neon Email Template
 */
function buildEmailTemplate(otpCode) {
    return `
    <!DOCTYPE html>
    <html dir="rtl" lang="ar">
    <head>
      <meta charset="utf-8">
      <meta name="viewport" content="width=device-width, initial-scale=1.0">
      <title>رمز التحقق KICKMOD</title>
      <style>
        body { margin: 0; padding: 0; background-color: #070a0c; font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Helvetica, Arial, sans-serif; color: #ffffff; }
        .wrapper { width: 100%; table-layout: fixed; background-color: #070a0c; padding: 30px 10px; }
        .main-card { max-width: 520px; margin: 0 auto; background: #0e1417; border: 1px solid rgba(83, 252, 24, 0.35); border-radius: 24px; padding: 36px 28px; box-shadow: 0 12px 50px rgba(0, 0, 0, 0.8), 0 0 30px rgba(83, 252, 24, 0.08); text-align: center; }
        .brand-badge { display: inline-block; padding: 6px 16px; border-radius: 12px; background: rgba(83, 252, 24, 0.12); border: 1px solid rgba(83, 252, 24, 0.3); font-size: 13px; font-weight: 900; letter-spacing: 2px; color: #53fc18; margin-bottom: 20px; }
        .brand-logo { font-size: 28px; font-weight: 900; letter-spacing: 1.5px; color: #ffffff; margin-bottom: 8px; }
        .brand-logo span { color: #53fc18; }
        .tagline { font-size: 12px; color: #7f8e95; margin-bottom: 26px; }
        .title { font-size: 21px; font-weight: 800; color: #ffffff; margin-bottom: 12px; line-height: 1.4; }
        .desc { font-size: 13px; color: #9aa8af; line-height: 1.7; margin-bottom: 26px; padding: 0 10px; }
        .otp-container { background: #050708; border: 2px dashed #53fc18; border-radius: 18px; padding: 22px 14px; margin: 26px 0; box-shadow: inset 0 0 20px rgba(83, 252, 24, 0.06), 0 0 24px rgba(83, 252, 24, 0.12); }
        .otp-label { font-size: 11px; text-transform: uppercase; color: #53fc18; font-weight: 800; letter-spacing: 3px; margin-bottom: 8px; }
        .otp-number { font-family: 'Courier New', Courier, monospace; font-size: 38px; font-weight: 900; letter-spacing: 14px; color: #53fc18; text-shadow: 0 0 16px rgba(83, 252, 24, 0.5); padding-right: 14px; }
        .timer-badge { display: inline-block; background: rgba(234, 179, 8, 0.12); border: 1px solid rgba(234, 179, 8, 0.3); color: #facc15; font-size: 12px; font-weight: 700; padding: 6px 14px; border-radius: 10px; margin-bottom: 24px; }
        .security-note { font-size: 11px; color: #617179; line-height: 1.6; border-top: 1px solid rgba(255, 255, 255, 0.07); padding-top: 20px; }
      </style>
    </head>
    <body>
      <div class="wrapper">
        <div class="main-card">
          <div class="brand-badge">KICKMOD SECURITY</div>
          <div class="brand-logo">KICK<span>MOD</span></div>
          <div class="tagline">نظام الرقابة والتحليلات للبث المباشر 24/7</div>
          
          <div class="title">رمز التحقق لتسجيل الدخول</div>
          <div class="desc">
            مرحباً بك! لقد تلقينا طلباً لتسجيل الدخول أو تأكيد حسابك في منصة <b>KICKMOD</b>.<br>
            استخدم كود الأمان التالي للمتابعة:
          </div>

          <div class="otp-container">
            <div class="otp-label">كود التحقق الخاص بك (OTP)</div>
            <div class="otp-number">${otpCode}</div>
          </div>

          <div class="timer-badge">
            صالح لمدة 10 دقائق فقط
          </div>

          <div class="security-note">
            هذا الرمز مخصص لحمايتك الشخصية فقط. لا تقم بمشاركته مع أي طرف أو فريق دعم.<br>
            إذا لم تكن قد طلبت هذا الرمز، فيمكنك تجاهل هذا البريد الإلكتروني بأمان.<br>
            © ${new Date().getFullYear()} KICKMOD · جميع الحقوق محفوظة
          </div>
        </div>
      </div>
    </body>
    </html>
    `;
}

/**
 * Send 6-digit OTP Email
 * Dispatches via Resend API, Brevo API, or SMTP Relay
 */
async function sendOTPEmail(toEmail, otpCode) {
    console.log(`\n======================================================`);
    console.log(`📬 [EMAIL OTP DISPATCH] Destination: ${toEmail}`);
    console.log(`🔑 Verification Code: [ ${otpCode} ]`);
    console.log(`⏱️ Expiration: 10 minutes`);
    console.log(`======================================================\n`);

    const cleanTo = toEmail.trim().toLowerCase();
    // Normalize Gmail plus addresses (e.g. user+34@gmail.com -> user@gmail.com) so Resend sandbox delivers
    let deliverTo = cleanTo.includes('+') && cleanTo.endsWith('@gmail.com')
        ? cleanTo.replace(/\+[^@]+@/, '@')
        : cleanTo;

    const htmlContent = buildEmailTemplate(otpCode);
    const subject = `[KICKMOD] رمز التحقق لتأكيد حساب (${cleanTo}) هو: ${otpCode}`;

    // METHOD 1: Resend REST API (100% Free, 3,000 emails/month, fastest inbox delivery)
    if (process.env.RESEND_API_KEY) {
        try {
            let res = await fetch('https://api.resend.com/emails', {
                method: 'POST',
                headers: {
                    'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    from: process.env.RESEND_FROM || 'KICKMOD <onboarding@resend.dev>',
                    to: [deliverTo],
                    subject,
                    html: htmlContent
                })
            });
            let data = await res.json();

            // If Resend returns 403 sandbox restriction, extract the owner's authorized email and retry
            if (!res.ok && data.message && (data.message.includes('testing emails') || data.message.includes('verify a domain'))) {
                const match = data.message.match(/\(([a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,})\)/);
                const ownerEmail = match ? match[1] : (process.env.RESEND_OWNER_EMAIL || 'khhdd900@gmail.com');
                console.warn(`[EmailService] Resend Sandbox restricted recipient "${deliverTo}". Automatically routing OTP to account owner (${ownerEmail}).`);

                const retryRes = await fetch('https://api.resend.com/emails', {
                    method: 'POST',
                    headers: {
                        'Authorization': `Bearer ${process.env.RESEND_API_KEY}`,
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({
                        from: process.env.RESEND_FROM || 'KICKMOD <onboarding@resend.dev>',
                        to: [ownerEmail],
                        subject: `[KICKMOD] رمز التحقق لتفعيل حساب (${cleanTo}) هو: ${otpCode}`,
                        html: `
                        <div dir="rtl" style="font-family: sans-serif; background: #070a0c; color: #fff; padding: 25px; border-radius: 16px; border: 1px solid #53fc18;">
                            <div style="background: rgba(83,252,24,0.1); border: 1px solid #53fc18; padding: 8px 14px; border-radius: 8px; color: #53fc18; font-weight: bold; font-size: 13px; margin-bottom: 16px;">
                                🛡️ تنبيه بيئة الاختبار (Resend Sandbox)
                            </div>
                            <p style="font-size: 15px; margin-bottom: 10px;">تم طلب رمز تحقق لتسجيل/تأكيد الحساب المستهدف: <b style="color: #53fc18;">${cleanTo}</b></p>
                            <div style="background: #000; border: 2px dashed #53fc18; border-radius: 12px; padding: 18px; text-align: center; margin: 18px 0;">
                                <span style="font-size: 32px; font-weight: 900; letter-spacing: 10px; color: #53fc18; font-family: monospace;">${otpCode}</span>
                            </div>
                            <p style="font-size: 12px; color: #9aa8af;">تم تسليم هذا الإشعار إلى بريدك المعتمد (<b>${ownerEmail}</b>) لأن النطاق قيد الوضع التجريبي. الرمز صالح لمدة 10 دقائق.</p>
                        </div>
                        `
                    })
                });

                const retryData = await retryRes.json();
                if (retryRes.ok) {
                    console.log(`[EmailService] ✅ Email delivered to owner (${ownerEmail}) via Resend Sandbox! ID:`, retryData.id);
                    return {
                        sent: true,
                        provider: 'resend_sandbox',
                        message: `تم إرسال رمز التحقق بنجاح إلى بريدك الإلكتروني (${ownerEmail}) لتأكيد حساب (${cleanTo}).`
                    };
                }
            }

            if (res.ok) {
                console.log(`[EmailService] ✅ Email sent via Resend API! ID:`, data.id);
                return {
                    sent: true,
                    provider: 'resend',
                    message: `تم إرسال رمز التحقق إلى بريدك الإلكتروني بنجاح (${deliverTo}).`
                };
            }

            console.error(`[EmailService] Resend API error:`, data);
            return {
                sent: false,
                provider: 'resend_error',
                error: data.message,
                message: data.message || 'فشل إرسال البريد عبر Resend.'
            };
        } catch (resendErr) {
            console.error(`[EmailService] Resend dispatch failed:`, resendErr.message);
        }
    }

    // METHOD 2: Brevo (Sendinblue) REST API (300 free emails/day)
    if (process.env.BREVO_API_KEY) {
        try {
            const res = await fetch('https://api.brevo.com/v3/smtp/email', {
                method: 'POST',
                headers: {
                    'api-key': process.env.BREVO_API_KEY,
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({
                    sender: {
                        name: 'KICKMOD Support',
                        email: process.env.BREVO_SENDER || 'noreply@kickmod.com'
                    },
                    to: [{ email: toEmail }],
                    subject,
                    htmlContent
                })
            });
            const data = await res.json();
            if (res.ok) {
                console.log(`[EmailService] ✅ Email sent via Brevo API! MessageID:`, data.messageId);
                return {
                    sent: true,
                    provider: 'brevo_api',
                    message: `تم إرسال رمز التحقق إلى بريدك الإلكتروني بنجاح (${toEmail}).`,
                    dev_code: null
                };
            }
            console.error(`[EmailService] Brevo API error:`, data);
        } catch (brevoErr) {
            console.error(`[EmailService] Brevo dispatch failed:`, brevoErr.message);
        }
    }

    // METHOD 3: Nodemailer with SMTP Relay (Brevo / Outlook / SendGrid / Custom SMTP)
    const transporter = getTransporter();
    if (transporter) {
        const fromAddress = process.env.SMTP_FROM || `"KICKMOD" <${process.env.SMTP_USER}>`;
        try {
            const info = await transporter.sendMail({
                from: fromAddress,
                to: toEmail,
                subject,
                text: `رمز التحقق الخاص بك في منصة KICKMOD هو: ${otpCode} (صالح لمدة 10 دقائق).`,
                html: htmlContent
            });

            console.log(`[EmailService] ✅ Email sent via SMTP Relay! MessageID:`, info.messageId);
            return {
                sent: true,
                provider: 'smtp',
                message: `تم إرسال رمز التحقق إلى بريدك الإلكتروني بنجاح (${toEmail}).`
            };
        } catch (smtpErr) {
            console.error(`[EmailService] ❌ SMTP send failed:`, smtpErr.message);
        }
    }

    // METHOD 4: No external provider configured
    console.warn(`[EmailService] Notice: No free external provider API key detected in .env.`);
    return {
        sent: false,
        provider: 'unconfigured',
        message: 'تعذر إرسال البريد الإلكتروني. يرجى تزويد بيانات SMTP أو التحقق من إعدادات Resend.'
    };
}

module.exports = {
    sendOTPEmail
};
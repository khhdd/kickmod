/**
 * KickMod Motion - Lightweight scroll reveals only.
 * No 3D tilt, no scroll hijacking.
 */
(function () {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    if (typeof gsap !== 'undefined' && !reduced) {
        if (typeof ScrollTrigger !== 'undefined') {
            gsap.registerPlugin(ScrollTrigger);
        }

        document.querySelectorAll('.km-reveal').forEach((el) => {
            el.classList.add('km-reveal-ready');
            gsap.fromTo(el,
                { opacity: 0, y: 10 },
                {
                    opacity: 1,
                    y: 0,
                    duration: 0.42,
                    ease: 'power2.out',
                    scrollTrigger: typeof ScrollTrigger !== 'undefined' ? {
                        trigger: el,
                        start: 'top 92%',
                        once: true
                    } : undefined
                }
            );
        });
    } else {
        document.querySelectorAll('.km-reveal').forEach(el => {
            el.classList.add('km-reveal-ready');
            el.style.opacity = '1';
            el.style.transform = 'none';
        });
    }

    window.animateCounterEl = function (el, targetValue) {
        if (!el) return;
        el.textContent = Math.round(Number(targetValue) || 0).toLocaleString('en-US');
    };
})();

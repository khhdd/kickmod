/**
 * KickMod Hero - Minimal 2D particle network
 * Replaces heavy Three.js scene with lightweight canvas 2D.
 * ~0% CPU when off-screen or tab hidden.
 */
(function () {
    const host = document.getElementById('heroCanvasHost');
    if (!host) return;

    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (reduced) return;

    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    host.appendChild(canvas);

    let w = 0, h = 0, particles = [], frameId = null;

    function resize() {
        w = canvas.width  = host.clientWidth  || window.innerWidth;
        h = canvas.height = host.clientHeight || 500;
    }

    function mkParticle() {
        return {
            x:  Math.random() * w,
            y:  Math.random() * h,
            vx: (Math.random() - 0.5) * 0.22,
            vy: (Math.random() - 0.5) * 0.22,
            r:  Math.random() * 1.1 + 0.4,
            a:  Math.random() * 0.28 + 0.07
        };
    }

    function drawFrame() {
        ctx.clearRect(0, 0, w, h);

        const len = particles.length;

        for (let i = 0; i < len; i++) {
            const p = particles[i];
            p.x += p.vx;
            p.y += p.vy;
            if (p.x < -4) p.x = w + 4;
            else if (p.x > w + 4) p.x = -4;
            if (p.y < -4) p.y = h + 4;
            else if (p.y > h + 4) p.y = -4;
        }

        // Connections
        for (let i = 0; i < len - 1; i++) {
            for (let j = i + 1; j < len; j++) {
                const dx = particles[i].x - particles[j].x;
                const dy = particles[i].y - particles[j].y;
                const d2 = dx * dx + dy * dy;
                if (d2 < 9000) {
                    ctx.beginPath();
                    ctx.moveTo(particles[i].x, particles[i].y);
                    ctx.lineTo(particles[j].x, particles[j].y);
                    ctx.strokeStyle = `rgba(83,252,24,${(0.065 * (1 - d2 / 9000)).toFixed(3)})`;
                    ctx.lineWidth = 0.5;
                    ctx.stroke();
                }
            }
        }

        // Dots
        for (let i = 0; i < len; i++) {
            const p = particles[i];
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, 6.2832);
            ctx.fillStyle = `rgba(83,252,24,${p.a})`;
            ctx.fill();
        }
    }

    function loop() {
        drawFrame();
        frameId = requestAnimationFrame(loop);
    }

    function start() {
        if (!frameId) frameId = requestAnimationFrame(loop);
    }

    function stop() {
        if (frameId) { cancelAnimationFrame(frameId); frameId = null; }
    }

    // Init
    resize();
    const count = window.innerWidth < 768 ? 28 : 55;
    particles = Array.from({ length: count }, mkParticle);
    start();

    // Pause off-screen
    if ('IntersectionObserver' in window) {
        new IntersectionObserver(entries => {
            entries[0].isIntersecting ? start() : stop();
        }, { threshold: 0.05 }).observe(host);
    }

    // Pause hidden tab
    document.addEventListener('visibilitychange', () => {
        document.hidden ? stop() : start();
    });

    window.addEventListener('resize', () => {
        stop();
        resize();
        particles.forEach(p => { p.x = Math.random() * w; p.y = Math.random() * h; });
        start();
    }, { passive: true });

    window.kmHero3D = { pause: stop, resume: start };
})();

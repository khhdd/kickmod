const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '..', 'kickmod.db');
const db = new sqlite3.Database(dbPath, (err) => {
    if (err) {
        console.error('Failed to connect to SQLite database:', err.message);
    } else {
        console.log('Connected to SQLite database at:', dbPath);
    }
});

// Initialize Tables
db.serialize(() => {
    // Users table for authentication
    db.run(`
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT UNIQUE NOT NULL,
            email TEXT UNIQUE,
            password_hash TEXT,
            salt TEXT,
            discord_id TEXT,
            discord_username TEXT,
            discord_avatar TEXT,
            email_verified INTEGER DEFAULT 0,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Email OTPs table for verification
    db.run(`
        CREATE TABLE IF NOT EXISTS email_otps (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL,
            otp_code TEXT NOT NULL,
            purpose TEXT DEFAULT 'login',
            payload TEXT,
            attempts INTEGER DEFAULT 0,
            expires_at DATETIME NOT NULL,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);

    // Safe column migrations for existing tables
    db.run(`ALTER TABLE email_otps ADD COLUMN purpose TEXT DEFAULT 'login'`, () => {});
    db.run(`ALTER TABLE email_otps ADD COLUMN payload TEXT`, () => {});
    db.run(`ALTER TABLE email_otps ADD COLUMN attempts INTEGER DEFAULT 0`, () => {});
    db.run(`CREATE INDEX IF NOT EXISTS idx_email_otps_lookup ON email_otps(email, purpose, expires_at)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_users_email ON users(email)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_users_username ON users(username)`);

    // Channels table (user_id owned, slug unique)
    db.run(`
        CREATE TABLE IF NOT EXISTS channels (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER,
            slug TEXT UNIQUE NOT NULL,
            name TEXT,
            kick_channel_id INTEGER,
            chatroom_id INTEGER,
            avatar_url TEXT,
            banner_url TEXT,
            is_monitored INTEGER DEFAULT 1,
            discord_webhook TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(user_id) REFERENCES users(id) ON DELETE CASCADE
        )
    `);

    // Moderators table
    db.run(`
        CREATE TABLE IF NOT EXISTS moderators (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            channel_id INTEGER NOT NULL,
            username TEXT NOT NULL,
            user_id INTEGER,
            avatar_url TEXT,
            first_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_seen DATETIME DEFAULT CURRENT_TIMESTAMP,
            total_messages INTEGER DEFAULT 0,
            total_bans INTEGER DEFAULT 0,
            total_timeouts INTEGER DEFAULT 0,
            total_deleted INTEGER DEFAULT 0,
            total_active_seconds INTEGER DEFAULT 0,
            is_online INTEGER DEFAULT 0,
            is_bot INTEGER DEFAULT 0,
            UNIQUE(channel_id, username),
            FOREIGN KEY(channel_id) REFERENCES channels(id) ON DELETE CASCADE
        )
    `);

    // Stream Sessions & Reports table
    db.run(`
        CREATE TABLE IF NOT EXISTS stream_reports (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            channel_id INTEGER NOT NULL,
            title TEXT,
            category TEXT,
            started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            ended_at DATETIME,
            duration_minutes INTEGER DEFAULT 0,
            active_mods_count INTEGER DEFAULT 0,
            total_bans INTEGER DEFAULT 0,
            total_timeouts INTEGER DEFAULT 0,
            total_mod_messages INTEGER DEFAULT 0,
            FOREIGN KEY(channel_id) REFERENCES channels(id) ON DELETE CASCADE
        )
    `);

    // Mod Attendance Sessions
    db.run(`
        CREATE TABLE IF NOT EXISTS mod_attendance_sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            channel_id INTEGER NOT NULL,
            moderator_username TEXT NOT NULL,
            started_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            last_ping_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            ended_at DATETIME,
            duration_seconds INTEGER DEFAULT 0,
            FOREIGN KEY(channel_id) REFERENCES channels(id) ON DELETE CASCADE
        )
    `);

    // Mod Actions (Audit Log) table
    db.run(`
        CREATE TABLE IF NOT EXISTS mod_actions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            channel_id INTEGER NOT NULL,
            moderator_username TEXT NOT NULL,
            action_type TEXT NOT NULL,
            target_username TEXT,
            target_user_id INTEGER,
            duration_seconds INTEGER DEFAULT 0,
            reason TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
            FOREIGN KEY(channel_id) REFERENCES channels(id) ON DELETE CASCADE
        )
    `);

    // Safe Alter table columns if existing
    db.run(`ALTER TABLE channels ADD COLUMN banner_url TEXT`, () => {});
    db.run(`ALTER TABLE channels ADD COLUMN user_id INTEGER`, () => {});
    db.run(`ALTER TABLE users ADD COLUMN email_verified INTEGER DEFAULT 0`, () => {});
    db.run(`ALTER TABLE moderators ADD COLUMN total_active_seconds INTEGER DEFAULT 0`, () => {});
    db.run(`ALTER TABLE moderators ADD COLUMN is_online INTEGER DEFAULT 0`, () => {});
    db.run(`ALTER TABLE moderators ADD COLUMN is_bot INTEGER DEFAULT 0`, () => {});
    db.run(`ALTER TABLE mod_actions ADD COLUMN stream_report_id INTEGER`, () => {});
    db.run(`ALTER TABLE mod_attendance_sessions ADD COLUMN stream_report_id INTEGER`, () => {});
    db.run(`ALTER TABLE stream_reports ADD COLUMN snapshot_json TEXT`, () => {});

    // Performance Indexes
    db.run(`CREATE INDEX IF NOT EXISTS idx_actions_channel ON mod_actions(channel_id, created_at)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_actions_stream ON mod_actions(stream_report_id)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_actions_mod ON mod_actions(channel_id, moderator_username)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_mods_channel ON moderators(channel_id, is_online)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_att_channel ON mod_attendance_sessions(channel_id, moderator_username)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_att_stream ON mod_attendance_sessions(stream_report_id)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_otps_email ON email_otps(email)`);
    db.run(`CREATE INDEX IF NOT EXISTS idx_channels_user ON channels(user_id)`);
});

// Helper wrapper for async queries
const dbAsync = {
    run: (sql, params = []) => {
        return new Promise((resolve, reject) => {
            db.run(sql, params, function (err) {
                if (err) reject(err);
                else resolve({ lastID: this.lastID, changes: this.changes });
            });
        });
    },
    get: (sql, params = []) => {
        return new Promise((resolve, reject) => {
            db.get(sql, params, (err, row) => {
                if (err) reject(err);
                else resolve(row);
            });
        });
    },
    all: (sql, params = []) => {
        return new Promise((resolve, reject) => {
            db.all(sql, params, (err, rows) => {
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
};

module.exports = { db, dbAsync };

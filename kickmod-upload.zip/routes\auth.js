const express = require('express');
const router = express.Router();
const crypto = require('crypto');
const { dbAsync } = require('../db/database');
const {
    hashPassword,
    createSessionToken,
    verifySessionToken,
    extractToken,
    requireAuth,
    createEmailOTP,
    verifyEmailOTP
} = require('../services/authService');
const { sendOTPEmail } = require('../services/emailService');

const DISCORD_CLIENT_ID = process.env.DISCORD_CLIENT_ID || '1572079161940639824';
const DISCORD_CLIENT_SECRET = process.env.DISCORD_CLIENT_SECRET || 'hvRgap9nfCweSkmqvZOdpni39_g5BJ2J';
const DISCORD_REDIRECT_URI = process.env.DISCORD_REDIRECT_URI || 'http://localhost:3000/api/auth/discord/callback';

// Security Regex Validators
const EMAIL_REGEX = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
const USERNAME_REGEX = /^[a-zA-Z0-9_]{3,30}$/;

// In-Memory Rate Limiter Map for Auth Endpoints
const rateLimitMap = new Map();
function checkRateLimit(key, maxRequests, windowMs) {
    const now = Date.now();
    let entry = rateLimitMap.get(key);
    if (!entry || now > entry.resetTime) {
        entry = { count: 1, resetTime: now + windowMs };
        rateLimitMap.set(key, entry);
        return true;
    }
    if (entry.count >= maxRequests) {
        return false;
    }
    entry.count++;
    return true;
}

/**
 * 1. Register Step 1: Validate, check uniqueness & send mandatory OTP
 */
router.post('/register', async (req, res) => {
    const { username, password, email } = req.body;
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';

    if (!username || !password || !email) {
        return res.status(400).json({ 
            success: false, 
            error: 'اسم المستخدم والبريد الإلكتروني وكلمة المرور جميعها حقول إجبارية للتسجيل.' 
        });
    }

    const cleanUsername = username.trim().toLowerCase();
    const cleanEmail = email.trim().toLowerCase();

    if (!USERNAME_REGEX.test(cleanUsername)) {
        return res.status(400).json({ 
            success: false, 
            error: 'اسم المستخدم يجب أن يكون بالإنجليزية والأرقام أو شرطة سفلية _ فقط (من 3 إلى 30 حرفاً).' 
        });
    }

    if (!EMAIL_REGEX.test(cleanEmail)) {
        return res.status(400).json({ 
            success: false, 
            error: 'يرجى إدخال عنوان بريد إلكتروني صحيح ومعتمد (مثال: name@example.com).' 
        });
    }

    if (password.length < 6) {
        return res.status(400).json({ 
            success: false, 
            error: 'كلمة المرور يجب أن تكون 6 خانات على الأقل.' 
        });
    }

    if (password.length > 128) {
        return res.status(400).json({ 
            success: false, 
            error: 'كلمة المرور طويلة جداً (الحد الأقصى 128 خانة).' 
        });
    }

    // Rate Limiting on registration attempts: max 4 per 5 mins per IP/email
    if (!checkRateLimit(`reg:${cleanEmail}`, 4, 5 * 60 * 1000) || !checkRateLimit(`reg_ip:${clientIp}`, 12, 5 * 60 * 1000)) {
        return res.status(429).json({ 
            success: false, 
            error: 'تم تجاوز الحد المسموح به لمحاولات التسجيل، يرجى الانتظار 5 دقائق والمحاولة مجدداً.' 
        });
    }

    try {
        // 1. Check if username is already registered
        const existingUsername = await dbAsync.get('SELECT id FROM users WHERE username = ?', [cleanUsername]);
        if (existingUsername) {
            return res.status(400).json({ 
                success: false, 
                code: 'USERNAME_EXISTS',
                error: 'اسم المستخدم مسجل مسبقاً، يرجى اختيار اسم آخر أو تسجيل الدخول.' 
            });
        }

        // 2. Check if email is already registered
        const existingEmail = await dbAsync.get('SELECT id FROM users WHERE email = ?', [cleanEmail]);
        if (existingEmail) {
            return res.status(400).json({ 
                success: false, 
                code: 'EMAIL_EXISTS',
                error: 'هذا البريد الإلكتروني مسجل بالفعل بحساب آخر، يرجى التوجه لتسجيل الدخول مباشرة.' 
            });
        }

        // Secure password hash
        const salt = crypto.randomBytes(16).toString('hex');
        const passwordHash = hashPassword(password, salt);

        // Directly create user and log in immediately (No OTP needed!)
        const result = await dbAsync.run(`
            INSERT INTO users (username, email, password_hash, salt, email_verified)
            VALUES (?, ?, ?, ?, 1)
        `, [cleanUsername, cleanEmail, passwordHash, salt]);

        const newUser = await dbAsync.get(`
            SELECT id, username, email, discord_id, discord_username, discord_avatar, email_verified, created_at 
            FROM users WHERE id = ?
        `, [result.lastID]);

        const token = createSessionToken(newUser.id);
        res.cookie('kickmod_token', token, {
            maxAge: 30 * 24 * 3600 * 1000,
            httpOnly: true,
            sameSite: 'lax',
            path: '/'
        });

        res.status(201).json({
            success: true,
            user: newUser,
            token,
            message: 'تم إنشاء الحساب وتسجيل الدخول بنجاح!'
        });
    } catch (err) {
        res.status(500).json({ success: false, error: 'حدث خطأ أثناء معالجة التسجيل: ' + err.message });
    }
});

/**
 * 1.b. Register Step 2: Verify OTP & Activate New Account
 */
router.post('/register/verify-otp', async (req, res) => {
    const { email, otp_code } = req.body;

    if (!email || !otp_code) {
        return res.status(400).json({ 
            success: false, 
            error: 'البريد الإلكتروني ورمز التحقق (OTP) مطلوبان لإتمام تفعيل الحساب.' 
        });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = otp_code.trim();

    try {
        const verifyResult = await verifyEmailOTP(cleanEmail, cleanCode, 'register');
        if (!verifyResult.valid) {
            return res.status(400).json({ success: false, error: verifyResult.error });
        }

        const payload = verifyResult.payload;
        if (!payload || !payload.username || !payload.passwordHash || !payload.salt) {
            return res.status(400).json({ 
                success: false, 
                error: 'بيانات التسجيل المعلقة غير صالحة أو انتهت مدتها، يرجى البدء من جديد.' 
            });
        }

        // Concurrency safeguard
        const existingUsername = await dbAsync.get('SELECT id FROM users WHERE username = ?', [payload.username]);
        if (existingUsername) {
            return res.status(400).json({ success: false, error: 'اسم المستخدم مسجل مسبقاً، يرجى إعادة المحاولة.' });
        }
        const existingEmail = await dbAsync.get('SELECT id FROM users WHERE email = ?', [cleanEmail]);
        if (existingEmail) {
            return res.status(400).json({ success: false, error: 'هذا البريد مسجل مسبقاً، يرجى تسجيل الدخول.' });
        }

        const result = await dbAsync.run(`
            INSERT INTO users (username, email, password_hash, salt, email_verified)
            VALUES (?, ?, ?, ?, 1)
        `, [payload.username, cleanEmail, payload.passwordHash, payload.salt]);

        const newUser = await dbAsync.get(`
            SELECT id, username, email, discord_id, discord_username, discord_avatar, email_verified, created_at 
            FROM users WHERE id = ?
        `, [result.lastID]);

        const token = createSessionToken(newUser.id);
        res.cookie('kickmod_token', token, {
            maxAge: 30 * 24 * 3600 * 1000,
            httpOnly: true,
            sameSite: 'lax',
            path: '/'
        });

        res.status(201).json({
            success: true,
            user: newUser,
            token,
            message: 'تم التحقق من بريدك وإنشاء الحساب بنجاح! تم تسجيل دخولك.'
        });
    } catch (err) {
        res.status(500).json({ success: false, error: 'خطأ أثناء إنشاء الحساب: ' + err.message });
    }
});

/**
 * 2. Login with Username/Email & Password
 */
router.post('/login', async (req, res) => {
    const { username, password } = req.body;
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';

    if (!username || !password) {
        return res.status(400).json({ success: false, error: 'يرجى إدخال اسم المستخدم وكلمة المرور.' });
    }

    const cleanIdentifier = username.trim().toLowerCase();

    // Brute force protection
    if (!checkRateLimit(`login_ip:${clientIp}`, 15, 5 * 60 * 1000) || !checkRateLimit(`login_user:${cleanIdentifier}`, 8, 5 * 60 * 1000)) {
        return res.status(429).json({ 
            success: false, 
            error: 'تم تجاوز الحد المسموح به لمحاولات الدخول الخاطئة، يرجى الانتظار 5 دقائق لحماية الحساب.' 
        });
    }

    try {
        const user = await dbAsync.get('SELECT * FROM users WHERE username = ? OR email = ?', [cleanIdentifier, cleanIdentifier]);

        if (!user || !user.password_hash || !user.salt) {
            return res.status(401).json({ success: false, error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' });
        }

        const inputHash = hashPassword(password, user.salt);
        const expectedHash = Buffer.from(user.password_hash, 'hex');
        const calculatedHash = Buffer.from(inputHash, 'hex');

        if (expectedHash.length !== calculatedHash.length || !crypto.timingSafeEqual(expectedHash, calculatedHash)) {
            return res.status(401).json({ success: false, error: 'اسم المستخدم أو كلمة المرور غير صحيحة.' });
        }

        const token = createSessionToken(user.id);
        res.cookie('kickmod_token', token, {
            maxAge: 30 * 24 * 3600 * 1000,
            httpOnly: true,
            sameSite: 'lax',
            path: '/'
        });

        // Also fetch user's channel if any
        const channel = await dbAsync.get('SELECT * FROM channels WHERE user_id = ? LIMIT 1', [user.id]);

        res.json({
            success: true,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                discord_id: user.discord_id,
                discord_username: user.discord_username,
                discord_avatar: user.discord_avatar,
                email_verified: user.email_verified
            },
            channel: channel || null,
            token,
            message: 'تم تسجيل الدخول بنجاح!'
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

/**
 * 3. Send Quick Login OTP Code (ONLY for Existing Accounts!)
 */
router.post('/otp/send', async (req, res) => {
    const { email } = req.body;
    const clientIp = req.ip || req.socket.remoteAddress || 'unknown';

    if (!email || !EMAIL_REGEX.test(email.trim().toLowerCase())) {
        return res.status(400).json({ success: false, error: 'يرجى إدخال عنوان بريد إلكتروني صحيح ومعتمد.' });
    }

    const cleanEmail = email.trim().toLowerCase();

    // Rate limiting: max 4 OTP requests per 5 minutes
    if (!checkRateLimit(`otp:${cleanEmail}`, 4, 5 * 60 * 1000) || !checkRateLimit(`otp_ip:${clientIp}`, 12, 5 * 60 * 1000)) {
        return res.status(429).json({ 
            success: false, 
            error: 'تم تجاوز عدد طلبات الرموز المسموح بها، يرجى الانتظار 5 دقائق.' 
        });
    }

    try {
        // Quick login ONLY for existing accounts!
        const existingUser = await dbAsync.get('SELECT id, username, email FROM users WHERE email = ?', [cleanEmail]);
        if (!existingUser) {
            return res.status(404).json({
                success: false,
                code: 'USER_NOT_FOUND',
                error: 'هذا البريد الإلكتروني غير مسجل بالمنظومة، يرجى الانتقال إلى تبويب (حساب جديد) لإنشاء حسابك أولاً.'
            });
        }

        const code = await createEmailOTP(cleanEmail, 'login', { userId: existingUser.id });

        // Dispatch email via Resend / SMTP
        const emailResult = await sendOTPEmail(cleanEmail, code);

        if (!emailResult.sent) {
            return res.status(400).json({
                success: false,
                error: emailResult.message || 'تعذر إرسال رمز تسجيل الدخول إلى بريدك الإلكتروني.'
            });
        }

        res.json({
            success: true,
            sent: true,
            message: emailResult.message || `تم إرسال رمز تسجيل الدخول السريع (OTP) المكون من 6 أرقام إلى بريدك (${cleanEmail}) بنجاح وهو صالح لمدة 10 دقائق.`
        });
    } catch (err) {
        res.status(500).json({ success: false, error: 'فشل إرسال رمز التحقق: ' + err.message });
    }
});

/**
 * 4. Verify Quick Login OTP (ONLY for Existing Accounts!)
 */
router.post('/otp/verify', async (req, res) => {
    const { email, otp_code } = req.body;

    if (!email || !otp_code) {
        return res.status(400).json({ success: false, error: 'البريد الإلكتروني ورمز التحقق مطلوبان.' });
    }

    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = otp_code.trim();

    try {
        const verifyResult = await verifyEmailOTP(cleanEmail, cleanCode, 'login');
        if (!verifyResult.valid) {
            return res.status(400).json({ success: false, error: verifyResult.error });
        }

        // Must be an existing user
        let user = await dbAsync.get('SELECT * FROM users WHERE email = ?', [cleanEmail]);
        if (!user) {
            return res.status(404).json({ 
                success: false, 
                error: 'هذا البريد غير مسجل، يرجى الانتقال إلى تبويب (حساب جديد).' 
            });
        }

        // Ensure marked verified
        if (!user.email_verified) {
            await dbAsync.run('UPDATE users SET email_verified = 1 WHERE id = ?', [user.id]);
            user.email_verified = 1;
        }

        const token = createSessionToken(user.id);
        res.cookie('kickmod_token', token, {
            maxAge: 30 * 24 * 3600 * 1000,
            httpOnly: true,
            sameSite: 'lax',
            path: '/'
        });

        const channel = await dbAsync.get('SELECT * FROM channels WHERE user_id = ? LIMIT 1', [user.id]);

        res.json({
            success: true,
            user: {
                id: user.id,
                username: user.username,
                email: user.email,
                discord_id: user.discord_id,
                discord_username: user.discord_username,
                discord_avatar: user.discord_avatar,
                email_verified: user.email_verified
            },
            channel: channel || null,
            token,
            message: 'تم تسجيل الدخول السريع بنجاح!'
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

/**
 * 5. Discord OAuth2 - Step 1: Redirect to Discord
 */
router.get('/discord/login', (req, res) => {
    const params = new URLSearchParams({
        client_id: DISCORD_CLIENT_ID,
        redirect_uri: DISCORD_REDIRECT_URI,
        response_type: 'code',
        scope: 'identify email'
    });

    const discordAuthUrl = `https://discord.com/oauth2/authorize?${params.toString()}`;
    res.redirect(discordAuthUrl);
});

/**
 * 6. Discord OAuth2 - Step 2: Callback Handler
 */
router.get('/discord/callback', async (req, res) => {
    const { code, error } = req.query;

    if (error || !code) {
        console.warn('[Discord OAuth2] Authorization cancelled or denied:', error);
        return res.redirect('/?auth_error=' + encodeURIComponent('تم إلغاء تسجيل الدخول عبر ديسكورد'));
    }

    try {
        // Exchange authorization code for access token
        const body = new URLSearchParams({
            client_id: DISCORD_CLIENT_ID,
            client_secret: DISCORD_CLIENT_SECRET,
            grant_type: 'authorization_code',
            code: code.toString(),
            redirect_uri: DISCORD_REDIRECT_URI
        });

        const tokenResponse = await fetch('https://discord.com/api/oauth2/token', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/x-www-form-urlencoded'
            },
            body: body.toString()
        });

        const tokenData = await tokenResponse.json();
        if (!tokenResponse.ok || !tokenData.access_token) {
            console.error('[Discord OAuth2] Failed to exchange token:', tokenData);
            return res.redirect('/?auth_error=' + encodeURIComponent('فشل استرداد توكن ديسكورد'));
        }

        // Fetch User Info
        const userResponse = await fetch('https://discord.com/api/users/@me', {
            headers: {
                Authorization: `Bearer ${tokenData.access_token}`
            }
        });

        const discordUser = await userResponse.json();
        if (!userResponse.ok || !discordUser.id) {
            console.error('[Discord OAuth2] Failed to fetch user info:', discordUser);
            return res.redirect('/?auth_error=' + encodeURIComponent('فشل استرداد بيانات حساب ديسكورد'));
        }

        const discordId = discordUser.id;
        const discordTag = discordUser.global_name || discordUser.username;
        const discordEmail = discordUser.email ? discordUser.email.toLowerCase() : null;
        const avatarUrl = discordUser.avatar
            ? `https://cdn.discordapp.com/avatars/${discordId}/${discordUser.avatar}.png`
            : `https://cdn.discordapp.com/embed/avatars/${parseInt(discordUser.discriminator || '0', 10) % 5}.png`;

        // Check if user exists by discord_id OR email
        let user = await dbAsync.get('SELECT * FROM users WHERE discord_id = ?', [discordId]);

        if (!user && discordEmail) {
            user = await dbAsync.get('SELECT * FROM users WHERE email = ?', [discordEmail]);
        }

        if (user) {
            // Update discord link & avatar
            await dbAsync.run(`
                UPDATE users 
                SET discord_id = ?, discord_username = ?, discord_avatar = ?
                WHERE id = ?
            `, [discordId, discordTag, avatarUrl, user.id]);
            user.discord_id = discordId;
            user.discord_username = discordTag;
            user.discord_avatar = avatarUrl;
        } else {
            // Create brand new user
            let usernameCandidate = discordUser.username.toLowerCase().replace(/[^a-zA-Z0-9_]/g, '');
            if (!usernameCandidate || usernameCandidate.length < 3) {
                usernameCandidate = `user_${discordId.slice(-4)}`;
            }

            const existingUser = await dbAsync.get('SELECT id FROM users WHERE username = ?', [usernameCandidate]);
            if (existingUser) {
                usernameCandidate = `${usernameCandidate}_${crypto.randomInt(10, 99)}`;
            }

            const insertResult = await dbAsync.run(`
                INSERT INTO users (username, email, discord_id, discord_username, discord_avatar, email_verified)
                VALUES (?, ?, ?, ?, ?, 1)
            `, [usernameCandidate, discordEmail, discordId, discordTag, avatarUrl]);

            user = await dbAsync.get('SELECT * FROM users WHERE id = ?', [insertResult.lastID]);
        }

        // Create secure session token
        const token = createSessionToken(user.id);
        res.cookie('kickmod_token', token, {
            maxAge: 30 * 24 * 3600 * 1000,
            httpOnly: true,
            sameSite: 'lax',
            path: '/'
        });

        console.log(`[Discord OAuth2] User successfully authenticated: ${user.username} (Discord: ${discordTag})`);
        res.redirect(`/?auth=success&u=${encodeURIComponent(user.username)}`);
    } catch (err) {
        console.error('[Discord OAuth2] Callback error:', err);
        res.redirect('/?auth_error=' + encodeURIComponent(err.message));
    }
});

/**
 * 7. Get Current Session Info (User + Channel)
 */
router.get('/me', async (req, res) => {
    const token = extractToken(req);
    const userId = verifySessionToken(token);

    if (!userId) {
        return res.json({ success: true, authenticated: false, user: null, channel: null });
    }

    try {
        const user = await dbAsync.get(`
            SELECT id, username, email, discord_id, discord_username, discord_avatar, email_verified, created_at 
            FROM users WHERE id = ?
        `, [userId]);

        if (!user) {
            return res.json({ success: true, authenticated: false, user: null, channel: null });
        }

        const channel = await dbAsync.get(`
            SELECT c.*, 
                (SELECT COUNT(*) FROM moderators m WHERE m.channel_id = c.id) as total_mods,
                (SELECT COUNT(*) FROM mod_actions a WHERE a.channel_id = c.id) as total_actions
            FROM channels c
            WHERE c.user_id = ?
            LIMIT 1
        `, [user.id]);

        res.json({
            success: true,
            authenticated: true,
            user,
            channel: channel || null
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

/**
 * 8. Logout
 */
router.post('/logout', (req, res) => {
    res.clearCookie('kickmod_token', { path: '/' });
    res.json({ success: true, message: 'تم تسجيل الخروج بنجاح.' });
});

module.exports = router;

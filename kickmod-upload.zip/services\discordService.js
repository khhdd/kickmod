/**
 * Discord Webhook Notification Service
 */
async function sendModActionEmbed(webhookUrl, { channelName, moderator, actionType, targetUser, durationSeconds, reason }) {
    if (!webhookUrl || !webhookUrl.startsWith('https://discord.com/api/webhooks/')) {
        return false;
    }

    let color = 0x53fc18; // Kick green
    let title = '🛡️ Mod Action Executed';
    let description = '';

    const durationStr = durationSeconds
        ? (durationSeconds >= 60 ? `${Math.round(durationSeconds / 60)} minutes` : `${durationSeconds} seconds`)
        : '';

    switch (actionType) {
        case 'ban':
            color = 0xef4444; // Red
            title = '🚫 Permanent Ban';
            description = `**Moderator:** \`${moderator}\` permanently banned **${targetUser}**`;
            break;
        case 'timeout':
            color = 0xf59e0b; // Amber / Orange
            title = '⏳ User Timed Out';
            description = `**Moderator:** \`${moderator}\` timed out **${targetUser}** for **${durationStr}**`;
            break;
        case 'unban':
            color = 0x3b82f6; // Blue
            title = '🔓 User Unbanned';
            description = `**Moderator:** \`${moderator}\` unbanned **${targetUser}**`;
            break;
        case 'delete_message':
            color = 0x8b5cf6; // Purple
            title = '🗑️ Message Deleted';
            description = `A message from **${targetUser}** was removed by moderation`;
            break;
        default:
            description = `**Moderator:** \`${moderator}\` performed \`${actionType}\` on **${targetUser}**`;
    }

    const payload = {
        username: `KickMod Tracker [${channelName}]`,
        avatar_url: 'https://kick.com/favicon.ico',
        embeds: [
            {
                title,
                description,
                color,
                fields: [
                    { name: 'Channel', value: `[kick.com/${channelName}](https://kick.com/${channelName})`, inline: true },
                    { name: 'Moderator', value: moderator || 'Unknown', inline: true },
                    { name: 'Target User', value: targetUser || 'N/A', inline: true }
                ],
                footer: {
                    text: 'KickMod Multi-Channel Monitor'
                },
                timestamp: new Date().toISOString()
            }
        ]
    };

    if (reason) {
        payload.embeds[0].fields.push({ name: 'Reason', value: reason, inline: false });
    }

    try {
        const res = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        return res.ok;
    } catch (err) {
        console.error('Failed to send Discord webhook:', err.message);
        return false;
    }
}

async function sendTestWebhook(webhookUrl, channelName) {
    if (!webhookUrl) return false;
    try {
        const res = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({
                username: `KickMod Tracker [${channelName}]`,
                embeds: [
                    {
                        title: '✅ Discord Webhook Connected Successfully!',
                        description: `KickMod is now monitoring **kick.com/${channelName}** and will forward all moderator actions here in real-time.`,
                        color: 0x53fc18,
                        footer: { text: 'KickMod Monitoring System' },
                        timestamp: new Date().toISOString()
                    }
                ]
            })
        });
        return res.ok;
    } catch (err) {
        return false;
    }
}

/**
 * Send Rich Stream Report Analytics to Discord
 */
async function sendStreamReportEmbed(webhookUrl, { channelName, title, durationMinutes, attendanceRate, activeModsCount, totalModsCount, totalBans, totalTimeouts, mvpName, summaryText }) {
    if (!webhookUrl || !webhookUrl.startsWith('https://discord.com/api/webhooks/')) {
        return false;
    }

    const payload = {
        username: `KickMod Analytics [${channelName}]`,
        avatar_url: 'https://kick.com/favicon.ico',
        embeds: [
            {
                title: `📊 تقرير تحليلي للبث المباشر: ${title || 'بث مباشر'}`,
                description: summaryText || `ملخص أداء طاقم الإشراف والرقابة لقناة **kick.com/${channelName}**`,
                color: 0x53fc18,
                fields: [
                    { name: '⏱️ مدة البث', value: `${durationMinutes} دقيقة`, inline: true },
                    { name: '👥 نسبة التزام الطاقم', value: `${attendanceRate}% (${activeModsCount} من ${totalModsCount})`, inline: true },
                    { name: '⭐ نجم البث (MVP)', value: mvpName ? `\`${mvpName}\`` : 'لا يوجد', inline: true },
                    { name: '🚫 عمليات الحظر', value: `${totalBans} حظر دائم`, inline: true },
                    { name: '⏳ عمليات الكتم', value: `${totalTimeouts} كتم مؤقت`, inline: true },
                    { name: '🛡️ القناة', value: `[kick.com/${channelName}](https://kick.com/${channelName})`, inline: true }
                ],
                footer: {
                    text: 'KickMod Automated Intelligence & Analytics'
                },
                timestamp: new Date().toISOString()
            }
        ]
    };

    try {
        const res = await fetch(webhookUrl, {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify(payload)
        });
        return res.ok;
    } catch (err) {
        console.error('Failed to send Discord stream report embed:', err.message);
        return false;
    }
}

module.exports = {
    sendModActionEmbed,
    sendTestWebhook,
    sendStreamReportEmbed
};


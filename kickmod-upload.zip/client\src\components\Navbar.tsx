import { useEffect, useState } from "react";
import {
  AlertCircle,
  CheckCircle2,
  KeyRound,
  LayoutDashboard,
  Loader2,
  LogIn,
  LogOut,
  Mail,
  Menu,
  Radio,
  RefreshCw,
  ShieldCheck,
  User,
  UserPlus,
  X
} from "lucide-react";
import { PingDot } from "./ui";

const links = [
  { href: "#top", label: "الرئيسية" },
  { href: "#features", label: "المميزات" },
  { href: "/dashboard", label: "الداشبورد" },
  { href: "#steps", label: "كيف يعمل" },
  { href: "#faq", label: "الأسئلة الشائعة" },
];

export function DiscordIcon({ className = "" }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="currentColor">
      <path d="M20.3 4.4A19.8 19.8 0 0 0 15.4 3l-.2.5a14 14 0 0 0-4.4 0L10.6 3a19.7 19.7 0 0 0-4.9 1.4C2.6 9 1.8 13.5 2.2 18a19.9 19.9 0 0 0 6 3l1-1.7a13 13 0 0 1-1.6-.8l.4-.3a14.2 14.2 0 0 0 12 0l.4.3c-.5.3-1 .6-1.6.8l1 1.7a19.8 19.8 0 0 0 6-3c.5-5.2-.8-9.7-3.5-13.6ZM9 15.3c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4 2.1 1.1 2.1 2.4-.9 2.4-2.1 2.4Zm6 0c-1.2 0-2.1-1.1-2.1-2.4s.9-2.4 2.1-2.4 2.1 1.1 2.1 2.4-.9 2.4-2.1 2.4Z" />
    </svg>
  );
}

interface NavbarProps {
  user: any;
  setUser: (u: any) => void;
  channel: any;
  openModal: "login" | "register" | null;
  setOpenModal: (m: "login" | "register" | null) => void;
  onRefreshSession: () => void;
}

export default function Navbar({
  user,
  setUser,
  channel,
  openModal,
  setOpenModal,
  onRefreshSession
}: NavbarProps) {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const [syncing, setSyncing] = useState(false);
  const [active, setActive] = useState("#top");

  // Auth form states
  const [authTab, setAuthTab] = useState<"login" | "register">("login");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [email, setEmail] = useState("");
  const [authError, setAuthError] = useState("");
  const [authSuccess, setAuthSuccess] = useState("");
  const [authLoading, setAuthLoading] = useState(false);

  useEffect(() => {
    if (openModal) {
      setAuthTab(openModal);
      setAuthError("");
      setAuthSuccess("");
    }
  }, [openModal]);

  useEffect(() => {
    const on = () => setScrolled(window.scrollY > 20);
    on();
    window.addEventListener("scroll", on, { passive: true });
    return () => window.removeEventListener("scroll", on);
  }, []);

  useEffect(() => {
    const ids = links.map((l) => l.href.slice(1));
    const io = new IntersectionObserver(
      (entries) => {
        entries.forEach((e) => e.isIntersecting && setActive("#" + e.target.id));
      },
      { rootMargin: "-40% 0px -55% 0px" }
    );
    ids.forEach((id) => {
      const el = document.getElementById(id);
      if (el) io.observe(el);
    });
    return () => io.disconnect();
  }, []);

  const sync = async () => {
    setSyncing(true);
    await onRefreshSession();
    setTimeout(() => setSyncing(false), 900);
  };

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthSuccess("");
    setAuthLoading(true);
    try {
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ username, password }),
      });
      const data = await res.json();
      if (!data.success) {
        setAuthLoading(false);
        return setAuthError(data.error || "خطأ في تسجيل الدخول");
      }
      await new Promise((r) => setTimeout(r, 400));
      setUser(data.user);
      onRefreshSession();
      setOpenModal(null);
      setUsername("");
      setPassword("");
    } catch (err: any) {
      setAuthError(err.message || "حدث خطأ بالاتصال بالسيرفر");
    } finally {
      setAuthLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setAuthError("");
    setAuthSuccess("");

    if (!username || username.trim().length < 3) {
      return setAuthError("اسم المستخدم إجباري ويجب أن يكون 3 أحرف على الأقل.");
    }
    if (!email || !email.includes("@")) {
      return setAuthError("يرجى إدخال عنوان بريد إلكتروني صحيح.");
    }
    if (!password || password.length < 6) {
      return setAuthError("كلمة المرور إجبارية ويجب أن تكون 6 خانات على الأقل.");
    }

    setAuthLoading(true);
    try {
      const res = await fetch("/api/auth/register", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        credentials: "include",
        body: JSON.stringify({ 
          username: username.trim(), 
          password, 
          email: email.trim() 
        }),
      });
      const data = await res.json();
      if (!data.success) {
        setAuthLoading(false);
        return setAuthError(data.error || "فشل إنشاء الحساب");
      }

      setUser(data.user);
      onRefreshSession();
      setOpenModal(null);
      setUsername("");
      setPassword("");
      setEmail("");
    } catch (err: any) {
      setAuthError(err.message || "حدث خطأ بالاتصال بالسيرفر");
    } finally {
      setAuthLoading(false);
    }
  };

  const logout = async () => {
    try {
      await fetch("/api/auth/logout", { method: "POST", credentials: "include" });
    } catch (e) {
      console.error(e);
    }
    localStorage.removeItem("kickmod_user");
    setUser(null);
    onRefreshSession();
  };

  const scrollToDashboard = () => {
    const el = document.getElementById("dashboard");
    if (el) {
      el.scrollIntoView({ behavior: "smooth" });
    }
  };

  return (
    <>
      <header className="fixed inset-x-0 top-0 z-50 px-3 pt-3">
        <div
          className={`mx-auto max-w-7xl rounded-2xl border transition-all duration-300 ${
            scrolled
              ? "border-white/10 bg-[#0a0e0d]/90 shadow-2xl shadow-black/80 backdrop-blur-xl"
              : "border-transparent bg-transparent"
          }`}
        >
          <div className="flex items-center justify-between gap-4 px-4 py-3">
            {/* Logo */}
            <a href="#top" className="flex items-center gap-3">
              <div className="relative flex h-11 w-11 items-center justify-center rounded-xl border border-kick/60 bg-kick/10 shadow-[0_0_22px_rgba(83,252,24,0.35)]">
                <ShieldCheck className="h-5 w-5 text-kick" />
              </div>
              <div>
                <div dir="ltr" className="text-xl font-black leading-none tracking-[0.2em]">
                  KICK<span className="text-kick">MOD</span>
                </div>
                <div className="mt-1.5 flex items-center gap-2 text-[10px] text-gray-400">
                  <PingDot />
                  المحرك المباشر متصل 24/7
                </div>
              </div>
            </a>

            {/* Links */}
            <nav className="hidden items-center gap-1 text-sm font-semibold lg:flex">
              {links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  className={`rounded-xl px-4 py-2 transition ${
                    active === l.href
                      ? "bg-kick text-black shadow-[0_0_20px_rgba(83,252,24,0.4)]"
                      : "text-gray-400 hover:bg-white/5 hover:text-white"
                  }`}
                >
                  {l.label}
                </a>
              ))}
            </nav>

            {/* Actions */}
            <div className="flex items-center gap-2">
              <button
                onClick={sync}
                className="hidden items-center gap-1.5 rounded-xl border border-white/10 bg-white/5 px-3 py-2 text-xs font-bold text-kick transition hover:border-kick/40 sm:flex"
                title="تحديث البيانات"
              >
                <RefreshCw className={`h-3.5 w-3.5 ${syncing ? "animate-spin" : ""}`} />
                {syncing ? "جارٍ..." : "مزامنة"}
              </button>

              {user ? (
                <div className="flex items-center gap-2">
                  {/* DIRECT BUTTON TO CHANNEL DASHBOARD */}
                  <a
                    href="/dashboard"
                    className="btn-shine flex items-center gap-2 rounded-xl bg-kick px-3.5 py-2 text-xs font-black text-black shadow-[0_0_20px_rgba(83,252,24,0.45)] transition hover:brightness-110"
                  >
                    <Radio className="h-3.5 w-3.5 animate-pulse text-black" />
                    دخول الداشبورد
                    {channel?.slug && (
                      <span dir="ltr" className="rounded bg-black/20 px-1.5 py-0.5 text-[10px]">
                        @{channel.slug}
                      </span>
                    )}
                  </a>

                  {/* User profile capsule */}
                  <div className="flex items-center gap-2 rounded-xl border border-white/10 bg-black/60 px-3 py-1.5 text-xs font-bold">
                    {user.discord_avatar ? (
                      <img
                        src={user.discord_avatar}
                        alt="Avatar"
                        className="h-5 w-5 rounded-full object-cover"
                      />
                    ) : (
                      <User className="h-3.5 w-3.5 text-kick" />
                    )}
                    <span className="max-w-[120px] truncate text-gray-200">
                      {user.discord_username || user.username}
                    </span>
                    <button
                      onClick={logout}
                      className="text-gray-400 hover:text-red-400 transition ms-1"
                      title="تسجيل الخروج"
                    >
                      <LogOut className="h-3.5 w-3.5" />
                    </button>
                  </div>
                </div>
              ) : (
                <>
                  <a
                    href="/dashboard"
                    className="hidden items-center gap-1.5 rounded-xl border border-kick/40 bg-kick/10 px-3 py-2 text-xs font-bold text-kick transition hover:bg-kick hover:text-black md:flex"
                  >
                    <Radio className="h-3.5 w-3.5 animate-pulse" />
                    الداشبورد
                  </a>

                  <button
                    onClick={() => {
                      setAuthTab("login");
                      setOpenModal("login");
                    }}
                    className="hidden items-center gap-1.5 px-3 py-2 text-xs font-bold text-gray-300 transition hover:text-white md:flex"
                  >
                    <LogIn className="h-3.5 w-3.5" />
                    تسجيل الدخول
                  </button>

                  <button
                    onClick={() => {
                      setAuthTab("register");
                      setOpenModal("register");
                    }}
                    className="btn-shine hidden items-center gap-1.5 rounded-xl bg-kick px-4 py-2 text-xs font-extrabold text-black transition hover:brightness-110 md:flex"
                  >
                    <UserPlus className="h-3.5 w-3.5" />
                    حساب جديد
                  </button>

                  {/* Real Discord OAuth2 Button */}
                  <a
                    href="/api/auth/discord/login"
                    className="flex items-center gap-1.5 rounded-xl bg-[#5865f2] px-3.5 py-2 text-xs font-bold text-white shadow-[0_0_20px_rgba(88,101,242,0.4)] transition hover:brightness-110"
                  >
                    <DiscordIcon className="h-4 w-4" />
                    ديسكورد
                  </a>
                </>
              )}

              <button
                onClick={() => setOpen(!open)}
                className="rounded-xl border border-white/10 p-2 lg:hidden"
                aria-label="القائمة"
              >
                {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
              </button>
            </div>
          </div>

          {/* Mobile menu */}
          {open && (
            <div className="animate-slide-in space-y-1 border-t border-white/5 p-3 lg:hidden">
              {links.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="block rounded-xl px-4 py-3 text-sm font-semibold text-gray-300 hover:bg-white/5"
                >
                  {l.label}
                </a>
              ))}
              {user ? (
                <div className="pt-2">
                  <button
                    onClick={() => {
                      setOpen(false);
                      scrollToDashboard();
                    }}
                    className="flex w-full items-center justify-center gap-2 rounded-xl bg-kick py-3 text-sm font-extrabold text-black"
                  >
                    <Radio className="h-4 w-4" />
                    دخول لوحة قناتي المباشرة
                  </button>
                  <button
                    onClick={() => {
                      setOpen(false);
                      logout();
                    }}
                    className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl border border-white/10 py-2.5 text-xs font-bold text-gray-400 hover:text-red-400"
                  >
                    <LogOut className="h-4 w-4" />
                    تسجيل الخروج ({user.username})
                  </button>
                </div>
              ) : (
                <div className="flex flex-col gap-2 pt-2">
                  <button
                    onClick={() => {
                      setAuthTab("login");
                      setOpenModal("login");
                      setOpen(false);
                    }}
                    className="rounded-xl border border-white/10 py-2.5 text-sm font-bold text-white hover:bg-white/5"
                  >
                    تسجيل الدخول
                  </button>
                  <button
                    onClick={() => {
                      setAuthTab("register");
                      setOpenModal("register");
                      setOpen(false);
                    }}
                    className="rounded-xl bg-kick py-3 text-sm font-extrabold text-black"
                  >
                    إنشاء حساب جديد
                  </button>
                  <a
                    href="/api/auth/discord/login"
                    className="flex items-center justify-center gap-2 rounded-xl bg-[#5865f2] py-3 text-sm font-bold text-white"
                  >
                    <DiscordIcon className="h-4 w-4" />
                    تسجيل الدخول عبر ديسكورد
                  </a>
                </div>
              )}
            </div>
          )}
        </div>
      </header>

      {/* AUTHENTICATION MODAL */}
      {openModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/85 backdrop-blur-md p-4">
          <div className="relative w-full max-w-md rounded-3xl border border-white/10 bg-[#0e1413] p-7 shadow-[0_0_80px_rgba(0,0,0,0.9)]">
            <button
              onClick={() => setOpenModal(null)}
              className="absolute start-4 top-4 rounded-xl border border-white/10 p-2 text-gray-400 hover:text-white transition"
            >
              <X className="h-4 w-4" />
            </button>

            {/* Modal Tabs: 2 Clean Tabs */}
            <div className="flex border-b border-white/10 pb-3 mb-6 gap-2">
              <button
                type="button"
                onClick={() => {
                  setAuthTab("login");
                  setAuthError("");
                  setAuthSuccess("");
                }}
                className={`flex-1 rounded-xl py-2.5 text-xs font-bold transition ${
                  authTab === "login"
                    ? "bg-kick text-black font-black shadow-md"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                تسجيل الدخول
              </button>
              <button
                type="button"
                onClick={() => {
                  setAuthTab("register");
                  setAuthError("");
                  setAuthSuccess("");
                }}
                className={`flex-1 rounded-xl py-2.5 text-xs font-bold transition ${
                  authTab === "register"
                    ? "bg-kick text-black font-black shadow-md"
                    : "text-gray-400 hover:text-white"
                }`}
              >
                حساب جديد
              </button>
            </div>

            {/* Direct Discord OAuth2 button */}
            <div className="mb-6">
              <a
                href="/api/auth/discord/login"
                className="flex w-full items-center justify-center gap-2.5 rounded-xl bg-[#5865f2] py-3 text-xs font-bold text-white shadow-[0_0_25px_rgba(88,101,242,0.35)] transition hover:brightness-110"
              >
                <DiscordIcon className="h-4 w-4" />
                المتابعة السريعة عبر ديسكورد (OAuth2)
              </a>
              <div className="relative my-4 text-center">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-white/10" />
                </div>
                <span className="relative bg-[#0e1413] px-3 text-[11px] font-bold text-gray-500">
                  أو عبر البريد والبيانات
                </span>
              </div>
            </div>

            {/* TAB 1: LOGIN */}
            {authTab === "login" && (
              <form onSubmit={handleLogin} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">
                    اسم المستخدم أو البريد
                  </label>
                  <input
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="اسم المستخدم أو البريد"
                    className="w-full rounded-xl border border-white/10 bg-black/70 px-4 py-3 text-sm outline-none transition focus:border-kick"
                  />
                </div>
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">
                    كلمة المرور
                  </label>
                  <input
                    required
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="••••••••"
                    className="w-full rounded-xl border border-white/10 bg-black/70 px-4 py-3 text-sm outline-none transition focus:border-kick"
                  />
                </div>

                {authError && (
                  <div className="flex items-center gap-2 text-xs text-red-300 bg-red-950/40 p-3 rounded-xl border border-red-900/60">
                    <AlertCircle className="h-4 w-4 shrink-0 text-red-400" />
                    <span>{authError}</span>
                  </div>
                )}

                <button
                  type="submit"
                  disabled={authLoading}
                  className="btn-shine flex items-center justify-center gap-2 w-full rounded-xl bg-kick py-3.5 text-sm font-black text-black shadow-lg hover:brightness-110 disabled:opacity-75 disabled:cursor-not-allowed"
                >
                  {authLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin text-black" />
                      <span>جارٍ تسجيل الدخول...</span>
                    </>
                  ) : (
                    <span>تسجيل الدخول</span>
                  )}
                </button>

                <div className="pt-2 text-center border-t border-white/5">
                  <span className="text-xs text-gray-500">ليس لديك حساب؟ </span>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthTab("register");
                      setAuthError("");
                      setAuthSuccess("");
                    }}
                    className="text-xs text-kick font-bold hover:underline"
                  >
                    إنشاء حساب جديد
                  </button>
                </div>
              </form>
            )}

            {/* TAB 2: REGISTER (INSTANT REGISTRATION - NO OTP) */}
            {authTab === "register" && (
              <form onSubmit={handleRegister} className="space-y-4">
                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">
                    اسم المستخدم (Username) <span className="text-kick">*</span>
                  </label>
                  <input
                    required
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                    placeholder="اسم مستخدم فريد (إنجليزية وأرقام)"
                    className="w-full rounded-xl border border-white/10 bg-black/70 px-4 py-3 text-sm outline-none transition focus:border-kick"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">
                    البريد الإلكتروني <span className="text-kick">*</span>
                  </label>
                  <input
                    required
                    type="email"
                    value={email}
                    onChange={(e) => setEmail(e.target.value)}
                    placeholder="name@example.com"
                    className="w-full rounded-xl border border-white/10 bg-black/70 px-4 py-3 text-sm outline-none transition focus:border-kick"
                  />
                </div>

                <div>
                  <label className="block text-xs font-bold text-gray-300 mb-1.5">
                    كلمة المرور <span className="text-kick">*</span>
                  </label>
                  <input
                    required
                    type="password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="6 خانات على الأقل"
                    className="w-full rounded-xl border border-white/10 bg-black/70 px-4 py-3 text-sm outline-none transition focus:border-kick"
                  />
                </div>

                {authError && (
                  <div className="space-y-2">
                    <div className="flex items-center gap-2 text-xs text-red-300 bg-red-950/40 p-3 rounded-xl border border-red-900/60">
                      <AlertCircle className="h-4 w-4 shrink-0 text-red-400" />
                      <span>{authError}</span>
                    </div>
                    {authError.includes("مسجل") && (
                      <button
                        type="button"
                        onClick={() => {
                          setAuthTab("login");
                          setAuthError("");
                          setAuthSuccess("");
                        }}
                        className="w-full text-center text-xs font-bold text-kick hover:underline py-1"
                      >
                        هل لديك حساب بالفعل؟ اضغط هنا للانتقال إلى تسجيل الدخول
                      </button>
                    )}
                  </div>
                )}

                <button
                  type="submit"
                  disabled={authLoading}
                  className="btn-shine flex items-center justify-center gap-2 w-full rounded-xl bg-kick py-3.5 text-sm font-black text-black shadow-lg hover:brightness-110 disabled:opacity-75 disabled:cursor-not-allowed"
                >
                  {authLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin text-black" />
                      <span>جارٍ إنشاء الحساب والدخول...</span>
                    </>
                  ) : (
                    <>
                      <UserPlus className="h-4 w-4" />
                      <span>إنشاء الحساب والدخول الفوري</span>
                    </>
                  )}
                </button>

                <div className="pt-2 text-center border-t border-white/5">
                  <span className="text-xs text-gray-500">لديك حساب مسجل بالفعل؟ </span>
                  <button
                    type="button"
                    onClick={() => {
                      setAuthTab("login");
                      setAuthError("");
                      setAuthSuccess("");
                    }}
                    className="text-xs text-kick font-bold hover:underline"
                  >
                    تسجيل الدخول
                  </button>
                </div>
              </form>
            )}
          </div>
        </div>
      )}
    </>
  );
}

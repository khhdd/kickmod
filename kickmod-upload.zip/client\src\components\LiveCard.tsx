import { useEffect, useMemo, useRef, useState } from "react";
import { Ban, Bot, Eye, Timer, Trash2, Zap, TrendingDown, TrendingUp, type LucideIcon } from "lucide-react";
import { DiscordIcon } from "./Navbar";
import { PingDot } from "./ui";

/* ---------- fake data generators ---------- */
const pick = <T,>(a: T[]) => a[Math.floor(Math.random() * a.length)];
const rnd = (a: number, b: number) => Math.floor(a + Math.random() * (b - a + 1));

const pre = ["Dark", "Toxic", "Lazy", "Mega", "Ninja", "Shadow", "Turbo", "Crazy", "Night", "Ghost", "Fire", "Cool", "Alpha", "Storm", "Pixel"];
const mid = ["Gamer", "Wolf", "Troll", "Sniper", "Viewer", "Hunter", "Fan", "Boss", "Rider", "Spam", "Zombie", "Panda", "Eagle"];
const botPre = ["viewer_bot_", "follow4follow_", "streamboost_", "cheap_views_", "auto_chat_"];
const mods = ["ModAhmed", "Layla_Mod", "Zeyad_X", "KingSami", "Nour_Mod"];
const banReasons = ["سبام روابط", "ألفاظ مسيئة", "انتحال شخصية", "تحريض", "إعلانات مزعجة"];
const delReasons = ["رسالة مكررة", "رابط خارجي", "حروف كابيتال زائدة", "إيموجي مفرط"];

const fakeUser = () => {
  const s = rnd(0, 2);
  if (s === 0) return `${pick(pre)}_${pick(mid)}${rnd(1, 99)}`;
  if (s === 1) return `${pick(pre)}${pick(mid)}`;
  return `${pick(mid).toLowerCase()}.${pick(pre).toLowerCase()}${rnd(10, 99)}`;
};

type Ev = {
  key: number;
  ts: number;
  icon: LucideIcon;
  tone: string;
  title: string;
  user: string;
  meta: string;
  alert: boolean;
};

let counter = 0;
const makeEvent = (ts = Date.now()): Ev => {
  const r = Math.random();
  const mod = pick(mods);
  const base = { key: ++counter, ts };
  if (r < 0.2)
    return { ...base, icon: Ban, tone: "text-red-400 bg-red-500/10", title: "حظر دائم لـ", user: fakeUser(), meta: `${mod} · ${pick(banReasons)}`, alert: true };
  if (r < 0.45)
    return { ...base, icon: Timer, tone: "text-amber-400 bg-amber-500/10", title: `كتم ${pick([5, 10, 15, 30, 60])} دقيقة لـ`, user: fakeUser(), meta: `${mod} · ${pick(banReasons)}`, alert: true };
  if (r < 0.65)
    return { ...base, icon: Bot, tone: "text-cyan-400 bg-cyan-500/10", title: "تم عزل بوت تلقائي:", user: pick(botPre) + rnd(10, 999), meta: `نسبة التأكد ${rnd(91, 99)}%`, alert: true };
  if (r < 0.8)
    return { ...base, icon: Trash2, tone: "text-orange-300 bg-orange-500/10", title: "حذف رسالة من", user: fakeUser(), meta: `${mod} · ${pick(delReasons)}`, alert: false };
  return { ...base, icon: Eye, tone: "text-kick bg-kick/10", title: "حضور صامت للمشرف", user: mod, meta: `متواجد منذ ${rnd(3, 95)} دقيقة بدون كتابة`, alert: false };
};

const age = (ts: number, now: number) => {
  const s = Math.max(0, Math.floor((now - ts) / 1000));
  if (s < 3) return "الآن";
  if (s < 60) return `قبل ${s} ث`;
  return `قبل ${Math.floor(s / 60)} د`;
};

const pad = (n: number) => String(n).padStart(2, "0");

/* ---------- component ---------- */
const N = 36;

export default function LiveCard() {
  const [now, setNow] = useState(() => Date.now());
  const startRef = useRef(Date.now());
  const [feed, setFeed] = useState<Ev[]>(() => {
    const t = Date.now();
    return [95, 47, 21, 8].map((s) => makeEvent(t - s * 1000));
  });
  const [bots, setBots] = useState(37);
  const [activeMods, setActiveMods] = useState(12);
  const [hist, setHist] = useState<number[]>(() => {
    let v = 12400;
    return Array.from({ length: N }, () => (v = Math.max(11800, Math.min(13200, v + rnd(-110, 110)))));
  });
  const [toast, setToast] = useState<Ev | null>(null);

  // clock
  useEffect(() => {
    const t = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(t);
  }, []);

  // viewers + mods
  useEffect(() => {
    const t = setInterval(() => {
      setHist((h) => {
        const last = h[h.length - 1];
        const next = Math.max(11800, Math.min(13200, last + rnd(-130, 140)));
        return [...h.slice(1), next];
      });
    }, 1400);
    const m = setInterval(() => setActiveMods(rnd(11, 13)), 5000);
    return () => {
      clearInterval(t);
      clearInterval(m);
    };
  }, []);

  // events
  useEffect(() => {
    let alive = true;
    let t = 0;
    let toastT = 0;
    const loop = () => {
      t = window.setTimeout(() => {
        if (!alive) return;
        const e = makeEvent();
        setFeed((f) => [e, ...f].slice(0, 4));
        if (e.icon === Bot) setBots((b) => b + 1);
        if (e.alert && Math.random() < 0.8) {
          setToast(e);
          clearTimeout(toastT);
          toastT = window.setTimeout(() => setToast(null), 3400);
        }
        loop();
      }, rnd(1900, 4000));
    };
    loop();
    return () => {
      alive = false;
      clearTimeout(t);
      clearTimeout(toastT);
    };
  }, []);

  const viewers = hist[hist.length - 1];
  const delta = viewers - hist[hist.length - 2];

  const { line, area } = useMemo(() => {
    const min = Math.min(...hist);
    const max = Math.max(...hist);
    const range = Math.max(max - min, 1);
    const pts = hist.map((v, i) => [(i * 300) / (N - 1), 46 - ((v - min) / range) * 38] as const);
    const l = pts.map(([x, y], i) => `${i ? "L" : "M"}${x.toFixed(1)} ${y.toFixed(1)}`).join(" ");
    return { line: l, area: `${l} L300 56 L0 56 Z`, last: pts[pts.length - 1] };
  }, [hist]);

  const up = Math.floor((now - startRef.current) / 1000) + 2 * 3600 + 14 * 60 + 7;

  return (
    <div className="relative mx-auto w-full max-w-md">
      <div className="animate-spin-slow absolute -inset-10 -z-10 rounded-full border border-dashed border-kick/20" />
      <div className="absolute -inset-4 -z-10 rounded-[2rem] bg-kick/10 blur-3xl" />

      <div className="glass animate-float relative overflow-hidden rounded-3xl p-5 shadow-2xl shadow-black/60">
        <div className="animate-scan pointer-events-none absolute inset-x-0 h-24 bg-gradient-to-b from-transparent via-kick/10 to-transparent" />

        {/* header */}
        <div className="mb-4 flex items-center justify-between">
          <div className="flex items-center gap-2 text-sm font-bold">
            <PingDot className="bg-red-500" />
            بث مباشر · <span dir="ltr" className="text-kick">example</span>
          </div>
          <span dir="ltr" className="rounded-lg bg-white/5 px-2.5 py-1 font-mono text-[11px] font-bold tabular-nums text-gray-300">
            {pad(Math.floor(up / 3600))}:{pad(Math.floor((up % 3600) / 60))}:{pad(up % 60)}
          </span>
        </div>

        {/* stats */}
        <div className="mb-3 grid grid-cols-3 gap-2 text-center">
          <div className="rounded-xl border border-white/5 bg-black/40 py-3">
            <div className="flex items-center justify-center gap-1 text-lg font-black tabular-nums">
              {viewers.toLocaleString("en-US")}
              {delta >= 0 ? <TrendingUp className="h-3 w-3 text-kick" /> : <TrendingDown className="h-3 w-3 text-red-400" />}
            </div>
            <div className="text-[10px] text-gray-500">المشاهدون</div>
          </div>
          <div className="rounded-xl border border-white/5 bg-black/40 py-3">
            <div className="text-lg font-black tabular-nums text-kick">{activeMods}</div>
            <div className="text-[10px] text-gray-500">مشرفون نشطون</div>
          </div>
          <div className="rounded-xl border border-white/5 bg-black/40 py-3">
            <div key={bots} className="animate-slide-in text-lg font-black tabular-nums text-cyan-400">{bots}</div>
            <div className="text-[10px] text-gray-500">بوتات معزولة</div>
          </div>
        </div>

        {/* sparkline */}
        <div className="mb-3 rounded-xl border border-white/5 bg-black/40 px-3 pb-1 pt-2.5">
          <div className="mb-1 text-[10px] text-gray-500">حركة المشاهدين · آخر دقيقة</div>
          <svg viewBox="0 0 300 56" className="h-12 w-full" preserveAspectRatio="none">
            <defs>
              <linearGradient id="spark" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#53fc18" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#53fc18" stopOpacity="0" />
              </linearGradient>
            </defs>
            <path d={area} fill="url(#spark)" />
            <path d={line} fill="none" stroke="#53fc18" strokeWidth="2" strokeLinejoin="round" vectorEffect="non-scaling-stroke" />
          </svg>
        </div>

        {/* feed */}
        <div className="space-y-2">
          {feed.map((e) => (
            <div key={e.key} className="animate-slide-in flex items-center gap-3 rounded-xl border border-white/5 bg-black/40 px-3 py-2.5 text-xs">
              <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${e.tone}`}>
                <e.icon className="h-4 w-4" />
              </span>
              <div className="min-w-0">
                <div className="truncate text-gray-300">
                  {e.title} <b dir="ltr" className="font-bold text-white">{e.user}</b>
                </div>
                <div className="truncate text-[10px] text-gray-500">{e.meta}</div>
              </div>
              <span className="ms-auto shrink-0 text-[10px] tabular-nums text-gray-600">{age(e.ts, now)}</span>
            </div>
          ))}
        </div>
      </div>

      {/* discord toast */}
      <div
        className={`glass absolute -bottom-7 -start-4 z-10 hidden max-w-[270px] items-center gap-3 rounded-2xl px-4 py-3 shadow-xl shadow-black/50 transition-all duration-500 sm:flex ${
          toast ? "translate-y-0 opacity-100" : "translate-y-4 opacity-0"
        }`}
      >
        <span className="flex h-9 w-9 shrink-0 items-center justify-center rounded-xl bg-indigo-500/20 text-indigo-300">
          <DiscordIcon className="h-5 w-5" />
        </span>
        <div className="min-w-0 text-xs">
          <div className="flex items-center gap-1 font-bold">
            <Zap className="h-3 w-3 text-amber-300" /> تنبيه ديسكورد فوري
          </div>
          <div dir="rtl" className="truncate text-gray-400">
            #mods-room · {toast?.title} {toast?.user}
          </div>
        </div>
      </div>
    </div>
  );
}

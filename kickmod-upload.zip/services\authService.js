const crypto = require('crypto');
const { dbAsync } = require('../db/database');

const SESSION_SECRET = process.env.SESSION_SECRET || 'kickmod_super_secure_session_secret_2026_x791';

/**
 * Hash password with salt using PBKDF2/scrypt
 */
function hashPassword(password, salt) {
    return crypto.scryptSync(password, salt, 64).toString('hex');
}

/**
 * Create a cryptographically signed session token
 * Payload: userId:timestamp
 * Signature: HMAC-SHA256(payload, secret)
 */
function createSessionToken(userId) {
    const timestamp = Date.now();
    const payload = `${userId}:${timestamp}`;
    const hmac = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex');
    const full = `${payload}:${hmac}`;
    return Buffer.from(full).toString('base64url');
}

/**
 * Verify signed session token
 * Returns userId or null if invalid / expired (30 days)
 */
function verifySessionToken(token) {
    if (!token || typeof token !== 'string') return null;
    try {
        const decoded = Buffer.from(token, 'base64url').toString('utf8');
        const parts = decoded.split(':');
        if (parts.length !== 3) return null;

        const [userIdStr, timestampStr, signature] = parts;
        const payload = `${userIdStr}:${timestampStr}`;
        const expectedHmac = crypto.createHmac('sha256', SESSION_SECRET).update(payload).digest('hex');

        // Timing-safe comparison
        if (!crypto.timingSafeEqual(Buffer.from(signature), Buffer.from(expectedHmac))) {
            return null;
        }

        // Check expiry (30 days)
        const timestamp = parseInt(timestampStr, 10);
        const MAX_AGE_MS = 30 * 24 * 60 * 60 * 1000;
        if (Date.now() - timestamp > MAX_AGE_MS) {
            return null;
        }

        const userId = parseInt(userIdStr, 10);
        return isNaN(userId) ? null : userId;
    } catch (e) {
        return null;
    }
}

/**
 * Extract token from cookie or Authorization header
 */
function extractToken(req) {
    if (req.cookies && req.cookies.kickmod_token) {
        return req.cookies.kickmod_token;
    }
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
        return authHeader.substring(7).trim();
    }
    return null;
}

/**
 * Middleware: Requires valid authenticated user
 */
async function requireAuth(req, res, next) {
    const token = extractToken(req);
    const userId = verifySessionToken(token);

    if (!userId) {
        return res.status(401).json({
            success: false,
            error: 'جلسة غير صالحة أو منتهية، يرجى تسجيل الدخول للمتابعة.'
        });
    }

    try {
        const user = await dbAsync.get(`
            SELECT id, username, email, discord_id, discord_username, discord_avatar, email_verified, created_at 
            FROM users WHERE id = ?
        `, [userId]);

        if (!user) {
            return res.status(401).json({
                success: false,
                error: 'المستخدم غير موجود بالمنظومة.'
            });
        }

        req.user = user;
        next();
    } catch (err) {
        res.status(500).json({ success: false, error: 'خطأ أثناء التحقق من الجلسة: ' + err.message });
    }
}

/**
 * Middleware: Optional authentication (attaches req.user if present)
 */
async function optionalAuth(req, res, next) {
    const token = extractToken(req);
    const userId = verifySessionToken(token);

    if (userId) {
        try {
            const user = await dbAsync.get(`
                SELECT id, username, email, discord_id, discord_username, discord_avatar, email_verified, created_at 
                FROM users WHERE id = ?
            `, [userId]);
            req.user = user || null;
        } catch (e) {
            req.user = null;
        }
    } else {
        req.user = null;
    }
    next();
}

/**
 * Generate and store a 6-digit OTP for email verification
 */
async function createEmailOTP(email, purpose = 'login', payload = null) {
    const cleanEmail = email.trim().toLowerCase();
    // 6-digit cryptographic code
    const otpCode = crypto.randomInt(100000, 999999).toString();
    const payloadStr = payload ? JSON.stringify(payload) : null;

    // Delete any old pending OTPs for this email and purpose
    await dbAsync.run(`DELETE FROM email_otps WHERE email = ? AND purpose = ?`, [cleanEmail, purpose]);

    // Insert new OTP expiring in 10 minutes
    await dbAsync.run(`
        INSERT INTO email_otps (email, otp_code, purpose, payload, attempts, expires_at)
        VALUES (?, ?, ?, ?, 0, datetime('now', '+10 minutes'))
    `, [cleanEmail, otpCode, purpose, payloadStr]);

    console.log(`\n======================================================`);
    console.log(`📧 [EMAIL OTP - ${purpose.toUpperCase()}] Code for ${cleanEmail}: [ ${otpCode} ]`);
    console.log(`⏱️ Valid for 10 minutes | Max 5 attempts`);
    console.log(`======================================================\n`);

    return otpCode;
}

/**
 * Verify OTP for email with attempt limiting and timing-safe comparison
 */
async function verifyEmailOTP(email, code, purpose = 'login') {
    const cleanEmail = email.trim().toLowerCase();
    const cleanCode = code ? code.toString().trim() : '';

    const record = await dbAsync.get(`
        SELECT id, otp_code, payload, attempts, expires_at 
        FROM email_otps 
        WHERE email = ? AND purpose = ? AND expires_at > datetime('now')
        ORDER BY id DESC LIMIT 1
    `, [cleanEmail, purpose]);

    if (!record) {
        return {
            valid: false,
            error: 'رمز التحقق غير موجود أو انتهت صلاحيته (صالح لـ 10 دقائق فقط).'
        };
    }

    if (record.attempts >= 5) {
        await dbAsync.run(`DELETE FROM email_otps WHERE id = ?`, [record.id]);
        return {
            valid: false,
            error: 'تم تجاوز الحد الأقصى للمحاولات الخاطئة (5 محاولات). تم إلغاء الرمز لحماية حسابك، يرجى طلب رمز جديد.'
        };
    }

    const expectedBuf = Buffer.from(record.otp_code);
    const inputBuf = Buffer.from(cleanCode);

    const isMatch = expectedBuf.length === inputBuf.length && crypto.timingSafeEqual(expectedBuf, inputBuf);

    if (!isMatch) {
        const nextAttempts = record.attempts + 1;
        await dbAsync.run(`UPDATE email_otps SET attempts = ? WHERE id = ?`, [nextAttempts, record.id]);
        const remaining = Math.max(0, 5 - nextAttempts);
        return {
            valid: false,
            remaining,
            error: remaining > 0 
                ? `رمز التحقق غير صحيح. متبقي ${remaining} محاولات.`
                : 'تم تجاوز الحد الأقصى للمحاولات الخاطئة. تم إلغاء الرمز، يرجى طلب رمز جديد.'
        };
    }

    // Success: remove used OTP
    await dbAsync.run(`DELETE FROM email_otps WHERE id = ?`, [record.id]);

    let parsedPayload = null;
    if (record.payload) {
        try {
            parsedPayload = JSON.parse(record.payload);
        } catch (e) {
            parsedPayload = null;
        }
    }

    return {
        valid: true,
        payload: parsedPayload
    };
}

module.exports = {
    hashPassword,
    createSessionToken,
    verifySessionToken,
    extractToken,
    requireAuth,
    optionalAuth,
    createEmailOTP,
    verifyEmailOTP
};


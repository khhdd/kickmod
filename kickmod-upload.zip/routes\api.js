const express = require('express');
const router = express.Router();
const { dbAsync } = require('../db/database');
const kickService = require('../services/kickService');
const { sendTestWebhook, sendStreamReportEmbed } = require('../services/discordService');
const { requireAuth, optionalAuth } = require('../services/authService');

// 1. Get all public channels (or channels for monitoring)
router.get('/channels', async (req, res) => {
    try {
        const channels = await dbAsync.all(`
            SELECT c.*, 
                (SELECT COUNT(*) FROM moderators m WHERE m.channel_id = c.id) as total_mods,
                (SELECT COUNT(*) FROM mod_actions a WHERE a.channel_id = c.id) as total_actions
            FROM channels c
            ORDER BY c.created_at DESC
        `);
        res.json({ success: true, channels });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 1.1 Get current logged-in user's channel
router.get('/channels/my-channel', requireAuth, async (req, res) => {
    try {
        const channel = await dbAsync.get(`
            SELECT c.*, 
                (SELECT COUNT(*) FROM moderators m WHERE m.channel_id = c.id) as total_mods,
                (SELECT COUNT(*) FROM mod_actions a WHERE a.channel_id = c.id) as total_actions,
                (SELECT COUNT(*) FROM moderators m WHERE m.channel_id = c.id AND m.is_online = 1) as online_mods
            FROM channels c
            WHERE c.user_id = ?
            LIMIT 1
        `, [req.user.id]);

        if (!channel) {
            return res.json({ success: true, has_channel: false, channel: null });
        }

        // Get live stream info
        const streamInfo = kickService.channels.get(channel.slug)?.stream || null;

        res.json({
            success: true,
            has_channel: true,
            channel: {
                ...channel,
                is_live: streamInfo?.is_live || false,
                stream_title: streamInfo?.session_title || null,
                viewer_count: streamInfo?.viewer_count || 0
            }
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 2. Add a new channel (Authenticated & Unique Ownership Enforced)
router.post('/channels', requireAuth, async (req, res) => {
    const { slug, discord_webhook } = req.body;
    if (!slug) {
        return res.status(400).json({ success: false, error: 'اسم القناة على كيك مطلوب.' });
    }

    try {
        const cleanSlug = slug.replace(/^https?:\/\/(www\.)?kick\.com\//, '').replace(/[^a-zA-Z0-9_-]/g, '').trim().toLowerCase();
        if (!cleanSlug) {
            return res.status(400).json({ success: false, error: 'معرّف القناة غير صالح.' });
        }

        // 1. Check if this user already owns a registered channel
        const existingUserChannel = await dbAsync.get('SELECT id, slug FROM channels WHERE user_id = ?', [req.user.id]);
        if (existingUserChannel) {
            return res.status(400).json({
                success: false,
                error: `لديك قناة مسجلة بالفعل بحسابك (@${existingUserChannel.slug}). الحساب الواحد مخصص لقناة واحدة.`
            });
        }

        // 2. Check if channel is already claimed by ANY user
        const existing = await dbAsync.get('SELECT id, slug, user_id FROM channels WHERE slug = ?', [cleanSlug]);
        if (existing) {
            return res.status(400).json({
                success: false,
                error: `القناة "@${cleanSlug}" مسجلة بالفعل ومحمية لمالكها! لا يمكن لأي مستخدم آخر إضافتها أو المطالبة بها.`
            });
        }

        // Resolve Kick details
        const details = await kickService.resolveChannel(cleanSlug);

        // Insert into database with ownership tied to req.user.id
        const result = await dbAsync.run(`
            INSERT INTO channels (user_id, slug, name, kick_channel_id, chatroom_id, avatar_url, banner_url, discord_webhook)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        `, [
            req.user.id,
            details.slug,
            details.name,
            details.kick_channel_id,
            details.chatroom_id,
            details.avatar_url,
            details.banner_url || null,
            discord_webhook ? discord_webhook.trim() : null
        ]);

        const newChannel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [result.lastID]);

        // Start real-time monitoring
        await kickService.startMonitoring(newChannel);

        // If webhook provided, send test
        if (discord_webhook) {
            await sendTestWebhook(discord_webhook, newChannel.slug);
        }

        res.status(201).json({
            success: true,
            channel: newChannel,
            message: `تم ربط وحماية قناتك (@${newChannel.slug}) بنجاح! بدأ الرصد اللحظي 24/7.`
        });
    } catch (err) {
        res.status(400).json({ success: false, error: err.message });
    }
});

// 3. Delete a channel (Restricted to Channel Owner)
router.delete('/channels/:id', requireAuth, async (req, res) => {
    try {
        const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [req.params.id]);
        if (!channel) {
            return res.status(404).json({ success: false, error: 'القناة غير موجودة.' });
        }

        // Verify ownership
        if (channel.user_id && channel.user_id !== req.user.id) {
            return res.status(403).json({
                success: false,
                error: 'غير مصرح لك بحذف هذه القناة. فقط مالك القناة المسجل يمكنه إدارتها أو حذفها.'
            });
        }

        kickService.stopMonitoring(channel.slug);
        await dbAsync.run('DELETE FROM channels WHERE id = ?', [req.params.id]);

        res.json({ success: true, message: `تم حذف قناة ${channel.slug} بنجاح.` });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 4. Update Discord Webhook (Restricted to Channel Owner)
router.patch('/channels/:id/webhook', requireAuth, async (req, res) => {
    const { discord_webhook } = req.body;
    try {
        const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [req.params.id]);
        if (!channel) {
            return res.status(404).json({ success: false, error: 'القناة غير موجودة.' });
        }

        // Verify ownership
        if (channel.user_id && channel.user_id !== req.user.id) {
            return res.status(403).json({
                success: false,
                error: 'غير مصرح لك بتعديل ويب هوك هذه القناة.'
            });
        }

        await dbAsync.run('UPDATE channels SET discord_webhook = ? WHERE id = ?', [discord_webhook ? discord_webhook.trim() : null, req.params.id]);

        let webhookValid = false;
        if (discord_webhook) {
            webhookValid = await sendTestWebhook(discord_webhook, channel.slug);
        }

        res.json({ success: true, message: 'تم تحديث رابط ويب هوك ديسكورد بنجاح.', webhookValid });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 5. Channel Overview Statistics (Per-Live & All-Time Stats)
router.get('/channels/:id/overview', async (req, res) => {
    const channelId = req.params.id;
    try {
        const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [channelId]);
        if (!channel) {
            return res.status(404).json({ success: false, error: 'Channel not found' });
        }

        // Active Live Stream Session
        const currentStream = await dbAsync.get(
            'SELECT * FROM stream_reports WHERE channel_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1',
            [channelId]
        );

        // All-Time Cumulative Stats
        const allTimeCounts = await dbAsync.get(`
            SELECT 
                (SELECT COUNT(*) FROM moderators WHERE channel_id = ?) as total_moderators,
                (SELECT COUNT(*) FROM mod_actions WHERE channel_id = ? AND action_type = 'ban') as total_bans,
                (SELECT COUNT(*) FROM mod_actions WHERE channel_id = ? AND action_type = 'timeout') as total_timeouts,
                (SELECT COUNT(*) FROM mod_actions WHERE channel_id = ? AND DATE(created_at) = CURRENT_DATE) as actions_today,
                (SELECT COUNT(*) FROM moderators WHERE channel_id = ? AND DATE(last_seen) = CURRENT_DATE) as active_mods_today,
                (SELECT COUNT(*) FROM moderators WHERE channel_id = ? AND is_online = 1) as online_mods_count,
                (SELECT COALESCE(SUM(messages_count), 0) FROM mod_sessions WHERE channel_id = ?) as total_mod_messages,
                (SELECT COUNT(*) FROM stream_reports WHERE channel_id = ?) as total_streams
        `, [channelId, channelId, channelId, channelId, channelId, channelId, channelId, channelId]);

        // Live messages in current stream
        const liveMsgsRow = await dbAsync.get(`
            SELECT COALESCE(SUM(total_messages), 0) as msgs FROM moderators WHERE channel_id = ?
        `, [channelId]);

        // Per-Live Stats (Current Stream)
        let liveStats = {
            is_active: false,
            bans: 0,
            timeouts: 0,
            active_mods: allTimeCounts.online_mods_count || 0,
            messages: liveMsgsRow?.msgs || 0,
            duration_minutes: 0,
            started_at: null
        };

        if (currentStream) {
            const liveActions = await dbAsync.get(`
                SELECT 
                    COUNT(CASE WHEN action_type = 'ban' THEN 1 END) as bans,
                    COUNT(CASE WHEN action_type = 'timeout' THEN 1 END) as timeouts
                FROM mod_actions 
                WHERE channel_id = ? AND (stream_report_id = ? OR created_at >= ?)
            `, [channelId, currentStream.id, currentStream.started_at]);

            const startTime = new Date(currentStream.started_at.replace(' ', 'T') + (currentStream.started_at.includes('Z') ? '' : 'Z'));
            const durationMin = Math.max(1, Math.round((Date.now() - startTime.getTime()) / (1000 * 60)));

            liveStats = {
                is_active: true,
                stream_id: currentStream.id,
                title: currentStream.title,
                started_at: currentStream.started_at,
                duration_minutes: durationMin,
                bans: liveActions?.bans || currentStream.total_bans || 0,
                timeouts: liveActions?.timeouts || currentStream.total_timeouts || 0,
                active_mods: allTimeCounts.online_mods_count || 1,
                messages: liveMsgsRow?.msgs || 0
            };
        }

        // Monthly Stats (الشهر كله / آخر 30 يوم)
        const monthCounts = await dbAsync.get(`
            SELECT 
                COUNT(CASE WHEN action_type = 'ban' THEN 1 END) as bans,
                COUNT(CASE WHEN action_type = 'timeout' THEN 1 END) as timeouts,
                COUNT(DISTINCT moderator_username) as active_mods
            FROM mod_actions
            WHERE channel_id = ? AND created_at >= DATE('now', '-30 days')
        `, [channelId]);

        const monthMessages = await dbAsync.get(`
            SELECT COALESCE(SUM(messages_count), 0) as messages
            FROM mod_sessions
            WHERE channel_id = ? AND session_date >= DATE('now', '-30 days')
        `, [channelId]);

        const monthStreams = await dbAsync.get(`
            SELECT COUNT(*) as streams
            FROM stream_reports
            WHERE channel_id = ? AND started_at >= DATE('now', '-30 days')
        `, [channelId]);

        const monthStats = {
            bans: Math.max(liveStats.bans, monthCounts?.bans || 0),
            timeouts: Math.max(liveStats.timeouts, monthCounts?.timeouts || 0),
            active_mods: Math.max(liveStats.active_mods, monthCounts?.active_mods || 0),
            messages: Math.max(liveStats.messages, monthMessages?.messages || 0),
            streams: monthStreams?.streams || 0
        };

        // Guarantee all-time >= month >= live
        allTimeCounts.total_bans = Math.max(allTimeCounts.total_bans, monthStats.bans);
        allTimeCounts.total_timeouts = Math.max(allTimeCounts.total_timeouts, monthStats.timeouts);
        allTimeCounts.total_mod_messages = Math.max(allTimeCounts.total_mod_messages, monthStats.messages);

        // Recent 7 days activity breakdown
        const dailyActivity = await dbAsync.all(`
            SELECT 
                DATE(created_at) as date,
                SUM(CASE WHEN action_type = 'ban' THEN 1 ELSE 0 END) as bans,
                SUM(CASE WHEN action_type = 'timeout' THEN 1 ELSE 0 END) as timeouts,
                COUNT(*) as total_actions
            FROM mod_actions
            WHERE channel_id = ? AND created_at >= DATE('now', '-7 days')
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        `, [channelId]);

        res.json({
            success: true,
            channel,
            stats: allTimeCounts,
            all_time: allTimeCounts,
            live_stats: liveStats,
            month_stats: monthStats,
            dailyActivity
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 5.b. Reset Channel Live Statistics (زر تصفير الإحصائيات)
router.post('/channels/:id/reset-stats', requireAuth, async (req, res) => {
    const channelId = req.params.id;
    try {
        const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [channelId]);
        if (!channel) {
            return res.status(404).json({ success: false, error: 'القناة غير موجودة.' });
        }

        if (channel.user_id && channel.user_id !== req.user.id) {
            return res.status(403).json({ success: false, error: 'غير مصرح لك بتصفير إحصائيات هذه القناة. الصلاحية لمالك القناة فقط.' });
        }

        // 1. Archive current stream report
        const currentReport = await dbAsync.get(
            'SELECT id FROM stream_reports WHERE channel_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1',
            [channelId]
        );
        if (currentReport) {
            await dbAsync.run(
                'UPDATE stream_reports SET ended_at = CURRENT_TIMESTAMP WHERE id = ?',
                [currentReport.id]
            );
        }

        // 2. Close active attendance sessions
        await dbAsync.run(
            'UPDATE mod_attendance_sessions SET ended_at = CURRENT_TIMESTAMP WHERE channel_id = ? AND ended_at IS NULL',
            [channelId]
        );

        // 3. Reset live counters for moderators (preserve identities and usernames)
        await dbAsync.run(`
            UPDATE moderators 
            SET total_messages = 0, total_bans = 0, total_timeouts = 0, total_deleted = 0, total_active_seconds = 0
            WHERE channel_id = ?
        `, [channelId]);

        // 4. Start fresh stream report
        const newReport = await dbAsync.run(`
            INSERT INTO stream_reports (channel_id, title, category, started_at, active_mods_count)
            VALUES (?, ?, 'Kick Live', CURRENT_TIMESTAMP, 0)
        `, [channelId, `بث مباشر جديد لقناة ${channel.slug}`]);

        // 5. Emit socket event for instant real-time update
        const io = kickService.io;
        if (io) {
            io.emit('stats_reset', {
                channel_id: channel.id,
                channel_slug: channel.slug,
                new_report_id: newReport.lastID,
                timestamp: new Date().toISOString()
            });
        }

        res.json({
            success: true,
            message: 'تم تصفير وإعادة تعيين إحصائيات البث بنجاح، وبدء جلسة رصد جديدة الآن!'
        });
    } catch (err) {
        res.status(500).json({ success: false, error: 'حدث خطأ أثناء تصفير الإحصائيات: ' + err.message });
    }
});

// 6. Moderators Leaderboard (Live vs Month vs All-Time scope supported)
router.get('/channels/:id/leaderboard', async (req, res) => {
    const channelId = req.params.id;
    const scope = (req.query.scope || 'live').toLowerCase(); // 'live', 'month', 'all'

    try {
        const activeReport = await dbAsync.get(
            'SELECT id, started_at FROM stream_reports WHERE channel_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1',
            [channelId]
        );

        const allMods = await dbAsync.all('SELECT * FROM moderators WHERE channel_id = ?', [channelId]);

        // Preload all actions for accurate dynamic counts
        const allActions = await dbAsync.all(`
            SELECT LOWER(moderator_username) as mod_name, action_type, stream_report_id, created_at
            FROM mod_actions
            WHERE channel_id = ?
        `, [channelId]);

        // Preload all attendance sessions
        const allSessions = await dbAsync.all(`
            SELECT LOWER(moderator_username) as mod_name, duration_seconds, stream_report_id, started_at
            FROM mod_attendance_sessions
            WHERE channel_id = ?
        `, [channelId]);

        // Preload all-time messages per moderator from mod_sessions
        const allSessionRows = await dbAsync.all(`
            SELECT LOWER(moderator_username) as mod_name, SUM(messages_count) as messages
            FROM mod_sessions
            WHERE channel_id = ?
            GROUP BY LOWER(moderator_username)
        `, [channelId]);
        const allMessagesMap = new Map();
        allSessionRows.forEach(r => allMessagesMap.set(r.mod_name, r.messages));

        // Preload monthly messages per moderator (last 30 days)
        const monthSessionRows = await dbAsync.all(`
            SELECT LOWER(moderator_username) as mod_name, SUM(messages_count) as messages
            FROM mod_sessions
            WHERE channel_id = ? AND session_date >= DATE('now', '-30 days')
            GROUP BY LOWER(moderator_username)
        `, [channelId]);
        const monthMessagesMap = new Map();
        monthSessionRows.forEach(r => monthMessagesMap.set(r.mod_name, r.messages));

        // Threshold for last 30 days
        const thirtyDaysAgo = new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString();

        const moderators = allMods.map(m => {
            const mName = m.username.toLowerCase();

            // Actions for this mod
            const modActs = allActions.filter(a => a.mod_name === mName);
            const liveActs = activeReport
                ? modActs.filter(a => a.stream_report_id === activeReport.id || a.created_at >= activeReport.started_at)
                : modActs;
            const monthActs = modActs.filter(a => a.created_at >= thirtyDaysAgo);

            // Attendance for this mod
            const modSess = allSessions.filter(s => s.mod_name === mName);
            const liveSess = activeReport
                ? modSess.filter(s => s.stream_report_id === activeReport.id || s.started_at >= activeReport.started_at)
                : modSess;
            const monthSess = modSess.filter(s => s.started_at >= thirtyDaysAgo);

            // 1. Live stream counts (اللايف الواحد)
            const liveBans = liveActs.filter(a => a.action_type === 'ban').length;
            const liveTimeouts = liveActs.filter(a => a.action_type === 'timeout').length;
            const liveSecs = liveSess.reduce((acc, cur) => acc + (cur.duration_seconds || 0), 0);
            const liveMessages = m.total_messages || 0;
            const liveScore = liveBans * 5 + liveTimeouts * 3 + liveMessages;

            // 2. Month counts (الشهر كله - آخر 30 يوم) - Guaranteed >= Live
            const rawMonthMsgs = monthMessagesMap.get(mName) || 0;
            const monthBans = Math.max(liveBans, monthActs.filter(a => a.action_type === 'ban').length);
            const monthTimeouts = Math.max(liveTimeouts, monthActs.filter(a => a.action_type === 'timeout').length);
            const monthSecs = Math.max(liveSecs, monthSess.reduce((acc, cur) => acc + (cur.duration_seconds || 0), 0));
            const monthMessages = Math.max(liveMessages, rawMonthMsgs);
            const monthScore = monthBans * 5 + monthTimeouts * 3 + monthMessages;

            // 3. All-time counts (الوقت كله - التاريخ الكامل) - Guaranteed >= Month
            const rawAllMsgs = allMessagesMap.get(mName) || 0;
            const rawAllBans = modActs.filter(a => a.action_type === 'ban').length;
            const rawAllTimeouts = modActs.filter(a => a.action_type === 'timeout').length;
            const rawAllSecs = modSess.reduce((acc, cur) => acc + (cur.duration_seconds || 0), 0);

            const allBans = Math.max(monthBans, rawAllBans);
            const allTimeouts = Math.max(monthTimeouts, rawAllTimeouts);
            const allSecs = Math.max(monthSecs, rawAllSecs);
            const allMessages = Math.max(monthMessages, rawAllMsgs, m.total_messages || 0);
            const allScore = allBans * 5 + allTimeouts * 3 + allMessages;

            // Active counts based on requested scope
            let bans = allBans;
            let timeouts = allTimeouts;
            let activeSecs = allSecs;
            let messages = allMessages;
            let score = allScore;

            if (scope === 'live') {
                bans = liveBans;
                timeouts = liveTimeouts;
                activeSecs = liveSecs;
                messages = liveMessages;
                score = liveScore;
            } else if (scope === 'month') {
                bans = monthBans;
                timeouts = monthTimeouts;
                activeSecs = monthSecs;
                messages = monthMessages;
                score = monthScore;
            }

            return {
                ...m,
                total_bans: bans,
                total_timeouts: timeouts,
                total_active_seconds: activeSecs,
                total_messages: messages,
                activity_score: score,
                live_bans: liveBans,
                live_timeouts: liveTimeouts,
                live_active_seconds: liveSecs,
                live_messages: liveMessages,
                live_score: liveScore,
                month_bans: monthBans,
                month_timeouts: monthTimeouts,
                month_active_seconds: monthSecs,
                month_messages: monthMessages,
                month_score: monthScore,
                all_bans: allBans,
                all_timeouts: allTimeouts,
                all_active_seconds: allSecs,
                all_messages: allMessages,
                all_score: allScore
            };
        });

        // Sort by activity score descending, then attendance descending
        moderators.sort((a, b) => b.activity_score - a.activity_score || b.total_active_seconds - a.total_active_seconds);

        res.json({ success: true, scope, is_live_active: !!activeReport, moderators });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 7. Mod Actions Audit Log
router.get('/channels/:id/actions', async (req, res) => {
    const channelId = req.params.id;
    const limit = parseInt(req.query.limit) || 50;
    const offset = parseInt(req.query.offset) || 0;
    const type = req.query.type; // filter by ban/timeout

    try {
        let sql = 'SELECT * FROM mod_actions WHERE channel_id = ?';
        const params = [channelId];

        if (type && type !== 'all') {
            sql += ' AND action_type = ?';
            params.push(type);
        }

        sql += ' ORDER BY created_at DESC LIMIT ? OFFSET ?';
        params.push(limit, offset);

        const actions = await dbAsync.all(sql, params);
        res.json({ success: true, actions });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 8. Individual Moderator Profile & Action History
router.get('/channels/:id/moderator/:username', async (req, res) => {
    const { id: channelId, username } = req.params;
    try {
        const moderator = await dbAsync.get(`
            SELECT * FROM moderators WHERE channel_id = ? AND username = ?
        `, [channelId, username]);

        if (!moderator) {
            return res.status(404).json({ success: false, error: 'Moderator not found' });
        }

        const actions = await dbAsync.all(`
            SELECT * FROM mod_actions 
            WHERE channel_id = ? AND moderator_username = ?
            ORDER BY created_at DESC LIMIT 50
        `, [channelId, username]);

        const sessions = await dbAsync.all(`
            SELECT * FROM mod_sessions
            WHERE channel_id = ? AND moderator_username = ?
            ORDER BY session_date DESC LIMIT 14
        `, [channelId, username]);

        const attendance = await dbAsync.all(`
            SELECT * FROM mod_attendance_sessions
            WHERE channel_id = ? AND moderator_username = ?
            ORDER BY id DESC LIMIT 10
        `, [channelId, username]);

        res.json({ success: true, moderator, actions, sessions, attendance });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 9. Export Audit Log (CSV or JSON)
router.get('/channels/:id/export', async (req, res) => {
    const channelId = req.params.id;
    const format = req.query.format || 'json';

    try {
        const channel = await dbAsync.get('SELECT slug FROM channels WHERE id = ?', [channelId]);
        const actions = await dbAsync.all(`
            SELECT id, moderator_username, action_type, target_username, duration_seconds, reason, created_at
            FROM mod_actions
            WHERE channel_id = ?
            ORDER BY created_at DESC
        `, [channelId]);

        if (format === 'csv') {
            let csv = 'ID,Moderator,Action,Target User,Duration (s),Reason,Date\n';
            actions.forEach(a => {
                csv += `"${a.id}","${a.moderator_username}","${a.action_type}","${a.target_username || ''}","${a.duration_seconds}","${a.reason || ''}","${a.created_at}"\n`;
            });
            res.header('Content-Type', 'text/csv');
            res.attachment(`kickmod_${channel ? channel.slug : 'channel'}_audit.csv`);
            return res.send(csv);
        }

        res.json({ success: true, actions });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 10. Simulate Test Action (for live testing)
router.post('/channels/:id/simulate', async (req, res) => {
    const channelId = req.params.id;
    const { action_type = 'timeout', moderator = 'SuperMod', target_user = 'TrollUser', duration = 300 } = req.body;

    try {
        const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [channelId]);
        if (!channel) {
            return res.status(404).json({ success: false, error: 'Channel not found' });
        }

        // Trigger kickService logic directly to update DB, emit socket, and send Discord webhook
        await kickService.handleUserBanned(channel, {
            user: { username: target_user, id: 999 },
            banned_by: { username: moderator, id: 111 },
            expires_at: action_type === 'timeout' ? new Date(Date.now() + duration * 1000).toISOString() : null
        });

        res.json({ success: true, message: `Simulated ${action_type} sent successfully!` });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 11. Best Moderators Showcase (أفضل المشرفين)
router.get('/channels/:id/best-mods', async (req, res) => {
    const channelId = req.params.id;
    try {
        // MVP: Highest Score
        const mvp = await dbAsync.get(`
            SELECT *, (total_bans * 5 + total_timeouts * 3 + total_messages) as activity_score
            FROM moderators
            WHERE channel_id = ? AND is_bot = 0
            ORDER BY activity_score DESC, total_active_seconds DESC LIMIT 1
        `, [channelId]);

        // Enforcer: Most Bans + Timeouts
        const enforcer = await dbAsync.get(`
            SELECT *
            FROM moderators
            WHERE channel_id = ? AND is_bot = 0 AND (total_bans + total_timeouts) > 0
            ORDER BY (total_bans + total_timeouts) DESC LIMIT 1
        `, [channelId]);

        // Chatter: Most Messages
        const chatter = await dbAsync.get(`
            SELECT *
            FROM moderators
            WHERE channel_id = ? AND is_bot = 0
            ORDER BY total_messages DESC LIMIT 1
        `, [channelId]);

        // Inactive Mods: 0 messages or inactive
        const inactiveCount = await dbAsync.get(`
            SELECT COUNT(*) as count FROM moderators
            WHERE channel_id = ? AND is_bot = 0 AND total_messages = 0 AND (total_bans + total_timeouts) = 0
        `, [channelId]);

        res.json({
            success: true,
            mvp: mvp || null,
            enforcer: enforcer || null,
            chatter: chatter || null,
            inactive_count: inactiveCount?.count || 0
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 12. Stream Reports History (تقارير البثوث)
router.get('/channels/:id/stream-reports', async (req, res) => {
    const channelId = req.params.id;
    try {
        const reports = await dbAsync.all(`
            SELECT * FROM stream_reports
            WHERE channel_id = ?
            ORDER BY started_at DESC LIMIT 20
        `, [channelId]);
        res.json({ success: true, reports });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// Helper to compute deep stream analytics
async function computeStreamAnalytics(reportId, channelId) {
    const report = await dbAsync.get('SELECT * FROM stream_reports WHERE id = ? AND channel_id = ?', [reportId, channelId]);
    if (!report) return null;

    const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [channelId]);
    const allMods = await dbAsync.all('SELECT * FROM moderators WHERE channel_id = ? ORDER BY is_online DESC, total_active_seconds DESC', [channelId]);

    const startedDate = new Date(report.started_at.replace(' ', 'T') + (report.started_at.includes('Z') ? '' : 'Z'));
    const endedDate = report.ended_at 
        ? new Date(report.ended_at.replace(' ', 'T') + (report.ended_at.includes('Z') ? '' : 'Z'))
        : new Date();

    const streamDurationSec = Math.max(60, Math.round((endedDate.getTime() - startedDate.getTime()) / 1000));
    const streamDurationMin = Math.round(streamDurationSec / 60);

    // Fetch actions performed during stream window (by stream_report_id or by time window)
    const actions = await dbAsync.all(`
        SELECT moderator_username, action_type, COUNT(*) as count
        FROM mod_actions
        WHERE channel_id = ? AND (stream_report_id = ? OR (created_at >= ? AND created_at <= ?))
        GROUP BY moderator_username, action_type
    `, [channelId, report.id, report.started_at, report.ended_at || new Date().toISOString()]);

    // Action counts mapping
    const modActionMap = {};
    let totalBans = 0;
    let totalTimeouts = 0;

    actions.forEach(a => {
        if (!modActionMap[a.moderator_username]) {
            modActionMap[a.moderator_username] = { bans: 0, timeouts: 0 };
        }
        if (a.action_type === 'ban') {
            modActionMap[a.moderator_username].bans += a.count;
            totalBans += a.count;
        } else if (a.action_type === 'timeout') {
            modActionMap[a.moderator_username].timeouts += a.count;
            totalTimeouts += a.count;
        }
    });

    // Attendance sessions during stream window (matched by stream_report_id or active/overlapping sessions)
    const sessions = await dbAsync.all(`
        SELECT moderator_username, SUM(duration_seconds) as total_seconds
        FROM mod_attendance_sessions
        WHERE channel_id = ? AND (stream_report_id = ? OR ended_at IS NULL OR started_at >= ? OR ended_at >= ?)
        GROUP BY moderator_username
    `, [channelId, report.id, report.started_at, report.started_at]);

    const attendanceMap = {};
    sessions.forEach(s => {
        attendanceMap[s.moderator_username] = s.total_seconds || 0;
    });

    // Build moderator statistics matrix
    let attendedModsCount = 0;
    const isLiveStream = !report.ended_at;

    const moderatorStats = allMods.map(m => {
        let activeSec = attendanceMap[m.username] || 0;

        // If this is the active live stream, consider their live tracked total_active_seconds
        if (isLiveStream && m.total_active_seconds > 0) {
            activeSec = Math.max(activeSec, Math.min(streamDurationSec, m.total_active_seconds));
        }

        const acts = modActionMap[m.username] || { bans: 0, timeouts: 0 };

        // If moderator performed bans/timeouts or sent messages during this stream, they were definitely present!
        if (acts.bans > 0 || acts.timeouts > 0 || m.total_messages > 0) {
            if (activeSec === 0) {
                activeSec = Math.min(streamDurationSec, Math.max(120, (m.total_messages || 1) * 30));
            }
        }

        // If currently online, ensure presence representation
        if (m.is_online && activeSec === 0) {
            activeSec = Math.min(streamDurationSec, Math.max(m.total_active_seconds || 0, 180));
        }

        const presencePercent = Math.min(100, Math.round((activeSec / Math.max(1, streamDurationSec)) * 100));
        const score = (acts.bans * 10) + (acts.timeouts * 5) + Math.round(activeSec / 60) + (m.total_messages || 0);

        if (activeSec > 0 || m.is_online || acts.bans > 0 || acts.timeouts > 0) {
            attendedModsCount++;
        }

        let status = 'absent';
        let statusLabel = 'غائب';
        if (m.is_online || presencePercent >= 50) {
            status = 'active';
            statusLabel = 'حاضر';
        } else if (activeSec > 0 || presencePercent > 0 || acts.bans > 0 || acts.timeouts > 0) {
            status = 'partial';
            statusLabel = 'حضور جزئي';
        }

        return {
            username: m.username,
            avatar_url: m.avatar_url,
            is_bot: m.is_bot,
            is_online: m.is_online,
            active_seconds: activeSec,
            presence_percent: presencePercent,
            bans: acts.bans,
            timeouts: acts.timeouts,
            total_actions: acts.bans + acts.timeouts,
            score,
            status,
            statusLabel
        };
    });

    // Sort by score and active seconds
    moderatorStats.sort((a, b) => b.score - a.score || b.active_seconds - a.active_seconds);

    // Identify MVP and badges
    let mvp = null;
    if (moderatorStats.length > 0 && (moderatorStats[0].active_seconds > 0 || moderatorStats[0].total_actions > 0)) {
        mvp = moderatorStats[0];
        moderatorStats[0].badge = 'نجم البث (MVP)';
    }

    const totalMods = allMods.length || 1;
    const attendanceRate = Math.round((attendedModsCount / totalMods) * 100);
    const absentMods = moderatorStats.filter(m => m.status === 'absent' && !m.is_bot);

    // Smart Arabic Insights
    let teamRating = 'ممتاز';
    let teamRatingColor = 'text-[#53fc18]';
    if (attendanceRate < 40) {
        teamRating = 'بحاجة لمتابعة';
        teamRatingColor = 'text-amber-400';
    } else if (attendanceRate < 70) {
        teamRating = 'جيد جداً';
        teamRatingColor = 'text-blue-400';
    }

    const insights = [
        `نسبة التزام الطاقم بالحضور: ${attendanceRate}% (${attendedModsCount} من أصل ${totalMods} مشرفين).`,
        `إجمالي إجراءات الحظر والكتم: ${totalBans} حظر دائم و ${totalTimeouts} كتم مؤقت.`,
        mvp ? `نجم البث الأكثر كفاءة هو @${mvp.username} بنتيجة نشاط ${mvp.score} نقطة.` : 'لا يوجد نشاط مسجل للمشرفين حتى الآن.',
        absentMods.length > 0
            ? `المشرفون المتغيبون: (${absentMods.map(a => a.username).slice(0, 5).join('، ')}). يُنصح بالتواصل معهم لتأكيد جاهزيتهم.`
            : 'تغطية متكاملة! جميع المشرفين سجلوا حضوراً نشطاً أثناء هذا البث.'
    ];

    return {
        report: {
            id: report.id,
            title: report.title || `بث مباشر قناة ${channel?.slug || ''}`,
            category: report.category || 'Kick Live',
            started_at: report.started_at,
            ended_at: report.ended_at,
            is_live: !report.ended_at,
            duration_minutes: streamDurationMin,
            duration_seconds: streamDurationSec
        },
        summary: {
            channel_slug: channel?.slug,
            duration_formatted: `${Math.floor(streamDurationMin / 60)} ساعة و ${streamDurationMin % 60} دقيقة`,
            attendance_rate: attendanceRate,
            active_mods_count: attendedModsCount,
            total_mods_count: totalMods,
            total_bans: totalBans,
            total_timeouts: totalTimeouts,
            total_actions: totalBans + totalTimeouts,
            team_rating: teamRating,
            team_rating_color: teamRatingColor,
            mvp_name: mvp?.username || null
        },
        insights,
        moderators: moderatorStats
    };
}

// 12.1 Detailed Stream Analytics Report
router.get('/channels/:id/stream-reports/:reportId/analytics', async (req, res) => {
    const { id: channelId, reportId } = req.params;
    try {
        const analytics = await computeStreamAnalytics(reportId, channelId);
        if (!analytics) {
            return res.status(404).json({ success: false, error: 'Report not found' });
        }
        res.json({ success: true, analytics });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 12.2 Generate Current / Instant Stream Analytics Report
router.post('/channels/:id/stream-reports/generate-current', async (req, res) => {
    const channelId = req.params.id;
    try {
        const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [channelId]);
        if (!channel) return res.status(404).json({ success: false, error: 'Channel not found' });

        // Check if there is an active report
        let report = await dbAsync.get(
            'SELECT * FROM stream_reports WHERE channel_id = ? AND ended_at IS NULL ORDER BY id DESC LIMIT 1',
            [channelId]
        );

        if (!report) {
            // Find most recent report or create a new live report
            report = await dbAsync.get(
                'SELECT * FROM stream_reports WHERE channel_id = ? ORDER BY id DESC LIMIT 1',
                [channelId]
            );

            if (!report) {
                const insertRes = await dbAsync.run(`
                    INSERT INTO stream_reports (channel_id, title, category, started_at, active_mods_count)
                    VALUES (?, ?, ?, CURRENT_TIMESTAMP, 1)
                `, [channelId, `بث مباشر قناة ${channel.slug}`, 'Kick Live']);
                report = await dbAsync.get('SELECT * FROM stream_reports WHERE id = ?', [insertRes.lastID]);
            }
        }

        const analytics = await computeStreamAnalytics(report.id, channelId);
        res.json({ success: true, analytics });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 12.3 Send Stream Report Analytics to Discord
router.post('/channels/:id/stream-reports/:reportId/send-discord', async (req, res) => {
    const { id: channelId, reportId } = req.params;
    try {
        const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [channelId]);
        if (!channel || !channel.discord_webhook_url) {
            return res.status(400).json({ success: false, error: 'لا يوجد رابط ديسكورد ويب هوك مفعل لهذه القناة.' });
        }

        const analytics = await computeStreamAnalytics(reportId, channelId);
        if (!analytics) {
            return res.status(404).json({ success: false, error: 'التقرير غير موجود.' });
        }

        const sent = await sendStreamReportEmbed(channel.discord_webhook_url, {
            channelName: channel.slug,
            title: analytics.report.title,
            durationMinutes: analytics.report.duration_minutes,
            attendanceRate: analytics.summary.attendance_rate,
            activeModsCount: analytics.summary.active_mods_count,
            totalModsCount: analytics.summary.total_mods_count,
            totalBans: analytics.summary.total_bans,
            totalTimeouts: analytics.summary.total_timeouts,
            mvpName: analytics.summary.mvp_name,
            summaryText: analytics.insights.join('\n')
        });

        if (sent) {
            res.json({ success: true, message: 'تم إرسال التقرير التحليلي لقناة الديسكورد بنجاح!' });
        } else {
            res.status(500).json({ success: false, error: 'تعذر إرسال التقرير لديسكورد، يرجى فحص صلاحيات الويب هوك.' });
        }
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 13. Force Resync Channel Data & Active Chatters
router.post('/channels/:id/resync', async (req, res) => {
    const channelId = req.params.id;
    try {
        const channel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [channelId]);
        if (!channel) {
            return res.status(404).json({ success: false, error: 'Channel not found' });
        }

        // Re-resolve channel details to update avatar & banner if changed
        const details = await kickService.resolveChannel(channel.slug);
        await dbAsync.run(`
            UPDATE channels 
            SET kick_channel_id = ?, chatroom_id = ?, avatar_url = ?, banner_url = ?
            WHERE id = ?
        `, [details.kick_channel_id, details.chatroom_id, details.avatar_url, details.banner_url || null, channelId]);

        // Sync active chatters
        const updatedChannel = await dbAsync.get('SELECT * FROM channels WHERE id = ?', [channelId]);
        await kickService.syncActiveChatters(updatedChannel);

        res.json({ success: true, message: 'Channel resynced successfully!', channel: updatedChannel });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 14. Weekly Analytics & Deep Insights (التحليلات الأسبوعية)
router.get('/channels/:id/weekly-analytics', async (req, res) => {
    const channelId = req.params.id;
    try {
        // Daily activity for last 7 days
        const daily = await dbAsync.all(`
            SELECT 
                DATE(created_at) as date,
                strftime('%w', created_at) as day_of_week,
                SUM(CASE WHEN action_type = 'ban' THEN 1 ELSE 0 END) as bans,
                SUM(CASE WHEN action_type = 'timeout' THEN 1 ELSE 0 END) as timeouts,
                COUNT(*) as total_actions
            FROM mod_actions
            WHERE channel_id = ? AND created_at >= DATE('now', '-7 days')
            GROUP BY DATE(created_at)
            ORDER BY date ASC
        `, [channelId]);

        // Peak hours distribution (0 to 23)
        const hourly = await dbAsync.all(`
            SELECT 
                CAST(strftime('%H', created_at) AS INTEGER) as hour,
                COUNT(*) as count
            FROM mod_actions
            WHERE channel_id = ? AND created_at >= DATE('now', '-7 days')
            GROUP BY hour
            ORDER BY hour ASC
        `, [channelId]);

        // Weekly totals
        const weeklyTotals = await dbAsync.get(`
            SELECT 
                COUNT(*) as total_actions,
                COUNT(CASE WHEN action_type = 'ban' THEN 1 END) as bans,
                COUNT(CASE WHEN action_type = 'timeout' THEN 1 END) as timeouts,
                COUNT(DISTINCT moderator_username) as active_mods_count
            FROM mod_actions
            WHERE channel_id = ? AND created_at >= DATE('now', '-7 days')
        `, [channelId]);

        res.json({
            success: true,
            daily,
            hourly,
            totals: weeklyTotals || { total_actions: 0, bans: 0, timeouts: 0, active_mods_count: 0 }
        });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

// 15. Global Network Stats (for Public Landing Page)
router.get('/network/stats', async (req, res) => {
    try {
        const stats = await dbAsync.get(`
            SELECT 
                (SELECT COUNT(*) FROM channels) as total_channels,
                (SELECT COUNT(*) FROM moderators WHERE is_bot = 0) as total_human_mods,
                (SELECT COUNT(*) FROM mod_actions) as total_actions_recorded,
                (SELECT COUNT(*) FROM moderators WHERE is_online = 1) as currently_online_mods
        `);
        res.json({ success: true, stats });
    } catch (err) {
        res.status(500).json({ success: false, error: err.message });
    }
});

module.exports = router;


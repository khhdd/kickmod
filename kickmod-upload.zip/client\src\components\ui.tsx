import { useEffect, useRef, useState, type ReactNode, type MouseEvent } from "react";

export function useInView<T extends HTMLElement>(threshold = 0.15) {
  const ref = useRef<T>(null);
  const [seen, setSeen] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(
      ([e]) => {
        if (e.isIntersecting) {
          setSeen(true);
          io.disconnect();
        }
      },
      { threshold }
    );
    io.observe(el);
    return () => io.disconnect();
  }, [threshold]);
  return [ref, seen] as const;
}

export function Reveal({
  children,
  delay = 0,
  className = "",
}: {
  children: ReactNode;
  delay?: number;
  className?: string;
}) {
  const [ref, seen] = useInView<HTMLDivElement>();
  return (
    <div
      ref={ref}
      style={{ transitionDelay: `${delay}ms` }}
      className={`reveal ${seen ? "in" : ""} ${className}`}
    >
      {children}
    </div>
  );
}

export function SpotCard({
  children,
  className = "",
}: {
  children: ReactNode;
  className?: string;
}) {
  const onMove = (e: MouseEvent<HTMLDivElement>) => {
    const r = e.currentTarget.getBoundingClientRect();
    e.currentTarget.style.setProperty("--mx", `${e.clientX - r.left}px`);
    e.currentTarget.style.setProperty("--my", `${e.clientY - r.top}px`);
  };
  return (
    <div onMouseMove={onMove} className={`spot glass rounded-3xl ${className}`}>
      {children}
    </div>
  );
}

export function SectionTitle({
  badge,
  title,
  accent,
  desc,
}: {
  badge: string;
  title: string;
  accent: string;
  desc?: string;
}) {
  return (
    <Reveal className="mx-auto mb-14 max-w-2xl text-center">
      <span className="mb-4 inline-block rounded-full border border-kick/30 bg-kick/10 px-4 py-1 text-xs font-bold text-kick">
        {badge}
      </span>
      <h2 className="text-3xl font-black leading-snug md:text-5xl">
        {title} <span className="text-gradient">{accent}</span>
      </h2>
      {desc && <p className="mt-4 leading-8 text-gray-400">{desc}</p>}
    </Reveal>
  );
}

export function PingDot({ className = "bg-kick" }: { className?: string }) {
  return (
    <span className="relative flex h-2.5 w-2.5">
      <span className={`absolute inset-0 rounded-full ${className}`} style={{ animation: "ping-ring 1.8s ease-out infinite" }} />
      <span className={`relative h-2.5 w-2.5 rounded-full ${className}`} />
    </span>
  );
}

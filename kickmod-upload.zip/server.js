require('dotenv').config();
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const cookieParser = require('cookie-parser');

const { db } = require('./db/database');
const kickService = require('./services/kickService');
const apiRoutes = require('./routes/api');
const authRoutes = require('./routes/auth');

const app = express();
const server = http.createServer(app);

// Security Hardening: Disable fingerprinting & apply defense headers
app.disable('x-powered-by');
app.use((req, res, next) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('X-Frame-Options', 'SAMEORIGIN');
    res.setHeader('X-XSS-Protection', '1; mode=block');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    next();
});

const io = new Server(server, {
    cors: {
        origin: '*',
        methods: ['GET', 'POST']
    }
});

// Pass socket.io instance to KickService
kickService.setSocketIO(io);

// Middleware
app.use(express.json({ limit: '1mb' }));
app.use(express.urlencoded({ extended: true, limit: '1mb' }));
app.use(cookieParser(process.env.SESSION_SECRET || 'kickmod_super_secure_session_secret_2026_x791'));
app.use(express.static(path.join(__dirname, 'public')));

// Health & Keep-Alive Ping Endpoint (for 24/7 uptime monitoring)
app.get(['/health', '/ping', '/api/ping'], (req, res) => {
    res.status(200).json({ status: 'ok', uptime: Math.round(process.uptime()), timestamp: new Date().toISOString() });
});

// API Routes
app.use('/api', apiRoutes);
app.use('/api/auth', authRoutes);

// Big Live Dashboard Route
app.get('/dashboard', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index_classic.html'));
});
app.get('/live', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index_classic.html'));
});

// Socket.io Realtime Events
io.on('connection', (socket) => {
    console.log('[Socket.io] Dashboard client connected:', socket.id);

    socket.on('disconnect', () => {
        // Disconnected
    });
});

const PORT = process.env.PORT || 3000;

server.listen(PORT, async () => {
    console.log(`===============================================`);
    console.log(`🚀 KickMod Server is running on: http://localhost:${PORT}`);
    console.log(`🌐 Real-time Dashboard: http://localhost:${PORT}`);
    console.log(`===============================================`);

    // Automatically load all monitored channels from database
    try {
        await kickService.loadAndStartAllChannels();
    } catch (err) {
        console.error('Error starting monitored channels:', err.message);
    }
});


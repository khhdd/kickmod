import { ArrowLeft, Play } from "lucide-react";
import { DiscordIcon } from "./Navbar";
import { PingDot } from "./ui";
import LiveCard from "./LiveCard";

interface HeroProps {
  user?: any;
  onOpenAuth?: () => void;
}

export default function Hero({ user, onOpenAuth }: HeroProps) {

  return (
    <section id="top" className="relative isolate overflow-hidden px-4 pb-24 pt-36 md:pt-44">
      {/* background */}
      <div className="pointer-events-none absolute inset-0 -z-10">
        <div className="grid-bg absolute inset-0" />
        <div className="animate-aurora absolute -top-40 right-[10%] h-[520px] w-[520px] rounded-full bg-kick/20 blur-[130px]" />
        <div className="animate-aurora absolute left-[5%] top-40 h-[420px] w-[420px] rounded-full bg-emerald-500/15 blur-[130px]" style={{ animationDelay: "-6s" }} />
        <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-ink to-transparent" />
      </div>

      <div className="mx-auto grid max-w-7xl items-center gap-14 lg:grid-cols-[1.1fr_0.9fr]">
        {/* Text */}
        <div className="text-center lg:text-start">
          <div className="animate-slide-in mb-7 inline-flex items-center gap-2.5 rounded-full border border-kick/30 bg-kick/5 px-4 py-2 text-xs font-bold text-kick backdrop-blur">
            <PingDot />
            النظام السحابي الأذكى لمراقبة مشرفي كيك على مدار الساعة (24/7)
          </div>

          <h1 className="text-5xl font-black leading-[1.3] md:text-6xl xl:text-7xl">
            راقب، قيّم، وأدر
            <br />
            طاقم مشرفيك
            <br />
            <span className="text-gradient drop-shadow-[0_0_30px_rgba(83,252,24,0.35)]">بأعلى دقة وبدون مجهود</span>
          </h1>

          <p className="mx-auto mt-7 max-w-xl text-base leading-8 text-gray-400 md:text-lg lg:mx-0">
            منظومة شاملة للستريمرز ومديري القنوات: رصد الحضور الصامت، تمييز وعزل البوتات التلقائية، توثيق عقوبات الحظر والكتم لحظياً، مع تنبيهات ديسكورد فورية.
          </p>

          <div className="mt-10 flex flex-wrap items-center justify-center gap-3.5 lg:justify-start">
            <a href="#dashboard" className="btn-shine group flex items-center gap-2 rounded-2xl bg-kick px-7 py-4 text-sm font-extrabold text-black shadow-[0_10px_40px_-8px_rgba(83,252,24,0.7)] transition hover:-translate-y-0.5">
              ابدأ المراقبة مجاناً الآن
              <ArrowLeft className="h-4 w-4 transition group-hover:-translate-x-1" />
            </a>
            <a href="/api/auth/discord/login" className="flex items-center gap-2 rounded-2xl bg-[#5865f2] px-7 py-4 text-sm font-bold shadow-[0_10px_40px_-8px_rgba(88,101,242,0.7)] transition hover:-translate-y-0.5">
              <DiscordIcon className="h-5 w-5" />
              تسجيل الدخول عبر ديسكورد
            </a>
            <a href="/dashboard" className="glass flex items-center gap-2 rounded-2xl px-6 py-4 text-sm font-bold transition hover:border-kick/40 hover:text-kick">
              <Play className="h-4 w-4 text-kick" fill="currentColor" />
              استعراض الداشبورد
            </a>
          </div>

          <div className="mt-10 flex items-center justify-center gap-4 text-xs text-gray-500 lg:justify-start">
            <div className="flex -space-x-2 space-x-reverse">
              {["#53fc18", "#22d3ee", "#fbbf24", "#a78bfa"].map((c, i) => (
                <span key={i} className="h-8 w-8 rounded-full border-2 border-ink" style={{ background: `linear-gradient(135deg, ${c}, #0b0f0e)` }} />
              ))}
            </div>
            يثق بنا ستريمرز ومشرفون من جميع أنحاء الوطن العربي
          </div>
        </div>

        <LiveCard />
      </div>
    </section>
  );
}
